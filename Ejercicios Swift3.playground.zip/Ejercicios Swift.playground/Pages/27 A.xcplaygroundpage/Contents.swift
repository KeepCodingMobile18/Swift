//: [Previous](@previous)

import Foundation

// MARK: Ejercicio 1 -> Protocolos

/// Debes de diseñar la `struct` `Jedi` para representar a un... Jedi. Debe de tener las siguientes propiedades:
/// * `name`, `surname` de tipo cadena
/// * `midichlorians` de tipo entero, entre 0 y 1000
/// * `affiliation` es de tipo `Affiliation`, una enum que tendrás que crear para representar los siguinetes
/// casos: GalacticRepublic, RebelAlliance, FirstOrder, GalacticEmpire, MandalorianOrder, KnightsOfRen y Unknown
/// * Una propiedad computable que imprime su nombre completo y la afiliación. Si los midiclorianos son >= 600, debe de anteponer el título "Master"
///
/// Tendrá un init que le pasa esos valores.
///
/// Tendrá un método `unsheathe` (desenvaina) que devuelve una cadena con texto como éste:
/// o:::::::::·::▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
/// La longitud debe de ser proporcional a la cantidad de midiclorianos
///
/// Tienes que hacer que conforme los siguinetes protocolos:
///* `Equatable`: usa todas las propiedades
///* `Comparable`: usa los midiclorianos
///* `CustomStringConvertible`: Debe de imprimir el nombre completoy los midiclorianos entre paréntesis
///* `Codable`

//: [Next](@next)
