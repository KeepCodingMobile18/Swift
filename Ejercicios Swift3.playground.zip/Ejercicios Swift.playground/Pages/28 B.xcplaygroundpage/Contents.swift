//: [Previous](@previous)

import Foundation

// MARK: Ejercicio 1 -> Genéricos
// Implementar una Pila Genérica: Crea una estructura genérica `Stack` que implemente una pila con operaciones básicas como `count`, `push`, `pop`, y `peek`.


// MARK: Ejercicio 2 -> Genéricos
// Cola Genérica: Desarrolla una estructura genérica `Queue` que represente una cola con operaciones como `enqueue` y `dequeue`.. Tiene que tener la propiedad `count` también.


// MARK: Ejercicio 5 -> Genéricos
// Máximo y Mínimo Genérico: Desarrolla funciones genéricas `max` y `min` que devuelvan el máximo y el mínimo, respectivamente, de dos valores pasados como argumentos.

// MARK: Ejercicio 7 -> Extensiones
// Extensión de Array: Escribe una extensión para el tipo genérico `Array` que agregue una función para devolver el elemento en el índice n-ésimo o `nil` si el índice está fuera de rango.

// MARK: Ejercicio 8 -> Extensiones
// Extensión de array :Crea una extensión a Array que añade el método `atRandom` que devuelve un elemento al azar de dicho `Array`.


//: [Next](@next)
