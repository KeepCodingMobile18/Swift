//: [Previous](@previous)

import Foundation

print("-----------------------------------------------")
print("------------------Ejercicio 1------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 1 -> funciones
// Crea la función `isPalindrome` que recibe una cadena y devuelve true si es un palíndromo y False si no.

/// Verifica si una cadena es un palíndromo.
/// - Parameter word: La cadena que será evaluada.
/// - Returns: `true` si es un palíndromo, `false` en caso contrario.
func isPalindrome1(_ word: String) -> Bool {
    // Convertimos la cadena en minúsculas para normalizar y asegurar que la comparación
    // no sea sensible a mayúsculas/minúsculas, y la convertimos en un array de caracteres.
    // let characters = Array(word.lowercased().replacingOccurrences(of: " ", with: ""))
    let characters = Array(word)


    // Inicializamos dos índices: uno al principio y otro al final del array de caracteres.
    var leftIndex = 0
    var rightIndex = characters.count - 1

    // Mientras que el índice izquierdo sea menor que el índice derecho,
    // seguimos comparando los caracteres.
    while leftIndex < rightIndex {
        // Si los caracteres en los índices actuales no coinciden,
        // entonces no es un palíndromo, así que devolvemos false.
        if characters[leftIndex] != characters[rightIndex] {
            return false
        }
        
        // Movemos el índice izquierdo hacia la derecha.
        leftIndex += 1
        // Movemos el índice derecho hacia la izquierda.
        rightIndex -= 1
    }

    // Si hemos comparado todos los pares de caracteres y todos coinciden,
    // entonces la palabra es un palíndromo, así que devolvemos true.
    return true
}

// Ejemplo de uso:
print(isPalindrome1("radar")) // true: "radar" es un palíndromo.
print(isPalindrome1("hello")) // false: "hello" no es un palíndromo.
print(isPalindrome1("Racecar")) // true: "Racecar" es un palíndromo cuando se ignoran mayúsculas/minúsculas.
print(isPalindrome1("anilina")) // true
print(isPalindrome1("reconocer")) // true
print(isPalindrome1("hola")) // false
print(isPalindrome1("A man a plan a canal Panama")) // true
print(isPalindrome1("reConOcer")) // true

func isPalindrome(_ word: String) -> Bool {
    return word == String(word.reversed())
}

func test_whenEvenPalindrome_isTrue() {
    let word = "lcggcl" // Output true
    assert(isPalindrome(word) == true, "The test \(#function) failed: the palindrome lcggcl is actually a palindrome")
}

test_whenEvenPalindrome_isTrue()
//: [Next](@next)
