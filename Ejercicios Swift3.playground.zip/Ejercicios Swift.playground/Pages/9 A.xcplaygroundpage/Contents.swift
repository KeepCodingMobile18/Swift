//: [Previous](@previous)

import Foundation

// MARK: Ejercicio bucles 1
// Crea la función `countChars(char:Character, inString:String)->Int` que devuelve el número de veces que un caracter aparece en una cadena.

func countCharsEqualToChar(_ ch:Character, inString string:String)->Int {
    let estoEsUnChar = ch
    let stringCopy = string
    return 0
}


// MARK: Ejercicio bucles 2
// Crea la función `removeDuplicates` que recibe una cadena y devuelve esa misma cadena con los caracteres repetidos eliminados. OJO, tiene que respetar el orden original!

// MARK: Ejercicio bucles 3
// Crea la función `condense`que recibe una cadena con caracteres en blanco y elimina los caracteres en blanco repetidos. Recuerda que tiene que funcionar con los que estén al principio y al final de la cadena, no sólo los que están dentro.

// MARK: Ejercicio bucles 4
//  Crea la función `classify` que recibe una cadena y devuelve una tupla con 2 valores:
//          * número de vocales
//          * número de caracteres que no son vocales
// Soy consciente de que no hemos visto las tuplas, arregláoslas.


// MARK: Ejercicio bucles 5
//  Crea la función `fizzBuzz`que itera entre el 1 y el 100 e imprime "Fizz" si el número actual es divisible por 3, "Buzz" si es divisible por 5 y "FizzBuzz" si es divisible por 3 y por 5.

// MARK: Ejercicio bucles 6
//  Recrea en Swift la función `choice` de Python, que recibe una lista y devuelve un elemento al azar de la misma.

// MARK: Ejercicio bucles 7
//  Crea la función `contains(hayStack: String, needle: String)->Bool`. Si el *pajar* continene a la *aguja*, devolvemos `true` y sino, `false`


// MARK: Ejercicio bucles 8
//  Crea la función `find(hayStack: String, needle: String)->Int` que en vez de devolver un booleano, devuele un entero con *la posición inicial* de la *aguja*.
//         * si no encuentra la aguja, devuelve la constante `NSNotFound`. Esa constante ya existe en `Cocoa`
//         * si no sabes donde está, habla con Grokk.


// MARK: Ejercicio bucles 9
//  Ahora que ya tienes `find`, piensa si de verdad hace falta `contains`. Busca la forma de poder reimplementar `contains` sólo en base a `find`.

// MARK: Ejercicio bucles 10
//  Crea la función `containsOccurrences(hayStack: String, needle: String, numOfOccs: Int)->Bool`
//        * Si `numOfOccs` < 0, se devuelve `false`
//        * Si `numOfOccs` == 0, se comprueba que la *aguja* no aparece nunca en el *pajar*
//        * Si `numOfOccs` > 0, estamso en el caso general




//: [Next](@next)
