//: [Previous](@previous)

import Foundation

/*
guard condition else {
    // Código que se ejecuta si la condición NO se cumple
    return // o throw, break, continue, etc.
}

// Si se cumple continua
*/
func funcionPrueba() {
    
    let booleano: Bool = true
    guard booleano == false else {
        print("El booleano no es false")
        return
    }
    print("El booleano es false")
    
}

//funcionPrueba()


// MARK: Guard let
let enteroOpcional: Int? = nil

func funcionDePrueba2() {
    
    
    guard let enteroOpcionalUnwrapped = enteroOpcional else {
        print("El entero opcional es nil \(enteroOpcional)")
        return
    }
    print("El entero opcional no es nil, es: \(enteroOpcionalUnwrapped)")
    
    
    
    
    if let enteroOpcionalUnwrapped2 = enteroOpcional {
        print("El entero opcional no es nil, es: \(enteroOpcionalUnwrapped)")
        
    } else {
        print("El entero opcional es nil \(enteroOpcional)")
    }
}


funcionDePrueba2()
//: [Next](@next)
