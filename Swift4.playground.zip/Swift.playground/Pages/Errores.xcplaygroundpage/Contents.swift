//: [Previous](@previous)

import Foundation


enum MyAppError: Error {
    case networkError
    case parsingError
    case unauthorizedAccess
    case invalidSize
}


func doSomething(withThis: String) throws -> Int {
    let size = withThis.count
    if size < 5{
        throw MyAppError.invalidSize
    }
    return size
}



do {
    let size = try doSomething(withThis: "12")
} catch MyAppError.networkError {
    print("Ha ocurrido algún error de red")
} catch MyAppError.invalidSize {
    print("Ha ocurrido algún error de tamaño")
}


var rc = try? doSomething(withThis: "uu")
// rc = try! doSomething(withThis: "iii")


//: [Next](@next)
