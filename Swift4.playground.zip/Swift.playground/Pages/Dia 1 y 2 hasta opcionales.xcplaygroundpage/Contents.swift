import Cocoa

// MARK: Variables y constantes

// Variables
var greeting = "Hello, playground"
print(greeting)
greeting = "Hello, hemos cambiado el saludo"
print(greeting)

// Constantes
let greetingConstante = "Greeting constante"
print(greetingConstante)
let greetingConstante2 = "Cambiamos el valor del greeting Constante" // Declaramos el greeting como constante
print(greetingConstante2)

// MARK: Comentarios

/// La función de prueba suma dos números y devuelve la suma multiplicada por dos.
///
/// - Parameters:
///   - num1: Número 1 que se va a sumar.
///   - num2: Número 2 que se va a sumar.
/// - Returns: La suma de los dos números multiplicada por dos.
///
/// Something
func funcionDePrueba(num1: Int, num2: Int) -> Int {
    return (num1) * 2
}


/*
 wadhiwahdiawnhid
 dnwidnhwiandiaw
 - Esto es un bloque
* Esto está comentado
 */

// MARK:
// MARK: -
// TODO: haY QUE implementar una funcionalidad
// FIXME: esto hay que arreglarlo


// MARK: Tipos
// Primitivos
let constanteStringImplícita = "Es un string implícito" // Manera implícita
let constanteStringExplícita: String = "Es un string explícito"
let intNumber: Int = 666 // Negativos o positivos -> 4 bytes
let intnumberImplícito = 122
let positiveIntNumber: UInt8 = 255 // hasta 255 -> 8 bits = 1 byte
let positiveLongIntNumber: UInt16 = 12737 // hasta 65535 -> 16 bits
let floatNumber: Float = 12.3
let doubleNumber: Double = 12.3442453
let isMinor: Bool = intNumber < 100

// Listas
let array1Implícito = ["Starlight", "Homelander", "Black Noir", "Queen Mave", "Translucent", "A Train", "The Deep"]
let array1explíctio: [String] = ["Starlight", "Homelander", "Black Noir", "Queen Mave", "Translucent", "A Train", "The Deep"]
let arrayDeArrays: [[String]] = [["Starlight", "Homelander", "Black Noir", "Queen Mave", "Translucent", "A Train", "The Deep"]]
// let arrayDeNúmeros = [2,2,4,2,"String"] // No acepta arrays de varios tipos

// Sets
let vowels = ["a", "e", "o", "u", "a"]
let vowelsSet: Set = ["a", "e", "o", "u", "a"]
let vowelsSetExplicit: Set<String> = ["a", "e", "o", "u", "a"]
let voewslSet2 = Set(["a", "e", "o", "u", "a"])

print(vowels)
print(vowelsSet)
print(vowelsSetExplicit)
print(voewslSet2)

// Diccionarios

var phoneNumbers: [String: String] = [
    "Alice":"630997788",
    "Bob":"91287391"
]

var number = phoneNumbers["Alice"]

if let aliceNumber = phoneNumbers["Alice"] {
    print(aliceNumber)
} else {
    print("Con optional")
}

print(number)

var bobNumber = phoneNumbers["Bob3"]
print(bobNumber)

for (name, number) in phoneNumbers {
    print(name, number)
}

// Boleano
let weight = 30
let age = 50
let ageIsMinorThanWeight = age < weight
print(ageIsMinorThanWeight)

if ageIsMinorThanWeight {
    print("Age is minor than weigth")
} else if weight > 90 {
    print("Age is greater or equal than weigth")
} else {
    print("Other")
}

// Enums
enum EmailState {
    case addressUnknown
    case confirmed
    case notConfirmed
}

let emailState = EmailState.addressUnknown
if emailState == EmailState.confirmed {
    print("Email confirmed")
} else {
    print("Email not confirmed")
}

enum Currency: String {
    case usd = "USD"
    case euro = "EURO"
}

let currency = Currency.euro
print(currency)
print(currency.rawValue)

// MARK: - Funciones

// El bmi es el peso / altura * altura
func maleBMI(weight: Double, height: Double) -> Double {
    // Función hace algo aquí
    let bmi = weight / (height * height)
    return bmi
}

print(maleBMI(weight: 2,height: 2))

func calculateBMI(withWeightInKg weight: Double, andHeightInMeters height: Double) -> Double {
    let bmi = weight / (height * height)
    return bmi
}

func calculateBMI(_ weight: Double, andHeightInMeters height: Double) -> Double {
    let bmi = weight / (height * height)
    return bmi
}


// MARK: Metodología de resolución
// Ejercicio 1: Crea la función `isPalindrome` que recibe una cadena y devuelve true si es un palíndromo y False si no.

// 1. Definir y entender el problema: "lcggcl" -> es un palíndromo

// 2. Declarar la función
// 2.1. Nombre de la función: isPalindrome
// 2.2. Entrada de la función: el string que vayamos a analizar -> "lcggcl"
// 2.3  Salida de la función: el booleano que nos va a decir si es o no es un palíndromo -> bool
// isPalindrome(word: String) -> Bool { }

// 3. Lógica de resolución del problema
// 3.1 Comparar letra por letra desde el inicio hasta el final: "lcggcl" -> l con l, c con c...
// 3.2. Invertir la palabra y ver si coincide con la palabra inicial: "lcpgal" == "lagpcl" ??
// 3. ....

// 4. Codificar la solución
func isPalindrome(_ word: String) -> Bool {
    // Comparar letra por letra desde el inicio hasta el final: "lcggcl" -> l con l, c con c...
    let characters = Array(word.lowercased().replacingOccurrences(of: " ", with: "")) // amanaplanacanalpanama
    
    
    var leftIndex = 0
    var lastIndex = characters.count - 1
    
    while leftIndex < lastIndex {
        if characters[leftIndex] != characters[lastIndex] {
            return false
        }
        // Actualizar los índices
        leftIndex += 1
        lastIndex -= 1
    }
    
    return true
}

// 5. Probar la función
print(isPalindrome("agaegfawaa")) // false
print(isPalindrome("anilina")) // true
print(isPalindrome("reconocer")) // true
print(isPalindrome("hola")) // false
print(isPalindrome("A man a plan a canal Panama")) // true
print(isPalindrome("reConOcer")) // true
print(isPalindrome("")) // true
print(isPalindrome("a")) // true

// 6. Problemas
// Las mayúsculas y minúsculas están siendo tenidas en cuenta
// agaegfawaa está dando true porque la primera y última letra son iguales
// A man a plan a canal Panama HAY ALGÚn problema

// 7. Refactorizar la función para resolver los problemas del punto 6 -> punto 4

func isPalindrome2(_ word: String) -> Bool {
    return word == String(word.reversed())
}

func test_whenEvenPalindrome_isTrue(word: String) {
    assert(isPalindrome2(word) == true, "The test \(#function) failed: the palindrome lcggcl is actually a palindrome")
}

test_whenEvenPalindrome_isTrue(word: "lcggcl")


// MARK: Optionals

let variableQueNoPuedeSerOpcional: Int = 20
let variableQuePuedeSerOpcional: Int? = nil
var variable2opcional: Int? = nil

print(variableQueNoPuedeSerOpcional)
print(variableQuePuedeSerOpcional)
print(variable2opcional)

print("Número opcional aaa \(Int("aaaa"))")
print("Número opcional 2 \(Int("2"))")

// Maneras de desempaquetar un opcional
// ?? y !
let k: String? = "nO ES NIL"

// print(k!)
print(k ?? "Es nil")

func bmi(weightInKg: Double, heightInCm: Double) -> Double? {
    var result: Double?  // Si no le asigno un valor, por defecto vale nil
    
    if heightInCm >= 0 && weightInKg >= 0{
        let h = heightInCm / 100
        result = (weightInKg / (h * h))
    } else {
        result = nil
    }
    
    return result
}

let bmiOptional = bmi(weightInKg: -2, heightInCm: -2)

// Desempaquetado con if let
if let bmi1 = bmi(weightInKg: 78, heightInCm: 165) {
    // Aquí bmi1 solo puede ser Double
    print("La función no es un nula: \(bmi1)")
} else{
    print("Es un nulo: ¡no lo toques!")
}

if let bmi2 = bmiOptional {
    print("La variable no es un nula: \(bmi2)")
} else{
    print("Es un nulo: ¡no lo toques!")
}

// La mejor hasta ahora -> if let
// Segunda mejor coalesce ??
// Tercera force unwrap !


enum BodyMassIndex {
    case underweight
    case healthy
    case overweight
    case obese
    case invalid
}

func classify(bmi: Double) -> BodyMassIndex {

    var result: BodyMassIndex
    
    if bmi < 18.5{
        result = BodyMassIndex.underweight
    }else if (18.5 <= bmi) && (bmi < 24.9){
        result = BodyMassIndex.healthy
    }else if (24.9 <= bmi) && (bmi < 29.9){
        result = BodyMassIndex.overweight
    }else{
        result = BodyMassIndex.obese
    }
    
    return result
}

// La mejor manera es usar switch
func classify2(bmi: Double) -> BodyMassIndex? {
    var result: BodyMassIndex?
    
    switch bmi {
    case let x where x < 0:
        result = nil
    case let x where x < 18.5:
        result = BodyMassIndex.underweight
    case let x where x < 24.9:
        result = BodyMassIndex.healthy
    case let x where x < 29.9:
        result = BodyMassIndex.overweight
    default:
        result = BodyMassIndex.obese
    }
    
    return result
}

func classify3(bmi: Double?) -> BodyMassIndex? {
    var result: BodyMassIndex?

    switch bmi {
    case nil:
        print("El valor de BMI es nulo")
        return nil
    case let x? where x < 0:
        print("El valor de BMI es negativo")
        result = nil
    case let x? where x < 18.5:
        result = BodyMassIndex.underweight
    case let x? where x < 24.9:
        result = BodyMassIndex.healthy
    case let x? where x < 29.9:
        result = BodyMassIndex.overweight
    default:
        result = BodyMassIndex.obese
    }

    return result
}

classify2(bmi: 18.9)
classify2(bmi: 2)
let optionalDouble: Double? = nil
classify3(bmi: -3)

// Ejemplo de desempaquetado con las tres formas

let optionalValue: String? = "Esto es un string"
print(optionalValue)

// 1. If let
if let optionalValueUnwrapped = optionalValue {
    // Para todo lo que ejecutemos aquí tenemos la certeza de que optionalValueUnwrapped es un String
    print(optionalValueUnwrapped)
}

// 2. Con coalesce
print(optionalValue ?? "Esto es nil")

// 3. Con force unwrapp
// print(optionalValue!)



// Cadena está rotada
/// Escribe una función que acepte dos cadenas y retorne true si una cadena es una rotación de la otra, considerando la distinción entre mayúsculas y minúsculas.
/// Consejo: Una rotación de cadena ocurre cuando tomas una cadena, remueves algunas letras de su final y las agregas al inicio.
/// Entradas y salidas de ejemplo: - "abcde" y "eabcd" ➔ true - "abcde" y "cdeab" ➔ true - "abcde" y "abced" ➔ false - "abc" y "a" ➔ false
func isRotated(inputWord word: String, ofRotatedWord rotatedWord: String) -> Bool {
    // Las cadenas tienen que tener la misma longitud, si no, retorna false
    guard word.count == rotatedWord.count else { return false } // abcde == abcde
    // Las cadena está rotada si abcde + abcde contiene a la rotada
    let combinedInputWord = word + word
    return combinedInputWord.contains(rotatedWord)
}

func testIsRotated() {
    assert(isRotated(inputWord: "abcde", ofRotatedWord: "eabcd") == true, "Test failed: 'eabcd' es una rotación de 'abcde'")
    assert(isRotated(inputWord: "abcde", ofRotatedWord: "cdeab") == true, "Test failed: 'cdeab' es una rotación de 'abcde'")
    assert(isRotated(inputWord: "abcde", ofRotatedWord: "abced") == false, "Test failed: 'abced' no es una rotación de 'abcde'")
    assert(isRotated(inputWord: "abc", ofRotatedWord: "a") == false, "Test failed: 'a' no es una rotación de 'abc'")
    assert(isRotated(inputWord: "hello", ofRotatedWord: "llohe") == true, "Test failed: 'llohe' es una rotación de 'hello'")
    assert(isRotated(inputWord: "swifty", ofRotatedWord: "tyswif") == true, "Test failed: 'tyswif' es una rotación de 'swifty'")
}

// Ejecutar el test
testIsRotated()


