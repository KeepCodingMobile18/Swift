//: [Previous](@previous)

import Foundation

/*
 _____ _
/  __ \ |
| /  \/ | ___  ___ _   _ _ __ ___  ___
| |   | |/ _ \/ __| | | | '__/ _ \/ __|
| \__/\ | (_) \__ \ |_| | | |  __/\__ \
 \____/_|\___/|___/\__,_|_|  \___||___/
                                       

*/

// MARK: - Función = closure
// En Swift todas las funciones son *clausuras*. Esto quiere decir lo siguiente:
// * Se pueden guardar en variables, listas, etc...
//
// Esta combinación es sumamente potente y flexible, aunque tiene una sintaxis
// que a veces puede ser confusa.
//
func add(a:Double, b:Double)->Double{
    let result = a + b
    print("Add function executed with result: \(result)")
    return result
}

func mult(a: Double, b: Double)-> Double{
    let result = a * b
    print("Mult function executed with result: \(result)")
    return result
}

// Podemos meterlas en una lista, como culquier otro valor
let funcs = [add, mult]
print(funcs)

// Podemos asignarlas a una variable y llamarlas
let addFunction = add
addFunction(2,2)

// Podemos ejecutarlas en bucle. Cuando las ejecutamos no podemos poner las etiquetas
for function1 in funcs {
    function1(2,3)
}

// MARK: - Sintaxis de las closures
// Dado que una función es un valor más, lo podemos asignar a
// una variable (usando una sintaxis un poco diferente)
// Es el equivalente a las expresiones lambda de Python, pero más flexible, ya que
// pueden tener más de una linea
//
// Sintaxis normal:
// 1. abrimos llaves y sabemos que es una closure
// 2. ponemos el encabezado como si fuese una función
// 3. ponemos in para separar el encabezado del resto: ¿Por qué se pone in?  https://forums.swift.org/t/history-why-does-closure-syntax-use-the-keyword-in/21885
// 4. creamos la función
let normal = { (n: Double, m: Double) -> Double in
    return n + m
}

// Se usan mucho, y el caso especial de una función muy sencillita, de usar y tirar,
// como las expresione lambda de Python, es tan común que hay una sintaxis
// simplificada.
//
// MARK: Una sola línea
// Se usa, es la más explícita
let unaSolaLinea = { (n: Double, m: Double) -> Double in
    return n + m
}

// MARK: Return implícito
// Se usa, aunque prefiero la anterior
// Como solo hay una linea, el return no hace falta: devolverá el valor de la única expresión
let returnImplícito = { (n: Double, m: Double) -> Double in
    n + m
}

// MARK: Tipo de retorno implícito
// Como el compilador sabe el tipo de los parámetros, puede inferir el tipo de retorno y lo podemos obviar.
// Esto sólo funciona porque la información está ahí, en algún lugar que el compilador puede encotnrar.
// En este caso, los parámetros y la operación de sumarlos
// No la he usado en mi vida y si la veo me hace daño en los ojos
let tipoRetornoImplicito = { (n: Double, m: Double) in
    n + m
}

// MARK: Tipo de parámetros implícitos
// Es la que más se usa. Ya veremos cuando las usemos que es la manera (predeterminada)
let parametrosImplicitos: (Double, Double) -> Double = { a, b in
    return a + b
}

// MARK: Tipo de parámetros y retorno implícitos
// Podría darse el caso que el compilador sepa tanto el tipo de retorno como el tipo de los parámetros. En ese caso
// no tenemos que repetir esa información
// Un poco de lo anterior
let parametrosYRetornoImplicito: (Double, Double) -> Double = { a, b in
    a + b
}

// MARK: Sintaxis hiperreducida
// De hecho podemos simplificar aun más! No hace falta darle un nombre al parámetro. Podemos referirnos
// a él como _el primero_, _el segundo_, etc. Sabiendo que el primero es el 0, la sintáxis es:
// Sí que se usa, sobre todo en las funciones de alto nivel map, filter...
let sintaxisHiperreducida: (Double, Double) -> Double = {
    $0 + $1
}

// `$0` es una forma de decir _el primer_ parámetro.
// `$1` sería el segundo, etc...

// Esta sintaxis hiper reducida es común, sobre todo cuando la clausura es parámetro de otro función. Se usa para evitar mucho código.
// Sinceramente, muchas de estas sintaxis no se ven. Mi preferida es la más explícita, la primera de todas
// No obstante, hay que saber reconocerlas todas aunque no las escribamos

let numeros: [Double] = [1.5, 2.3, 5.5, 3.1, 0.7, 4.8]
let umbral: Double = 4.0

let numerosFiltrados = numeros.filter {
    $0 > umbral
} // Ejemplo, que no os de un ictus todavía

let suma = numerosFiltrados.reduce(0.0, sintaxisHiperreducida)

print("La suma de los números filtrados es: \(suma)")
// Salida esperada: La suma de los números filtrados es: 15.7


// MARK: - Uso de closures
// MARK: - Closures como parámetros
// Cómo usaríamos estas closures?
// Declaramos una función con una closure y dos números. Vamos a realizar una operación con ellos
func performSomeOperationWith(number1 n1: Double, andNumber2 n2: Double, closure: (Double, Double) -> Double) -> Double {
    print()
    print("Double n1 and n2")
    let doubleN1 = n1 * 2 // n1 = 2 -> doubleN1 = 4
    let doubleN2 = n2 * 2 // n2 = 2 -> doubleN2 = 4
    print("Before closure")
    let closureVal = closure(doubleN1,doubleN2) // closure(4, 4) -> esto devuelve un Double
    print("Closure val = \(closureVal)")
    print("After closure")
    return closureVal
}

/// Utilizamos la función
/// En este caso vamos a usarla para sumar los números
let valueAfterOperation = performSomeOperationWith(number1: 2, andNumber2: 2, closure: { n1, n2 in
    return n1 + n2
})
print(valueAfterOperation)

// Si nos acordamos arriba de las closures que hemos declarado y almacenado en las variables normal, unaSolaLinea, returnImplícito... todas hacen lo mismo, suman dos números y tienen el mismo tipo (Double, Double) -> Double. Entonces podemos usarlas en lugar de la closure
let valueAfterClosureNormal = performSomeOperationWith(number1: 2, andNumber2: 2, closure: normal)
print("Valor de closure normal: \(valueAfterClosureNormal)")

let valueAfterUnaSolaLinea = performSomeOperationWith(number1: 2, andNumber2: 2, closure: unaSolaLinea)
print("Valor de closure una sola línea: \(valueAfterUnaSolaLinea)")

let valueAfterReturnImplícito = performSomeOperationWith(number1: 2, andNumber2: 2, closure: returnImplícito)
print("Valor con return implícito: \(valueAfterReturnImplícito)")

let valueAfterTipoRetornoImplicito = performSomeOperationWith(number1: 2, andNumber2: 2, closure: tipoRetornoImplicito)
print("Valor con tipo de retorno implícito: \(valueAfterTipoRetornoImplicito)")

let valueAfterParametrosYRetornoImplicito = performSomeOperationWith(number1: 2, andNumber2: 2, closure: parametrosYRetornoImplicito)
print("Valor con parámetros y tipo de retorno implícitos: \(valueAfterParametrosYRetornoImplicito)")

let valueAfterSintaxisHiperreducida = performSomeOperationWith(number1: 2, andNumber2: 2, closure: sintaxisHiperreducida)
print("Valor con sintaxis hiperreducida: \(valueAfterSintaxisHiperreducida)")

// MARK: Closure como último parámetro -> trailing closure
// Cuando escribimos una closure como último parámetro, podemos utilizar la sintaxis propia
let valueAfterOperation2 = performSomeOperationWith(number1: 2, andNumber2: 2) { a, b in
    a + b
}

// MARK: - Ejemplo por la pregunta de Aroa de un uso "real"
// Uso de todo esto:
// Tenemos esta función para guardar los datos
// MARK: Sección que se encarga de todo las funcionalidades de almacenamiento y tratamiento de datos
func storeData(_ data: String) {
    print("2. Storing data in keychain...")
    print("3. Stored data: \(data)")
}


// MARK: Sección que se encarga de interactuar con la red
// El programa se inicia y necesitamos la información del usuario para guardarla en el iphone. Solo podemos guardar la información una vez la hemos recuperado.
func fetchData(forUser name: String, closure: (String) -> Void) {
    print()
    print("1. Fetching data for user \(name)")
    for second in 1...10 { print("----- \(second) seconds elapsed")} // Esto dura varios segundos, horas o milisegundos. Lo suficiente como para que se ejecute un programa
    let fetchedData = "\(name) ID = 71927189"
    closure(fetchedData) // Aquí ya sabemos que contamos con la información del servidor para el usuario
}

// MARK: Función main
// Queremos guardar la información en el dispositivo cuando hayamos obtenido los datos
func storeDataForUser(name: String) {
    // El programa empieza -> segundo 1
    fetchData(forUser: name) { fetchedData in
        storeData(fetchedData) // El programa está 10 segundos
        // ponerFotoNuevaAlUsuario()
    }
}

func main() {
    storeDataForUser(name: "Aroa")
}

main()

// MARK: Otros usos
// Aparte de funciones asíncronas se usan en operaciones como map, filter, reduce... SwiftUI -> todo closures, para empaquetar la información y evitar que navegue por el programa descontroladamente (desarrollo seguro)

//: [Next](@next)
