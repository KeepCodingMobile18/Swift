//: [Previous](@previous)
//: # Tipos de Datos y Colecciones en Swift
/*:
## Índice
* [Tipos de Datos](#Tipos-de-Datos)
* [Tuplas](#Tuplas)
* [Listas (Arrays)](#Listas-Arrays)
* [Conjuntos (Sets)](#Conjuntos-Sets)
* [Diccionarios](#Diccionarios)

Swift proporciona una amplia variedad de tipos de datos, desde tipos numéricos como enteros o decimales hasta tipos de colecciones como arrays, conjuntos y diccionarios. A continuación se detallan cada uno de estos.
 
 ![Tipos en Swift](tipos.png)

*/
//: ## Tipos de Datos
/*: Los tipos de datos en Swift pueden ser especificados explícitamente o deducidos por el compilador. Todos los tipos son clases, a diferencia de lenguajes como Java donde existen tipos primitivos separados de las clases.
*/
let nombre: String = "Billy Butcher" // Especificación explícita del tipo
let nombre2 = "Billy Butcher" // Especificación implícita por deducción del compilador
let nombreCalle: String = "Nosh my bollocks ave"
let numeroCalle: Int = 673 // Enteros de 64 bits
let numeroCallePositivo: UInt8 = 122 // Entero sin signo de 0 a 255, se usa, por ejemplo, para el RGB
let numeroCallePositivoLargo: UInt16 = 122
let peso: Float = 83.6
let indiceMasaCorporal: Double = 21.4627453636
let edad: Int = 32
let esMenorDeEdad: Bool = edad < 18
//: ## Listas (Arrays)
/*: En Swift, a lo que en otros lenguajes como Python se llama una lista, aquí se denomina Array. Pueden definirse explícitamente o dejar que el compilador infiera su tipo. Cada array tiene que tener un único tipo de datos.
*/
let losSieteImplicito = ["Starlight", "Homelander", "Black Noir", "Queen Mave", "Translucent", "A Train", "The Deep"] // Array implícito
let losSieteExplicito: [String] = ["Starlight", "Homelander", "Black Noir", "Queen Mave", "Translucent", "A Train", "The Deep"] // Array explícito
let losChicos: [String] // Array declarado, pero no inicializado
let listaDeListas: [[Int]] // Un array de arrays de enteros
//: ## Conjuntos (Sets)
/*: Los sets en Swift son colecciones sin elementos duplicados. Los sets no usan llaves para su definición en Swift, sino los mismos corchetes que los Arrays. Por lo tanto, es necesario especificar que estás creando un Set:
*/
let vocales = ["a", "e", "o", "u"]  // Array de vocales
let conjuntoVocalesExplícito: Set<String> = ["a", "e", "o", "u"] // Conjunto explícito
let conjuntoVocalesImplícito = Set(["a", "e", "o", "u"]) // Conjunto implícito
let conjuntoSinRepeticion = Set(["a", "e", "o", "u", "u"]) // Las repeticiones se eliminan automáticamente

// Iterando sobre un conjunto
for letra in conjuntoSinRepeticion {
    print(letra)
}
//: ## Tuplas
/*:
Las tuplas son una forma simple de agrupar múltiples valores en un único compuesto. Pueden contener elementos de diferentes tipos y son útiles para devolver múltiples valores desde una función. No son estrictamente colecciones.
*/
// Definiendo una tupla simple con dos elementos, un `String` y un `Int`.
let studentData = ("John", 21)

// Accediendo a los elementos de la tupla usando índices.
let name = studentData.0
let age = studentData.1

// También se pueden definir tuplas con elementos nombrados para un acceso más claro.
let student = (name: "Alice", age: 22)

// Accediendo a los elementos por nombre.
let studentName = student.name
let studentAge = student.age

// Tuplas como valores de retorno en funciones
func getStudentInfo() -> (name: String, age: Int) {
    return ("Bob", 23)
}

// Llamando a la función y almacenando su resultado en una tupla.
let (studentName2, studentAge2) = getStudentInfo()

// Descomponiendo la tupla directamente en variables individuales.
let (name2, age2) = studentData

// Si no me importa uno de los componentes,
let (nameOfStudent, _) = studentData
print(nameOfStudent)

// Ejemplo real usando tuplas en una función asíncrona
func fetchShelterPoints() async -> Result<[ShelterPointModel], NetworkError> {
    guard let url = URL(string: "http://127.0.0.1:8080/api/shelters") else { return .failure(.invalidURL) }
    
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.setValue("mWIwALVZo3a0evMfbUgkl/gLvRis1/w99To0AamBN+0=", forHTTPHeaderField: "ApiKey")
    
    do {
        // Esto de aquí es la respuesta en una tupla (data, response)
        let (data, response) = try await URLSession.shared.data(for: request)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else { fatalError("Error while fetching data") }
        
        let shelterPointModel = try JSONDecoder().decode([ShelterPointModel].self, from: data)
        return .success(shelterPointModel)
    } catch {
        return .failure(.responseError)
    }
}
//: ## Diccionarios
/*: Los diccionarios en Swift son colecciones de asociaciones clave-valor. Son útiles para almacenar valores donde cada elemento puede ser accedido mediante su clave única.
*/
var numerosDeTelefono: [String: String] = [
    "Alice": "555-1234",
    "Bob": "555-5678"
]

// Acceso, adición, actualización y eliminación en diccionarios
if let numeroDeAlice = numerosDeTelefono["Alice"] {
    print("El número de teléfono de Alice es \(numeroDeAlice)")
} else {
    print("No se encontró el número de teléfono de Alice")
}

numerosDeTelefono["Charlie"] = "555-9999" // Añadiendo un nuevo valor
numerosDeTelefono["Alice"] = "555-4321" // Actualizando un valor existente
numerosDeTelefono["Bob"] = nil // Eliminando un par clave-valor

for (nombre, numero) in numerosDeTelefono {
    print("\(nombre): \(numero)")
}

/*: [Errores comunes en diccionarios:](#Errores-comunes-en-diccionarios)
 1. Intentar acceder a una clave inexistente devuelve nil.
 2. Intentar modificar un diccionario declarado con `let`.
*/
//: [Next](@next)
