//: # Introducción a Clases en Swift
/*:
## Índice
1. [Concepto de Clases](#1-Concepto-de-Clases)
2. [Herencia en Clases](#2-Herencia-en-Clases)
3. [Cuándo Usar Clases vs Structs](#3-Cuándo-Usar-Clases-vs-Structs)

Las clases en Swift son una manera de definir plantillas para crear objetos. Estas plantillas pueden tener propiedades (datos) y métodos (funciones), lo que hace que cada objeto que se crea a partir de una clase comparta el mismo conjunto de características y comportamientos definidos por esa clase. Las clases son tipos de referencia, lo cual es fundamental entender al trabajar con ellas.

 ![Clases](clase.png)

 */
//: ## 1. Concepto de Clases
/*:
Una clase define una estructura de datos que permite utilizar propiedades y métodos. Las clases son tipos de referencia, lo que significa que cuando creas una clase y la asignas a una nueva variable, estás manejando una referencia al mismo objeto.

### Ejemplo de una Clase
*/
class Worker {
    var workerPosition: String
    
    init(workerPosition: String) {
        self.workerPosition = workerPosition
    }
    
    func ejecutarTrabajo() {
        print("Trabajo ejecutado")
    }
}

let trabajador1 = Worker(workerPosition: "Manager")
let trabajador2 = trabajador1

trabajador2.workerPosition = "Supervisor"

print(trabajador1.workerPosition)  // Salida: Supervisor
/*:
En este ejemplo, la clase `Worker` tiene una propiedad `workerPosition` y un método `ejecutarTrabajo()`. Cada objeto de tipo `Worker` tendrá una `workerPosition` y podrá ejecutar trabajo. Notamos que al asignar `trabajador1` a `trabajador2`, ambos apuntan al mismo objeto, por lo que modificar `workerPosition` en `trabajador2` también afecta a `trabajador1`.

### Tipos de Referencia

Cuando trabajas con clases, no estás trabajando directamente con el objeto, sino con una referencia a la ubicación del objeto en la memoria. Esto significa que si asignas un objeto de una clase a otra variable, ambos apuntarán al mismo objeto en la memoria.

Imagina las cajas como slots de memoria donde se almacenan los datos y las flechas como las variables que apuntan a esas cajas. Cuando cambias el contenido de la caja, cualquier flecha que apunte a ella verá el cambio.
*/
//: ## 2. Herencia en Clases
/*:
### ¿Qué es la Herencia y Por qué es Útil?

La herencia es un concepto fundamental de la programación orientada a objetos que permite que una clase (denominada subclase) adquiera las propiedades y métodos de otra clase (denominada superclase). Esto facilita la creación de jerarquías de clases donde las subclases pueden reutilizar código de sus superclases, haciéndolas más eficientes y organizadas.

### Ejemplo de Herencia

Supongamos que deseas modelar una jerarquía de roles en una empresa. Tienes una clase `Worker` con información básica sobre un trabajador, y quieres crear una subclase `Employee` que herede de `Worker`:
 */
class Employee: Worker {
    var employeeID: Int
    
    init(workerPosition: String, employeeID: Int) {
        self.employeeID = employeeID
        super.init(workerPosition: workerPosition)
    }
    
    func showDetails() {
        print("Position: \(workerPosition), ID: \(employeeID)")
    }
}

// Creación de un objeto Employee
let empleado1 = Employee(workerPosition: "Developer", employeeID: 12345)
empleado1.ejecutarTrabajo() // Salida: Trabajo ejecutado
empleado1.showDetails()     // Salida: Position: Developer, ID: 12345
/*:
### Nota sobre Inicializadores

Es importante resaltar que en nuestra clase `Employee`, hemos llamado al `init` de la superclase `Worker` utilizando `super.init`. Esto asegura que la propiedad `workerPosition` se inicialice correctamente al crear un objeto `Employee`.

*/
//: ## 3. Cuándo Usar Clases vs Structs
/*:
Entender cuándo usar una clase o una struct es importante y depende en gran medida del caso de uso.

 ![Comparativa struct vs clase](tabla.png)

### Usos de las Clases
- **Instancias Compartidas:** Útiles para instancias que requieren ser compartidas o donde el estado necesita ser mutable.
- **Herencia:** Adecuadas para casos donde el polimorfismo y la herencia son necesarios.
- **Uso Complejo de Objetos:** Cuando necesitas deinitializers y gestión de ciclos de vida.

### Usos de las Structs
- **Modelado de Datos Simples:** Ideal para datos inmutables y ligeros.
- **Implementación Sencilla:** Rápida y fácil de usar debido a su gestión de tipo por valor que no requiere inicializadores si todas las propiedades son públicas.
- **Seguridad en Concurrencia:** Debido a su naturaleza de valor, son más seguras para usarse en programación concurrente.

### Administración de Memoria y ARC

La administración de memoria es importante cuando trabajamos con clases porque son tipos de referencia. Swift utiliza ARC (Automatic Reference Counting) para manejar la memoria de las instancias de clase.

Con las estructuras (structs), cada vez que creas una nueva instancia, se hace una copia completa del valor, lo cual es eficiente y seguro en la mayoría de los casos. Sin embargo, las clases, al ser referencias al mismo objeto, necesitan una administración de memoria cuidadosa para evitar tener objetos "colgados" (sin ninguna flecha que apunte a ellos) o referencias cicladas (donde dos instancias se apuntan mutuamente, impidiendo ser liberadas).

Imagina que cada objeto es una caja en la memoria, y cada flecha que apunta a una caja es una variable que hace referencia a ese objeto. ARC cuenta cuántas flechas apuntan a una caja. Cuando ya no hay flechas apuntando a la caja, ARC se deshace automáticamente de la caja para liberar espacio.
 
 ![Gestión de la memoria de ARC](ARC.png)

Como programador, puedo eliminar esas flechas (variables) que apuntan a una caja (el slot de memoria) asignándole a la variable un valor nil si la variable es opcional. Si no es opcional, debo dejar que la función en la que vive esa variable finalice y entonces las flecha (variables) se eliminan automáticamente. Al eliminarse las flechas, ARC puede liberar la memoria de las cajas.
 
 ![Eliminación de variables](eliminacion.png)

*/
