//: [Previous](@previous)
//: # Funciones y Closures en Swift
/*:
## Índice
1. [Funciones como Closures](#1-Funciones-como-Closures)
2. [Sintaxis de las Closures](#2-Sintaxis-de-las-Closures)
3. [Closures como Parámetros](#3-Closures-como-Parámetros)
4. [Ejemplo de Uso Real](#4-Ejemplo-de-Uso-Real)

Las funciones y closures en Swift proporcionan una sintaxis poderosa y flexible que permite realizar operaciones muy versátiles de manera concisa.
 
 ![Closures](closure.png)

*/
//: ## 1. Funciones como Closures
/*:
En Swift, todas las funciones son closures. Esto significa que pueden guardarse en variables, listas, etc. La flexibilidad de esta característica permite ejecutar funciones de manera dinámica y ubicarlas en colecciones de datos.
*/
func add(a: Double, b: Double) -> Double {
    let result = a + b
    print("Add function executed with result: \(result)")
    return result
}

func mult(a: Double, b: Double) -> Double {
    let result = a * b
    print("Mult function executed with result: \(result)")
    return result
}

// Ejemplo de almacenamiento y ejecución de funciones en una lista
let funcs = [add, mult]
print(funcs)

let addFunction = add
addFunction(2, 2)

for function1 in funcs {
    function1(2, 3)
}
//: ## 2. Sintaxis de las Closures
/*:
La sintaxis de las closures puede variar desde una forma normal hasta una hiperreducida. A continuación, discutimos las diferentes formas en que se pueden definir closures.

### Sintaxis Normal
- **Llaves**: Indican que se inicia una closure.
- **Encabezado y `in`**: Separan la declaración de parámetros del cuerpo de la closure.
- **Cuerpo**: Define la lógica de la closure.
*/
let normal = { (n: Double, m: Double) -> Double in
    return n + m
}

// ### Una sola línea
let unaSolaLinea = { (n: Double, m: Double) -> Double in
    return n + m
}

// ### Return implícito
let returnImplícito = { (n: Double, m: Double) -> Double in
    n + m
}

// ### Tipo de retorno implícito
let tipoRetornoImplicito = { (n: Double, m: Double) in
    n + m
}

// ### Tipo de parámetros implícitos
let parametrosImplicitos: (Double, Double) -> Double = { a, b in
    return a + b
}

// ### Tipo de parámetros y retorno implícitos
let parametrosYRetornoImplicito: (Double, Double) -> Double = { a, b in
    a + b
}

// ### Sintaxis hiperreducida
let sintaxisHiperreducida: (Double, Double) -> Double = {
    $0 + $1
}

let numeros: [Double] = [1.5, 2.3, 5.5, 3.1, 0.7, 4.8]
let umbral: Double = 4.0

let numerosFiltrados = numeros.filter {
    $0 > umbral
}

let suma = numerosFiltrados.reduce(0.0, sintaxisHiperreducida)
print("La suma de los números filtrados es: \(suma)")
//: ## 3. Closures como Parámetros
/*:
Las closures pueden ser utilizadas como parámetros dentro de otras funciones, lo que permite encapsular operaciones en varias capas y customizables.
*/
func performSomeOperationWith(number1 n1: Double, andNumber2 n2: Double, closure: (Double, Double) -> Double) -> Double {
    print()
    print("Double n1 and n2")
    let doubleN1 = n1 * 2
    let doubleN2 = n2 * 2
    print("Before closure")
    let closureVal = closure(doubleN1, doubleN2)
    print("Closure val = \(closureVal)")
    print("After closure")
    return closureVal
}

// Utilización de la función con diferentes tipos de closures
let valueAfterOperation = performSomeOperationWith(number1: 2, andNumber2: 2, closure: { n1, n2 in
    return n1 + n2
})
print("Valor tras la operación: \(valueAfterOperation)")

let valueAfterClosureNormal = performSomeOperationWith(number1: 2, andNumber2: 2, closure: normal)
print("Valor de closure normal: \(valueAfterClosureNormal)")

let valueAfterUnaSolaLinea = performSomeOperationWith(number1: 2, andNumber2: 2, closure: unaSolaLinea)
print("Valor de closure una sola línea: \(valueAfterUnaSolaLinea)")

let valueAfterReturnImplícito = performSomeOperationWith(number1: 2, andNumber2: 2, closure: returnImplícito)
print("Valor con return implícito: \(valueAfterReturnImplícito)")

let valueAfterTipoRetornoImplicito = performSomeOperationWith(number1: 2, andNumber2: 2, closure: tipoRetornoImplicito)
print("Valor con tipo de retorno implícito: \(valueAfterTipoRetornoImplicito)")

let valueAfterParametrosYRetornoImplicito = performSomeOperationWith(number1: 2, andNumber2: 2, closure: parametrosYRetornoImplicito)
print("Valor con parámetros y tipo de retorno implícitos: \(valueAfterParametrosYRetornoImplicito)")

let valueAfterSintaxisHiperreducida = performSomeOperationWith(number1: 2, andNumber2: 2, closure: sintaxisHiperreducida)
print("Valor con sintaxis hiperreducida: \(valueAfterSintaxisHiperreducida)")

// Uso de `_trailing closure_`
let valueAfterOperation2 = performSomeOperationWith(number1: 2, andNumber2: 2) { a, b in
    a + b
}
//: ## 4. Ejemplo de Uso Real
/*:
Closures encuentran un uso intensivo en operaciones asíncronas y en funciones de manipulación de colecciones como `map`, `filter`, y `reduce`. También son esenciales en SwiftUI para definir vistas de manera declarativa.
*/
// MARK: Ejemplo "real" de uso con datos asíncronos
func storeData(_ data: String) {
    print("2. Storing data in keychain...")
    print("3. Stored data: \(data)")
}

func fetchData(forUser name: String, onComplete: (String) -> Void) {
    print()
    print("1. Fetching data for user \(name)")
    for second in 1...10 { print("----- \(second) seconds elapsed") }
    let fetchedData = "\(name) ID = 71927189"
    onComplete(fetchedData)
}

func storeDataForUser(name: String) {
    fetchData(forUser: name) { fetchedData in
        storeData(fetchedData)
    }
}

func main() {
    storeDataForUser(name: "Aroa")
}

main()
//: ### Nota
/*:
Más allá de las operaciones asíncronas, las closures son utilizadas para asegurar que la manipulación de datos se realice de manera controlada, evitando manipulación desordenada del flujo del programa.
*/
//: [Next](@next)
