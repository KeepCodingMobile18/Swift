//: [Previous](@previous)
//: # Introducción a Genéricos en Swift
/*:
## Índice
1. [Motivación para el Uso de Genéricos](#1-Motivación-para-el-Uso-de-Genéricos)
2. [Concepto de Genéricos](#2-Concepto-de-Genéricos)
3. [Función Genérica Simple](#3-Función-Genérica-Simple)
4. [Estructuras Genéricas](#4-Estructuras-Genéricas)
5. [Restricciones en los Tipos Genéricos](#5-Restricciones-en-los-Tipos-Genéricos)

Los genéricos en Swift nos permiten crear funciones y tipos que son reutilizables y flexibles al trabajar con cualquier tipo, sin perder la seguridad de tipos.
 
 ![Genéricos](generico.png)

*/
//: ## 1. Motivación para el Uso de Genéricos
/*:
Para un lenguaje de tipado estático como Swift, es común repetir código para funciones con diferentes tipos de datos. Por ejemplo, las siguientes funciones para sumar diferentes tipos son completamente distintas en Swift:
*/
func add(a: Int, b: Int) -> Int {
    return a + b
}

func add(a: Float, b: Float) -> Float {
    return a + b
}

func add(a: Double, b: Double) -> Double {
    return a + b
}

add(a: 12.1, b: 23.1)
/*:
Sin embargo, esta repetición va en contra del principio DRY (Don't Repeat Yourself). Está claro que debe haber una forma mejor.
*/
//: ## 2. Concepto de Genéricos
/*:
Los genéricos nos permiten definir plantillas de funciones o tipos que pueden trabajar con cualquier tipo de datos. En vez de copiar y pegar el código para cada tipo, el compilador lo hace por nosotros.

Por ejemplo, en tiempos antiguos se usaba una plantilla como la siguiente:
 
```swift
func add(a: TipoGenerico, b: TipoGenerico) -> TipoGenerico {
    return a + b
}
```

El compilador se encarga de "copiar y pegar" esta plantilla para cada tipo específico requerido.
*/
//: ## 3. Función Genérica Simple
/*:
Esta función genérica `printArrayElements` imprime todos los elementos de un array, independientemente del tipo de datos de estos elementos:
*/
func printArrayElements<T>(array: [T]) {
    for element in array {
        print(element)
    }
}

let intArray = [1, 2, 3, 4, 5]
let stringArray = ["manzana", "banana", "cereza"]

print("Int Array:")
printArrayElements(array: intArray)

print("\nString Array:")
printArrayElements(array: stringArray)
/*:
La función `printArrayElements` acepta un array de cualquier tipo `T` y recorre todos sus elementos para imprimirlos. Funciona con cualquier tipo de array, ya sea de enteros, cadenas o cualquier otro tipo.
*/
//: ## 4. Estructuras Genéricas
/*:
Las estructuras también pueden ser genéricas, y tanto las funciones como las estructuras pueden tener más de un tipo genérico.
### Ejemplo: Estructura `Pair`
*/
struct Pair<First, Second> {
    let first: First
    let second: Second
}

// Pareja de `String` y `[String]`
let p = Pair(first: "Names", second: ["Lucas", "Grijander", "Perico"])

// Pareja de dos funciones
let f = Pair(
    first: { (n: Double, m: Double) in n + m },
    second: { (x: Double, y: Double) in x * y }
)

f.first(4, 5)  // 9
f.second(2, 3) // 6
//: ## 5. Restricciones en los Tipos Genéricos
/*:
Hasta ahora, los tipos genéricos podían ser cualquier cosa. Sin embargo, en algunos casos, necesitamos que los tipos genéricos cumplan ciertos requisitos, como ser numéricos.

Esto se logra usando protocolos. Por ejemplo, `Numeric` se utiliza para contrar tipos numéricos:
*/
func mult<T: Numeric>(a: T, b: T) -> T {
    return a * b
}
//: [Next](@next)
