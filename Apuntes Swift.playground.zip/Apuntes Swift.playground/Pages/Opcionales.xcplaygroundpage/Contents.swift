//: [Previous](@previous)
//: # Opcionales
/*:
## Índice
1. [Introducción a Opcionales](#1-Introducción-a-Opcionales)
2. [Declaración de Opcionales](#2-Declaración-de-Opcionales)
3. [Desempaquetado de Opcionales](#3-Desempaquetado-de-Opcionales)
4. [Ejemplos de uso real: clasificación basada en BMI](#4-Ejemplos-de-Uso-Real)
5. [Ejemplos de uso real: conversión de Tipos](#4-Ejemplos-de-Uso-Real)

Los opcionales en Swift son una característica que permite manejar valores que podrían estar ausentes, lo que se materializa en que una variable puede ser de un tipo o `nil` (estar ausente).
 
 ![Optionals](optional.png)

*/
//: ## 1. Introducción a Opcionales
/*:
En Swift, los opcionales son tipos que pueden contener un valor o no contar con ninguno (`nil`). Este concepto es crucial para manejar situaciones donde un valor podría estar ausente.
*/
//: ## 2. Declaración de Opcionales
/*:
Veamos cómo declarar y trabajar con opcionales.
*/
let variableQueNoPuedeSerOpcional: Int = 20
let variableQuePuedeSerOpcional: Int? = nil
var variable2opcional: Int? = nil

print(variableQueNoPuedeSerOpcional) // Siempre contiene un valor
print(variableQuePuedeSerOpcional)   // Actualmente contiene nil
print(variable2opcional)             // Actualmente contiene nil

// Ejemplo de conversión
print("Número opcional aaa \(Int("aaaa"))") // Retorna nil
print("Número opcional 2 \(Int("2"))")     // Retorna 2 como un Int?
//: ## 3. Desempaquetado de Opcionales
/*:
Desempaquetar un opcional es extraer el valor contenido en él: dado que una variable opcional puede contener un valor o `nil`, tenemos que asegurarnos de qué es lo que contiene. Esto se llama desempaquetado o unwrap. Existen varias maneras de hacerlo:
*/
//:### 1. If Let
let optionalValue: String? = "Esto es un string"
if let optionalValueUnwrapped = optionalValue {
    // Aquí estamos seguros de que optionalValueUnwrapped tiene un valor
    print(optionalValueUnwrapped)
} else {
    print("El valor es nil")
}
//:### 2. Guard Let
func procesoConGuardLet(optionalText: String?) { // Escribimos una función porque el Playground no permite utilizar return sin una función
    guard let unwrappedText = optionalText else {
        print("El texto es nil")
        return
    }
    print("Texto no nulo: \(unwrappedText)")
}
procesoConGuardLet(optionalText: optionalValue)
//:### 3. Coalescing Operator ??
print(optionalValue ?? "Esto es nil")
//:### 4. Force Unwrapping (¡Usar con precaución!)
if optionalValue != nil {
    print(optionalValue!) // Solo debe usarse si estamos absolutamente seguros de que no es nil
}
//: ## 4. Ejemplos de uso real: clasificación basada en BMI
/*:
Aquí hay un ejemplo de una función que calcula el Índice de Masa Corporal (BMI) y devuelve un opcional.
*/
func bmi(weightInKg: Double, heightInCm: Double) -> Double? {
    guard heightInCm > 0 && weightInKg > 0 else {
        return nil
    }
    let heightInMeters = heightInCm / 100
    return weightInKg / (heightInMeters * heightInMeters)
}

if let bmiValue = bmi(weightInKg: 78, heightInCm: 165) {
    print("BMI calculado: \(bmiValue)")
} else {
    print("Datos de entrada no válidos para calcular el BMI.")
}
/*:
Utilizando enum para representar las diferentes categorías de BMI
*/
enum BodyMassIndex {
    case underweight
    case healthy
    case overweight
    case obese
    case invalid
}

// Clasificación usando una función basada en opcionales
func classify3(bmi: Double?) -> BodyMassIndex? {
    guard let actualBMI = bmi, actualBMI >= 0 else {
        return .invalid
    }
    
    switch actualBMI {
    case ..<18.5:
        return .underweight
    case 18.5..<24.9:
        return .healthy
    case 24.9..<29.9:
        return .overweight
    default:
        return .obese
    }
}

let classifiedBMI = classify3(bmi: 18.9)
if let bmiCategory = classifiedBMI {
    print("Categoría del BMI: \(bmiCategory)")
} else {
    print("BMI no válido.")
}
//: ## 5. Ejemplos de uso real: conversión de Tipos
/*:
Al igual que en Python, para convertir un tipo en otro, en Swift se **utiliza el nombre del tipo de destino como si fuera una función**.

Por ejemplo, para convertir algo en un `Int`, haríamos:
*/

print(Int("42") ?? "No convertible")   // Retorna 42
print(Int(78.222))                     // Retorna 78

// Si no se puede convertir, se devuelve `nil`.
print(Int("¡Fistro!") ?? "No convertible") // Retorna nil, "No convertible"

// Por lo tanto, el resultado de `Int("42")` es un `Int?`, no un `Int`.

/// **Ejemplo**
///
/// Crea la función `parseInt(input: String?, defaultValue: Int = 0)->Int`
/*:
Con el siguiente comportamiento:
1. Devuelve `defaultValue` si `input` es nil.
2. Devuelve `defaultValue` si `input` no se puede convertir a un entero.
3. Devuelve el valor convertido si `input` se puede convertir a entero.
*/
func parseInt(input: String?, defaultValue: Int = 0) -> Int {
    if let raw = input, let num = Int(raw) {
        return num
    } else {
        return defaultValue
    }
}

print(parseInt(input: "hola", defaultValue: 42)) // Devuelve 42
//: [Next](@next)
