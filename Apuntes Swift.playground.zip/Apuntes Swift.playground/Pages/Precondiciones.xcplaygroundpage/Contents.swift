//: [Previous](@previous)
//: # Precondiciones con guard y assert en Swift
/*:
## Índice
1. [Precondiciones y Guard](#1-Precondiciones-y-Guard)
2. [Uso de Guard](#2-Uso-de-Guard)
3. [Comparación entre Guard y If](#3-Comparación-entre-Guard-y-If)
4. [Assert en Swift](#4-Assert-en-Swift)

El uso de `guard` y `assert` en Swift permite manejar precondiciones de manera más estructurada y segura en el flujo de un programa.
 
 ![Precondiciones en Swift](precondiciones.png)

*/
//: ## 1. Precondiciones y Guard
/*:
`guard` es una forma flexible de comprobar condiciones al principio de una función y garantiza que el flujo no siga a no ser que se cumpla cierta condición.
*/
//: ## 2. Uso de Guard
/*:
La sintaxis de `guard` es clara y concisa. Se utiliza principalmente para verificar una condición y salir tempranamente de un bloque de código si la condición no se cumple.

### Sintaxis de guard
```
guard condición else {
    // Código que se ejecuta si la condición NO se cumple
    return // o throw, break, continue, etc.
}
// Código que se ejecuta si la condición SÍ se cumple
```
*/
func divide(_ numerator: Double, by denominator: Double) -> Double {
    // Usamos guard para asegurarnos de que el denominador no sea cero
    guard denominator != 0 else {
        print("El denominador no puede ser cero. Abandonando la operación.")
        return 0 // Elegimos un valor especial, como 0, para indicar fallo
    }
    
    return numerator / denominator
}

let result = divide(10, by: 0)
print("Resultado de la división: \(result)")
//: ## 3. Comparación entre Guard y If
/*:
A menudo, `guard` es comparado con `if` porque ambos verifican condiciones. Sin embargo, están diseñados para casos de uso ligeramente diferentes.

### Ejemplo usando `if`
```
if condición {
    // Código que se ejecuta si la condición SÍ se cumple
} else {
    // Código que se ejecuta si la condición NO se cumple
    return // o throw, break, continue, etc.
}
```

### Diferencia clave
- `guard` es más útil para condiciones de salida temprana, ya que permite que el código principal de la función sea de un solo nivel, sin anidamientos.
- `if` es más flexible y se usa cuando necesitas manejar ambas ramas de ejecución (si la condición es verdadera o falsa).
*/

func validateAndProcess(number: Int) {
    // Ejemplo usando if
    if number >= 0 {
        print("El número es válido: \(number)")
    } else {
        print("El número no es válido. Abandonando.")
        return
    }
    
    // Ejemplo usando guard
    guard number >= 0 else {
        print("El número no es válido. Abandonando.")
        return
    }
    print("El número es válido: \(number)")
}

validateAndProcess(number: 5)
validateAndProcess(number: -3)
//: ## 4. Assert en Swift
/*:
Similar a `guard`, los `asserts` también se pueden utilizar para verificar condiciones. Sin embargo, `assert` es utilizado principalmente durante el desarrollo y solo se evalúa en builds de depuración.
*/
func assertNonNegativeNumber(_ number: Int) {
    // Usamos assert para asegurarnos de que el número sea no negativo
    assert(number >= 0, "El número debe ser no negativo")
    print("El número es no negativo: \(number).")
}

assertNonNegativeNumber(5)
//assertNonNegativeNumber(-1) // Descomentar para probar el assert
//: [Next](@next)
