//: [Previous](@previous)
//: # Estructuras Condicionales en Swift
/*:
## Índice
* [Booleanos](#Booleanos)
* [If y Else](#If-y-Else)
* [Switch](#Switch)
* [Switch con Declaración de Variables](#Switch-con-Declaración-de-Variables)
* [Operador Ternario](#Operador-Ternario)


Las estructuras condicionales son esenciales para tomar decisiones en el flujo lógico de un programa. En Swift, podemos utilizar if, switch y operadores ternarios para manejar estas decisiones.
 
 ![Estructuras condicionales en Swift](ifs.png)
*/

//: ## Booleanos
/*: En Swift, al igual que en otros lenguajes de programación como Python, los booleanos representan valores de verdad con `true` y `false`.

Los operadores booleanos para combinar o invertir condiciones son los siguientes:
- `||` (or) - Retorna `true` si al menos una de las condiciones es verdadera.
- `&&` (and) - Retorna `true` solo si ambas condiciones son verdaderas.
- `!` (not) - Inversa el valor booleano.

Los booleanos se utilizan comúnmente en estructuras condicionales para la toma de decisiones en el flujo de control de un programa.
*/

let peso = 83.6
let edad = 32
let esMenorDeEdad = edad < 18
//: ## If y Else
/*:
La estructura `if` en Swift evalúa una condición y ejecuta un bloque de código si la condición es verdadera. Puedes usar `else if` y `else` para evaluar múltiples condiciones y definir bloques de código alternativos.
*/
if esMenorDeEdad && peso >= 100 {
    print("Mayor de edad y rellenito.")
} else if !esMenorDeEdad {
    print("Es menor de edad.")
} else {
    print("Todo lo demás.")
}
/*:
### Detalles
- La clave `if` comienza la estructura condicional.
- `else if` permite encadenar múltiples condiciones (no existe `elif` como en Python).
- `else` proporciona un bloque de código a ejecutar si ninguna de las condiciones anteriores se cumple.
- Los bloques de código se definen con llaves `{}`.
*/
//: ## Switch
/*:
El `switch` en Swift permite evaluar una variable contra múltiples valores posibles. Es más poderoso que en algunos otros lenguajes al soportar comparaciones avanzadas y rangos. Es la mejor opción cuando tienes que evaluar los Enums, que veremos más adelante.
*/
let calificación = 85

switch calificación {
case 90...100:
    print("Excelente")
case 80..<90:
    print("Muy Bueno")
case 70..<80:
    print("Bueno")
default:
    print("Necesita Mejorar")
}
/*:
### Detalles
- Cada `case` define un valor o rango de valores que se compara contra la variable.
- El `default` se usa para manejar cualquier caso que no haya coincidido con los anteriores.
- A diferencia de algunos lenguajes, los `switch` en Swift no necesitan `break` para finalizar cada caso.
*/
//: ## Switch con Declaración de Variables
/*:
Puedes usar el `switch` con la palabra clave `let` para declarar variables dentro de las condiciones, lo que te permite evaluar expresiones complejas directamente en los casos.
*/
func clasificarCalificación(_ nota: Int) -> String {
    switch nota {
    case let x where x < 50:
        return "Reprobado"
    case let x where x < 70:
        return "Aprobado"
    case let x where x < 90:
        return "Notable"
    default:
        return "Sobresaliente"
    }
}

let resultadoClasificado = clasificarCalificación(calificación)
print("Calificación: \(calificación) - Resultado: \(resultadoClasificado)")
/*:
Este ejemplo evalúa el valor `nota` con diferentes casos utilizando condiciones que involucran comparaciones dentro del propio `switch` lo que ofrece mayor flexibilidad.
*/
//: ## Operador Ternario
/*:
El operador ternario es una forma compacta de realizar una decisión basada en una condición. Es ideal para asignar valores simples basados en una condición.
*/
let resultado = esMenorDeEdad ? "Menor de edad" : "Mayor de edad"
print("El resultado es: \(resultado)")
/*:
### Detalles
- La sintaxis básica es `condición ? valor_si_verdadero : valor_si_falso`
- Es útil para asignaciones cortas y claras, pero su uso excesivo puede reducir la legibilidad del código.
- Es muy utilizado
*/
// [Next](@next)
