//: [Previous](@previous)
//: # Structs en Swift
/*:
## Índice
1. [Concepto de Objeto y POO](#1-Concepto-de-Objeto-y-POO)
2. [Introducción a Structs](#2-Introducción-a-Structs)
3. [Encapsulamiento](#3-Encapsulamiento)
4. [Ejemplos de Uso de Structs](#4-Ejemplos-de-Uso-de-Structs)

Los objetos en programación orientada a objetos (POO) nos permiten modelar entidades del mundo real o conceptos abstractos en nuestros programas. En Swift, las structs son uno de los bloques fundamentales para definir objetos.
 
 ![Structs](struct.png)

*/
//: ## 1. Concepto de Objeto y POO
/*:
### Qué representa
Un objeto representa una entidad autocontenida que combina **propiedades** (datos) y **métodos** (comportamiento).

### Qué hace
1. **Propiedades**: Son las variables almacenadas dentro de un objeto que representan el estado o la información del objeto.
2. **Funciones**: Son métodos que definen el comportamiento del objeto, permitiendo que los objetos interactúen con otros.

#### Ejemplos en Swift
*/
var numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
numbers.count
numbers.append(9)

let stringPrueba = "HOLAMUNDO"
_ = stringPrueba.first
//: ## 2. Introducción a Structs
/*:
Los structs en Swift son tipos de datos que permiten agrupar propiedades y funciones. Son tipos **de valor**, lo que significa que se copian cuando se asignan a una nueva variable o se pasan a una función.

### Inmutabilidad y Mutabilidad
- **Inmutabilidad**: Cuando un struct se declara con `let`, no se pueden modificar sus propiedades.
- **Mutabilidad**: Cuando un struct se declara con `var`, sí se pueden modificar sus propiedades.
 
### Ejemplo de Struct
*/
struct Employee {
    var name: String
    var ID: String
    var clockInMonthlyBalance: Int
    
    mutating func clockIn() {
        clockInMonthlyBalance += 10 // Simular que llega 10 segundos tarde
    }
}

var pedro: Employee = Employee(name: "Pedro", ID: "54856254", clockInMonthlyBalance: 0)
pedro.clockIn()
print(pedro.clockInMonthlyBalance)

var javi = Employee(name: "Javi", ID: "54898254", clockInMonthlyBalance: -100)
javi.clockIn()
print(javi.clockInMonthlyBalance)

let isma = Employee(name: "Isma", ID: "54898254", clockInMonthlyBalance: 20)
// isma.clockIn() // Esto produce un error porque con let no se pueden mutar los structs
//: ## 3. Encapsulamiento
/*:
El encapsulamiento es un principio de la POO que oculta los detalles internos de un objeto y solo expone los necesarios. Swift permite definir propiedades y métodos como `private` para aplicar encapsulamiento.
*/
struct Employee2firePrivado {
    var name: String
    let ID: String
    var clockInMonthlyBalance: Int
    
    private func fireEmployee() {
        print("You are fired!")
    }
    
    mutating func clockIn() {
        clockInMonthlyBalance += 10
        if clockInMonthlyBalance >= 1000 { fireEmployee() }
    }
}

var employee2FirePrivado = Employee2firePrivado(name: "aaa", ID: "aaaa", clockInMonthlyBalance: 10)
employee2FirePrivado.clockIn()
print(employee2FirePrivado.clockInMonthlyBalance)
//: ## 4. Ejemplos de Uso de Structs
/*:
Veamos cómo los structs pueden ser usados en diferentes contextos.
*/
struct Counter {
    private var value: Int

    init(value: Int) {
        self.value = value
    }
    
    var currentValue: Int {
        return value
    }

    mutating func increment() {
        value += 1
    }

    mutating func decrement() {
        value -= 1
    }
}

var correctAnswers = Counter(value: 0)
var incorrectAnswers = Counter(value: 0)

let responses = ["correct", "incorrect", "correct", "correct", "incorrect"]

for response in responses {
    if response == "correct" {
        correctAnswers.increment()
    } else if response == "incorrect" {
        incorrectAnswers.increment()
    }
}

print("Respuestas correctas: \(correctAnswers.currentValue)")
print("Respuestas incorrectas: \(incorrectAnswers.currentValue)")
//: [Next](@next)
