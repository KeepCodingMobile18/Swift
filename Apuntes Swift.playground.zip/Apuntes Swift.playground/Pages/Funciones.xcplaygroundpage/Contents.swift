//: [Previous](@previous)
//: # Funciones en Swift
/*:
## Índice
* [Definición y Sintaxis](#Definición-y-Sintaxis)
* [Nombres Descriptivos y Especificidad](#Nombres-Descriptivos-y-Especificidad)
* [Etiquetas de Parámetros](#Etiquetas-de-Parámetros)
* [Valores por Defecto](#Valores-por-Defecto)
* [Parámetros por Posición y por Nombre](#Parámetros-por-Posición-y-por-Nombre)
* [Funciones que No Devuelven Nada](#Funciones-que-No-Devuelven-Nada)

Las funciones en Swift son herramientas fundamentales para estructurar tu código de manera modular y reutilizable. Aunque son similares a las funciones en otros lenguajes, porque tienen que adaptarse a la rigidez del compilador y por ciertas funcionalidades extra para la nomenclatura.
 
 ![Funciones en Swift](funciones.png)

*/
//: ## Definición y Sintaxis
/*:
Las funciones en Swift se declaran usando la palabra clave `func`, y el cuerpo de la función está delimitado por llaves `{}`. Es importante especificar los tipos de datos de los parámetros y del valor de retorno.
*/
func maleBMI(weight: Double, height: Double) -> Double {
    let heightMeters = height / 100
    return weight / (heightMeters * heightMeters)
}

let bmi = maleBMI(weight: 83, height: 187)
print("BMI Calculado: \(bmi)")
/*:
### Detalles
1. **Palabra Clave**: Se utiliza `func` en lugar de `def` como en algunos otros lenguajes.
2. **Delimitación de Bloques**: Se usa `{}` para definir el ámbito, apoyado con un indentado opcional para mejorar la lectura.
3. **Tipos Obligatorios**: Debes especificar los tipos de parámetros y el tipo de retorno, lo que permite un código más seguro.
4. **Documentación**: Los comentarios se utilizan para explicar el propósito y funcionamiento del código.

### Buenas Prácticas:
- Utiliza nombres de funciones claros y descriptivos para mejorar la comprensión del código.
*/
//: ## Nombres Descriptivos y Especificidad
/*:
El lenguaje Swift fomenta el uso de nombres descriptivos para funciones y parámetros, asi se facilita la legibilidad y comprensión.
*/
func calculateMaleBMI(withWeightInKg: Double, andHeightInCm: Double) -> Double {
    let heightMeters = andHeightInCm / 100
    return withWeightInKg / (heightMeters * heightMeters)
}

let detailedBmi = calculateMaleBMI(withWeightInKg: 83, andHeightInCm: 187)
print("BMI Detallado: \(detailedBmi)")
/*:
#### Consejos:
- **Especificidad**: Usa nombres específicos para las etiquetas de los parámetros, como `weightInKg` y `heightInCm`.
- **Claridad**: Asegúrate que el nombre de la función y sus parámetros resulten en una lectura natural.
*/
//: ## Etiquetas de Parámetros
/*:
Swift permite definir etiquetas externas (marcadas en azul) e internas (en blanco) para los parámetros.
*/
func calculateBMI(forWeight weight: Double, andHeight height: Double) -> Double {
    let heightMeters = height / 100 // Aquí el programador usa height, no andHeight
    return weight / (heightMeters * heightMeters)
}

let meaningfulBmi = calculateBMI(forWeight: 83, andHeight: 187)
print("BMI Significativo: \(meaningfulBmi)")
/*:
- **Etiquetas Externas**: facilitan la comprensión cuando se llama a la función.
- **Etiquetas Internas**: permiten al programador usar el nombre de los parámetros como desee dentro de la función.
- **Ejemplo Claro**: `calculateBMI(forWeight: 83, andHeight: 187)` es autodescriptivo, mostrando claramente qué representan los valores.
*/
//: ## Valores por Defecto
/*:
Puedes definir valores por defecto para los parámetros en Swift con lo que puedes omitir su especificación durante la llamada.
*/
func fullName(firstName: String, lastName: String = "Targaryen") -> String {
    return "\(firstName) \(lastName)"
}

let defaultFullName = fullName(firstName: "Aemond")
let customFullName = fullName(firstName: "Manolo", lastName: "Escobar")
print("Nombre por Defecto: \(defaultFullName)")
print("Nombre Personalizado: \(customFullName)")
/*:
#### Consideraciones:
- **Flexibilidad**: los valores por defecto permiten el uso de funciones con menos argumentos si ciertas condiciones son universales o comunes.
*/
//: ## Parámetros por posición y por nombre
/*:
Swift ofrece flexibilidad en cómo se pueden pasar parámetros, aunque los diseñadores deben decidir esto al definir la función.
*/
func add(a: Int, b: Int) -> Int {
    return a + b
}

let sumByName = add(a: 3, b: 4)

// Versión por posición
func addByPosition(_ a: Int, _ b: Int) -> Int {
    return a + b
}

let sumByPosition = addByPosition(40, 2)
print("Suma por Nombre: \(sumByName)")
print("Suma por Posición: \(sumByPosition)")
/*:
#### Consejo:
- Decidir al momento de definir si los parámetros se pasarán por nombre o por posición puede influir en la claridad de las llamadas a esa función. Swift prefiere siempre pasar los parámetros por nombre y solo utilizar los parámetros por posición cuando mejora la legibilidad.
*/
//: ## Funciones que No Devuelven Nada
/*:
Las funciones que no devuelven un valor específico se declaran con `Void`, indicando que no habrá ningún dato de retorno.
*/
func bold(_ text: String) -> Void {
    print("**\(text)**")
}

bold("Swift")
/*:
- **Función de Ejemplo**: La función `bold` simplemente imprime el texto con un formato de markdown para negrita sin devolver un valor.
- **Declaración de `Void`**: Indica explícitamente que el retorno es irrelevante, aunque opcionalmente `-> Void` puede ser omitido.

### Nota:
- Swift utiliza `Void`, un alias de tipo para `()`, para indicar que no se espera un valor devuelto.
*/
// [Next](@next)
