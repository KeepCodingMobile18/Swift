//: [Previous](@previous)
//: # Bucles en Swift
/*:
## Índice
* [Secuencias Explícitas](#Secuencias-Explícitas)
* [Iteración](#Iteración)
* [Secuencias Implícitas](#Secuencias-Implícitas)
* [Bucle While](#Bucle-While)
* [Bucle Repeat-While](#Bucle-Repeat-While)
* [Bucle con Stride](#Bucle-con-Stride)

Los bucles en Swift son fundamentales para iterar sobre colecciones de datos y ejecutar bloques de código repetidamente. A continuación, se presentan las características específicas de los diferentes tipos de bucles en Swift.
 
 ![Bucles en Swift](bucles.png)

*/
//: ## Secuencias Explícitas
/*:
Las secuencias más comunes en Swift son las listas, similares a las de Python. Sin embargo, en Swift, las listas deben ser homogéneas, es decir, todos sus elementos deben ser del mismo tipo. Esto se ve en la hoja de Tipos de este Playground.
*/
let names = ["Anakin", "Han", "Leia", "Tarkin"] // Todos son cadenas
let weights = [82.1, 102, 78.9, 67]             // Todos son Doubles (incluso los enteros se convierten a Double)

// let nope = ["hola", 42, []] // No funciona por defecto, ya que mezcla tipos sin especificación.
/*:
### Detalles
1. **Homogeneidad**: Todos los elementos de la lista deben ser del mismo tipo.
2. **Conversión de Tipos**: Swift asegura que todos los elementos de una lista sean convertibles al tipo declarado.
*/
//: ## Iteración
/*:
La iteración en Swift se realiza de manera muy similar a Python, utilizando el bucle `for-in`.
*/
for name in names {
    print(name)
}

var total = 0
for element in weights {
    total += Int(element) // Conversión explícita a Int para manipulación exacta
}
print("Peso total: \(total)")
/*:
### Consideraciones
- **Simplicidad**: La sintaxis de Swift para iterar es sencilla y legible.
- **Conversión de Tipos**: Swift es estricto con los tipos.
*/
//: ## Secuencias Implícitas
/*:
En Swift, al igual que en Python, podemos utilizar rangos para crear secuencias que se evalúan de forma lazily (evaluadas sólo cuando se necesita).
*/
for each in 0...9 { // Incluye el 9
    print(each)
}
/*:
### Aspectos Importantes
- **Rangos**: Los rangos en Swift se crean usando el operador `...`.
- **Evaluación Lazy**: Similar a Python, permitiendo reducir el uso de memoria.
*/
//: ## Bucle While
/*:
Los bucles `while` en Swift son casi idénticos a los de Python, con la principal diferencia en la sintaxis de las llaves `{}`.
*/
var i = 0
let top = 9
var nums = ""

while i <= top {
    nums += "\(i)\n"
    i += 1
}

print(nums)
/*:
### Nota
- **Estructura**: Utiliza `{}` para delimitar el cuerpo del bucle en vez de utilizar indentación.
- **Control de Flujo**: `break` permite la salida abrupta del bucle. Cuando escribas un while **empieza por la condición que rompe el bloque**.
*/
//: ## Bucle Repeat-While
/*:
El bucle `repeat-while` en Swift asegura que el cuerpo del bucle se ejecute al menos una vez, ya que la condición se evalúa al final.
*/
var counter = 0
var numbers = ""

repeat {
    numbers += "\(counter)\n"
    counter += 1
} while counter <= top

print(numbers)
/*:
### Características
- **Ejecución Garantizada**: El cuerpo del bucle se ejecuta al menos una vez.
- **Condición Posterior**: Evaluación de la condición al final del bucle.
*/
//: ## Bucle con Stride
/*:
Utilizando `stride`, puedes crear bucles que tengan un incremento o decremento diferente a 1.
*/
for index in stride(from: 0, to: 10, by: 2) {
    print(index) // Imprime 0, 2, 4, 6, 8
}

for index in stride(from: 10, through: 0, by: -2) {
    print(index) // Imprime 10, 8, 6, 4, 2, 0
}
/*:
### Características Importantes
- **Incremento Personalizado**: `stride` permite definir un paso específico.
- **Inclusivo o Exclusivo**: Con `to`, el valor final es exclusivo (no se incluye), con `through`, el valor final es inclusivo.
*/
//: [Next](@next)
