//: [Previous](@previous)
//: # Enums en Swift
/*:
## Índice
* [Introducción a los Enums](#Introducción-a-los-Enums)
* [Enums con Valores Asociados](#Enums-con-Valores-Asociados)
* [Enums con Parámetros](#Enums-con-Parámetros)

En Swift, los enums (enumeraciones) permiten definir un tipo de datos que puede tener un conjunto de valores relacionados. Esto facilita el manejo de estados o condiciones predefinidas de una manera segura y explícita.
*/
//: ## Introducción a los Enums
/*:
Los enums permiten definir un conjunto de valores relacionados en Swift. Son particularmente útiles para modelar estados o categorías que no cambian.
 ![Enums en Swift](enum.png)

*/
enum EmailState {
    case addressUnknown
    case confirmed
    case notConfirmed
}

let emailState = EmailState.addressUnknown
if emailState == EmailState.confirmed {
    print("Email confirmed")
} else {
    print("Email not confirmed")
}
/*:
### Detalles
- Se define con la palabra clave `enum` seguida del nombre en PascalCase (primera con mayúscula).
- Los casos dentro del enum utilizan CamelCase y representan los valores posibles.
- Se utiliza para asegurar que una variable solo puede contener uno de un conjunto predefinido de valores.
*/
//: ## Enums con Valores asociados o Raw Values
/*:
Los enums pueden tener valores brutos (raw values), que son valores constantes predefinidos de un tipo específico para cada caso. Esto es útil cuando necesitas asociar un valor específico a cada caso del enum.
*/
enum Currency: String {
    case usd = "USD"
    case euro = "EURO"
}

let currency = Currency.euro
print(currency) // Imprime: euro
print(currency.rawValue) // Imprime: EURO
/*:
### Detalles
- Aquí, `Currency` toma valores crudos de tipo `String`.
- Cada caso del enum tiene un valor asociado (`rawValue`).
*/
//: ## Enums con Parámetros
/*:
Los enums también pueden contener parámetros, lo que permite pasar información adicional cuando se crea una instancia del enum. Esto es útil para representar errores o estados complejos.
*/
enum NumeroError: Error {
    case numeroNegativoError(errorNumber: Int)
    case cero(errorNumber: Int)
}
/*:
### Detalles
- Aquí `NumeroError` se utiliza para modelar errores que pueden incluir información detallada.
- Almacenan valores asociados, para que estos puedan ser modificados en lugar de ser escritos en el propio Enum.
*/
// [Next](@next)
