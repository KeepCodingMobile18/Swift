//: [Previous](@previous)
import Foundation
//: # Variables y Constantes en Swift
/*:
 ## Índice
 * [Variables](#Variables)
 * [Ejemplo de Variables](#Ejemplo-de-Variables)
 * [Constantes](#Constantes)
 * [Ejemplo de Constantes](#Ejemplo-de-Constantes)
 * [Buenas Prácticas](#Buenas-Pr%C3%A1cticas)

 En Swift, utilizamos variables y constantes para almacenar valores de diferentes tipos de datos. La principal diferencia entre ambas es que el valor de una constante no puede cambiar una vez establecido, mientras que el valor de una variable sí puede cambiar.
 
 ![Variables en Swift](variables.png)

*/
//: ## Variables
/*: Las variables se declaran con la palabra clave `var`. Una vez que se inicializa, puedes cambiar su valor en cualquier momento.
*/
//: ### Ejemplo de Variables
var saludo = "Hello, playground"
print(saludo) // Imprime: Hello, playground

// Cambiamos el valor de la variable
saludo = "Hello, hemos cambiado el saludo"
print(saludo) // Imprime: Hello, hemos cambiado el saludo
/*: En este ejemplo, `saludo` es una variable que inicialmente tiene el valor `"Hello, playground"`, pero luego se cambia a `"Hello, hemos cambiado el saludo"`.
*/
//: ## Constantes
/*: Las constantes se declaran con la palabra clave `let`. Una vez que una constante tiene un valor, no se puede cambiar.
*/
//: ### Ejemplo de Constantes
let saludoConstante = "Greeting constante"
print(saludoConstante) // Imprime: Greeting constante

// No se puede asignar un nuevo valor a una constante como saludoConstante, eso generaría un error.
// saludoConstante = "Otro saludo" // Descomenta esta línea para ver el error

// Si necesitas otro valor para la constante, puedes crear una nueva constante
let saludoConstante2 = "Cambiamos el valor del greeting Constante"
print(saludoConstante2) // Imprime: Cambiamos el valor del greeting Constante
/*: En este ejemplo, `saludoConstante` es una constante. Una vez asignado un valor, este no puede ser modificado, asegurándonos de que su valor se mantiene durante toda la ejecución del programa.
*/
//: ## Buenas Prácticas
/*:
- Usa `let` siempre que sepas que un valor no necesitará cambiar.
- Usa `var` cuando anticipes que el valor cambiará.
*/
//: [Next](@next)



