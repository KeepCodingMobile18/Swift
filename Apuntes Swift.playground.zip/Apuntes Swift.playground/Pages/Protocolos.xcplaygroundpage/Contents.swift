//: [Previous](@previous)
//: # Introducción a Protocolos en Swift
/*:
## Índice
1. [Concepto de Protocolos](#1-Concepto-de-Protocolos)
2. [Protocolos Comunes en Swift](#2-Protocolos-Comunes-en-Swift)
3. [Implementación de Protocolos](#3-Implementación-de-Protocolos)
4. [Ejemplos de Uso de Protocolos](#4-Ejemplos-de-Uso-de-Protocolos)

Los protocolos en Swift definen un conjunto de métodos, propiedades y otros requisitos que se pueden adoptar por una clase, estructura o enumeración para proporcionar una funcionalidad específica.
 
 ![Protocolos](protocol.png)

*/
//: ## 1. Concepto de Protocolos
/*:
Un protocolo en Swift es similar a una interfaz en otros lenguajes de programación. Define un plano de métodos y propiedades que un tipo debe implementar. Los protocolos no proporcionan implementaciones por sí mismos, sino que especifican qué debe implementarse.

### Ejemplo de un Protocolo
*/
protocol Increment {
    mutating func increment()
}

struct Counter: Increment {
    private var value: Int

    init(value: Int) {
        self.value = value
    }
    
    var currentValue: Int {
        return value
    }

    mutating func increment() {
        value += 1
    }

    mutating func decrement() {
        value -= 1
    }
}
//: ## 2. Protocolos Comunes en Swift
/*:
Swift incluye varios protocolos estándar que proporcionan funcionalidades esenciales:

- **Equatable**: Permite comparar instancias de un tipo para igualdad. Es fundamental para comparar tipos personalizados o definir si dos objetos son iguales.

- **Comparable**: Extiende `Equatable` y permite comparar instancias de un tipo para determinar su orden. Es útil para ordenar y organizar colecciones.

- **Hashable**: Permite que un tipo sea utilizado en una colección `Dictionary` o `Set`. Es esencial para tipos que necesitan una forma única de identificación.

- **Sequence**: Define un tipo que proporciona iteración secuencial sobre sus elementos. Es fundamental para trabajar con colecciones de datos.

- **Collection**: Extiende `Sequence` y agrega funcionalidades para trabajar con colecciones indexadas, como arrays y diccionarios.

- **Codable**: Combinación de `Decodable` y `Encodable`. Se utiliza para convertir tipos como estructuras y clases a y desde formatos de datos externos, como JSON.

- **CustomStringConvertible**: Permite a un tipo proporcionar su propia representación en forma de cadena. Es útil para imprimir descripciones legibles de instancias de tipos.

- **Delegate**: Aunque no es un protocolo oficial de Swift, el patrón de delegación es común en el desarrollo de iOS y macOS. Los protocolos de delegado son creados por los desarrolladores para definir un conjunto de métodos que un delegado puede implementar para actuar en nombre de otro objeto.
*/
//: ## 3. Implementación de Protocolos
/*:
Para implementar un protocolo, una clase, estructura o enumeración debe proporcionar una implementación para cada requisito del protocolo.
*/
struct EquatableCounter: Equatable {
    private var value: Int

    init(value: Int) {
        self.value = value
    }
    
    var currentValue: Int {
        return value
    }

    mutating func increment() {
        value += 1
    }

    mutating func decrement() {
        value -= 1
    }
}

let ec1 = EquatableCounter(value: 12)
let ec2 = EquatableCounter(value: 12)

if ec1 == ec2 {
    print("Son equivalentes")
} else {
    print("No son equivalentes")
}
//: ## 4. Ejemplos de Uso de Protocolos
/*:
Los protocolos se pueden utilizar para definir tipos personalizados que cumplen con ciertos criterios.

### Ejemplo de Protocolo Comparable
*/
struct MiTipo: Comparable {
    let value: String
    
    static func < (lhs: MiTipo, rhs: MiTipo) -> Bool {
        lhs.value.count < rhs.value.count
    }
}

let obj1 = MiTipo(value: "a")
let obj2 = MiTipo(value: "a")
print(obj1 == obj2)
//: [Next](@next)
