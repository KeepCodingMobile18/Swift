//: [Previous](@previous)
//: # Comentarios en Swift
/*:
 ## Índice
 * [Comentarios de una sola línea](#Comentarios-de-una-sola-línea)
 * [Comentarios de múltiples líneas](#Comentarios-de-múltiples-líneas)
 * [Comentarios anidados](#Comentarios-anidados)
 * [Comentarios de documentación](#Comentarios-de-documentación)

 Swift ofrece diferentes formas de añadir comentarios a tu código. Los comentarios no son procesados por el compilador y son útiles para explicar partes del código, dejar recordatorios, o deshabilitar temporalmente líneas de código.
 
 ![Comentarios en Swift](comentarios.png)

*/
//: ## Comentarios de una sola línea
/*:
 Se utilizan dos barras (`//`) para hacer comentarios de una sola línea:
*/
let saludo = "Hola, mundo" // Este es un comentario de una sola línea
//: ## Comentarios de múltiples líneas
/*:
 Para comentarios más largos que abarcan varias líneas, usa la combinación de barra y asterisco:
 */
/*
 Este es un comentario
 de múltiples líneas
 que abarca más de
 una línea.
*/
//: ## Comentarios anidados
/*:
Swift también permite comentarios anidados utilizando la misma notación de barra y asterisco que el comentario de múltiples líneas:
*/
/* Este es un comentario de múltiples líneas
    /* y este es un comentario anidado */
   fin del comentario múltiple */
//: ## Comentarios de documentación
/*:
Se utilizan tres barras (`///`) para crear comentarios de documentación. Estos son especialmente útiles para generar documentación automática utilizando herramientas externas:
*/
/// Esta función imprime un saludo en la consola
///
/// - Parameter nombre: El nombre de la persona a saludar
/// - Returns: Un mensaje de bienvenida
func saludar(nombre: String) -> String {
    return "Hola, \(nombre)!"
}
//: [Next](@next)
