//: [Previous](@previous)
//: # Manejo de Errores en Swift
/*:
## Índice
1. [Introducción a los Errores](#1-Introducción-a-los-Errores)
2. [Sintaxis de Manejo de Errores](#2-Sintaxis-de-Manejo-de-Errores)
3. [Propagación de Errores](#4-Propagación-de-Errores)
4. [Casos Especiales: `try?` y `try!`](#5-Casos-Especiales-try-y-try!)

En Swift, el manejo de errores nos permite responder y gestionar situaciones donde se debe realizar una recuperación de fallos de manera controlada y segura.
 
 ![Errores](error.png)

*/
//: ## 1. Introducción a los Errores
/*:
Los errores en Swift son valores que conforman el protocolo `Error`. Podemos definir nuestros propios errores creando un `enum` que adopta este protocolo.
*/
enum MyAppError: Error {
    case networkError
    case parsingError
    case unauthorizedAccess
    case invalidSize
}
//: ## 2. Sintaxis de Manejo de Errores
/*:
Para manejar errores, Swift nos ofrece un conjunto de palabras clave y estructuras: `throws`, `try`, `do`, `catch`.

- `throws` indica que una función puede lanzar un error.
- `try` se usa al llamar a una función que puede lanzar errores.
- `do-catch` permite capturar y manejar errores.
- ``throw`` permite lanzar un error.

### Ejemplo Simple:
*/
func checkSize(of input: String) throws -> Int {
    let size = input.count
    if size < 5 {
        throw MyAppError.invalidSize // Lanzamos un error si el tamaño es inválido
    }
    return size
}

do {
    let size = try checkSize(of: "12")
    print("Tamaño: \(size)")
} catch MyAppError.invalidSize {
    print("Ha ocurrido algún error de tamaño")
}
//: ## 3. Propagación de Errores
/*:
Los errores se propagan de manera automática en Swift. Esto significa que si un error no es capturado en el bloque actual, se propagará hacia el bloque de código superior hasta llegar a uno que lo maneje.
*/
enum NumeroError: Error {
    case numeroNegativoError(errorNumber: Int)
    case cero(errorNumber: Int)
}

func verificarNumeroPositivo(_ numero: Int) throws {
    if numero < 0 {
        throw NumeroError.numeroNegativoError(errorNumber: numero)
    } else if numero == 0 {
        throw NumeroError.cero(errorNumber: numero)
    }
}

func manejarNumero(numero: Int) {
    do {
        try verificarNumeroPositivo(numero)
        print("El número \(numero) es positivo.")
    } catch NumeroError.numeroNegativoError {
        print("Error: El número es negativo.")
    } catch NumeroError.cero(let numero) {
        print("Error: El número es cero con código de error \(numero).")
    } catch {
        print("Un error inesperado ocurrió: \(error).")
    }
}

manejarNumero(numero: 5)   // "El número 5 es positivo."
manejarNumero(numero: -3)  // "Error: El número es negativo."
manejarNumero(numero: 0)   // "Error: El número es cero con código de error 0"
//: ## 4. Casos Especiales: `try?` y `try!`
/*:
El uso de `try?` y `try!` permite manejar errores de forma simplificada.

- `try?` convierte una operación que puede generar un error en una que devuelve un `nil` si ocurre un error.
- `try!` fuerza la ejecución de una operación y provoca un crash si se produce un error. Debe usarse con precaución.

*/
var rc = try? checkSize(of: "uu")
// rc = try! checkSize(of: "iii") // ¡Usar con precaución!
//: [Next](@next)
