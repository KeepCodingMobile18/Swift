//: [Previous](@previous)
//: # Metodología de resolución de problemas
/*:
## Índice
1. [Definición y Comprensión del Problema](#1-Definición-y-Comprensión-del-Problema)
2. [Declaración de la Función](#2-Declaración-de-la-Función)
3. [Lógica de Resolución del Problema](#3-Lógica-de-Resolución-del-Problema)
4. [Codificación de la Solución](#4-Codificación-de-la-Solución)
5. [Pruebas de la Función](#5-Pruebas-de-la-Función)
6. [Problemas Detectados](#6-Problemas-Detectados)
7. [Refactorización](#7-Refactorización)
8. [Documentación de la Función](#8-Documentación-de-la-Función)

En cualquier lenguaje de programación es útil tener una serie de pasos que seguir a la hora de crear funciones. Aquí se presenta una metodología para mayor eficiencia en la resolución de problemas mediante un ejemplo:
 
 ![Metodología](metod.png)
 
 **Ejercicio 1: Crea la función `isPalindrome` que recibe una cadena y devuelve true si es un palíndromo y False si no.**
*/
//: ## 1. Definición y Comprensión del Problema
/*:
Un palíndromo es una palabra o frase que se lee igual de adelante hacia atrás y viceversa. Por ejemplo, "anilina" es un palíndromo.
*/
//: ## 2. Declaración de la Función
/*:
La función debe tener un nombre descriptivo y tipos de entrada y salida bien definidos:
- **Nombre de la Función**: `isPalindrome`
- **Entrada**: una cadena (`String`) que vamos a analizar.
- **Salida**: un valor booleano (`Bool`) indicando si la cadena es un palíndromo o no.
```Swift
func isPalindrome(_ word: String) -> Bool {
    // Lógica de verificación aquí
}
 ```
 */
//: ## 3. Lógica de Resolución del Problema
/*:
Hay múltiples enfoques para resolver este problema:

1. **Comparación de Caracteres**: Comparar cada carácter desde el inicio con el final.
2. **Inversión de la Cadena**: Invertir la cadena y verificar si coincide con la original.
*/
//: ## 4. Codificación de la Solución
/*:
La implementación de la función `isPalindrome` mediante comparación de caracteres:
*/
func isPalindrome(_ word: String) -> Bool {
    let characters = Array(word)
    
    var leftIndex = 0
    var lastIndex = characters.count - 1
    
    while leftIndex < lastIndex {
        if characters[leftIndex] != characters[lastIndex] {
            return false
        }
        leftIndex += 1
        lastIndex -= 1
    }
    
    return true
}
//: ## 5. Pruebas de la Función
/*:
Probaremos la función `isPalindrome` con varios casos:
*/
print(isPalindrome("agaegfawaa")) // false
print(isPalindrome("anilina")) // true
print(isPalindrome("reconocer")) // true
print(isPalindrome("hola")) // false
print(isPalindrome("A man a plan a canal Panama")) // true
print(isPalindrome("reConOcer")) // true
print(isPalindrome("")) // true
print(isPalindrome("a")) // true
//: ## 6. Problemas Detectados
/*:
Al probar, notamos que:
- El manejo de mayúsculas afecta la detección de palíndromos correctamente.
- El manejo de espacios también está provocando errores.
*/
//: ## 7. Refactorización
/*:
Refactorizamos la función para manejar mayúsculas y espacios adecuadamente:
*/
func isPalindromeRefactored(_ word: String) -> Bool {
    let characters = Array(word.lowercased().replacingOccurrences(of: " ", with: "")) // Aquí abordamos el problema
    
    var leftIndex = 0
    var lastIndex = characters.count - 1
    
    while leftIndex < lastIndex {
        if characters[leftIndex] != characters[lastIndex] {
            return false
        }
        leftIndex += 1
        lastIndex -= 1
    }
    
    return true
}
//: ## 8. Documentación de la Función
/*:
Es esencial documentar funciones para facilitar su comprensión y mantenimiento.

### `isPalindromeRefactored`
Verifica si la cadena proporcionada es un palíndromo.

- **Parámetro**: `word` - La cadena que va a ser comparada.
- **Devuelve**: `true` si la cadena es un palíndromo, `false` si no lo es.
*/
func isPalindromeRefactored2(_ word: String) -> Bool {
    let characters = Array(word.lowercased().replacingOccurrences(of: " ", with: ""))
    
    var leftIndex = 0
    var lastIndex = characters.count - 1
    
    while leftIndex < lastIndex {
        if characters[leftIndex] != characters[lastIndex] {
            return false
        }
        leftIndex += 1
        lastIndex -= 1
    }
    
    return true
}
// [Next](@next)
