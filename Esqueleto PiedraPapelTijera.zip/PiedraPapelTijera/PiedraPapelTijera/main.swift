//
//  main.swift
//  game
//
//  Created by Ismael Sabri Pérez on 1/9/24.
//

import Foundation

enum GameChoice {

}

func readUserChoice()  {
    // Este es un código de ejemplo para que veáis que readline funciona
    print("Escribe lo que quieras, a continuación, se imprimirá por pantalla")
    let line = readLine()
    print("Lo que has escrito es \(line)")
}

func isExit() {

}

func generateComputerChoice() {

}

func evaluateMove() {

}

func displayResult() {

}

func gameLoop() {
    readUserChoice()
}

func main() {
    gameLoop()
}



main()

