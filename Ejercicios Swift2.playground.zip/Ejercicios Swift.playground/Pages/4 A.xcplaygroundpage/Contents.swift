//: [Previous](@previous)

import Foundation

// MARK: Ejercicio de funciones 1
// Crea la función `isPalindrome` que recibe una cadena y devuelve true si es un palíndromo y False si no.

//: [Next](@next)
