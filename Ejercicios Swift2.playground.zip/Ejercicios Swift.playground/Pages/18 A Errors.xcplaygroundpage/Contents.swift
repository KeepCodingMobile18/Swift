//: [Previous](@previous)

import Foundation

// MARK: Ejercicio Errores 1: Lanzamiento y Captura de Errores Básicos
// Crea una función que lance un error si recibe un número negativo y luego escribe otra función para llamar a la primera y manejar el error.
enum NumeroError: String, Error {
    case numeroNegativoError = "El numero es negativo"
    case cero = "El numero es cero"
}

// Función que lanza un error si recibe un número negativo
func verificarNumeroPositivo(_ numero: Int) throws {
    if numero < 0 {
        // Si el número es negativo, lanzamos un error
        throw NumeroError.numeroNegativoError
    } else if numero == 0 {
        throw NumeroError.cero
    }
}

// Función que llama a 'verificarNumeroPositivo' y maneja el error
func manejarNumero(numero: Int) {
    do {
        // Intentamos verificar el número
        try verificarNumeroPositivo(numero)
        print("El número \(numero) es positivo.")
    } catch NumeroError.numeroNegativoError {
        // Manejamos el caso donde el número es negativo
        print("Error: El número es negativo.")
    } catch let error as NumeroError {
        print("Error: \(error.rawValue)")
    } catch {
        // Cualquier otro error
        print("Un error inesperado ocurrió: \(error).")
    }
}



// Caso 1: Número positivo
manejarNumero(numero: 5)
// Debería imprimir: "El número 5 es positivo."

// Caso 2: Número negativo
manejarNumero(numero: -3)
// Debería imprimir: "Error: El número es negativo."

// Caso 3: Número cero (consideramos cero como no negativo)
manejarNumero(numero: 0)
// Debería imprimir: "Error: El número es cero."

// MARK: Ejercicio Errores 2: Propagación de Errores
// Escribe una función que puede lanzar un error, y otra que llame a esta función usando `try` y propague el error a su llamante.

// Definimos un enumerado para el error de división
enum DivisionError: Error {
    case divisionPorCero
}

// Función que realiza una división y puede lanzar un error
func dividir(_ dividendo: Double, entre divisor: Double) throws -> Double {
    // Comprueba si el divisor es cero para lanzar un error
    if divisor == 0 {
        throw DivisionError.divisionPorCero
    }
    // Si no hay error, retorna el resultado de la división
    return dividendo / divisor
}

// Función que llama a 'dividir' y propaga el error
func calcularDivision(dividendo: Double, divisor: Double) throws {
    // Aquí estamos intentando llamar a 'dividir' y podremos atrapar el error donde se llame a 'calcularDivision'
    let resultado = try dividir(dividendo, entre: divisor)
    print("Resultado de la división: \(resultado)")
}

do {
    // Caso: División con divisor no cero (sin error)
    try calcularDivision(dividendo: 10, divisor: 2)
    // Debería imprimir: "Resultado de la división: 5.0"
} catch DivisionError.divisionPorCero {
    print("Error: Intento de dividir por cero.")
} catch {
    print("Un error inesperado ocurrió: \(error).")
}

do {
    // Caso: División con divisor cero (con error)
    try calcularDivision(dividendo: 10, divisor: 0)
    // No se imprimirá el resultado porque causará un error.
} catch DivisionError.divisionPorCero {
    // Este mensaje debería ser impreso
    print("Error: Intento de dividir por cero.")
} catch {
    print("Un error inesperado ocurrió: \(error).")
}


// MARK: Ejercicio Errores 3: Uso de `try?` y `try!`
// Modifica el ejercicio anterior para usar `try?` y `try!` explicando la diferencia entre ambos.

// Definimos un error para la conversión fallida
enum ConversionError: Error {
    case conversionFallida
}

// Función que intenta convertir una cadena a Int
func convertirACadenaANumero(_ cadena: String) throws -> Int {
    guard let numero = Int(cadena) else {
        // Lanza un error si la conversión falla
        throw ConversionError.conversionFallida
    }
    return numero
}

// Uso de `try?`: convierte cualquier error a un valor opcional
func usarTryConInterrogacion() {
    let numeroOpcional = try? convertirACadenaANumero("123a") // Esto fallará
    if let numero = numeroOpcional {
        print("Conversión exitosa: \(numero)")
    } else {
        print("La conversión falló y devolvió nil.")
    }
}

// Uso de `try!`: asume que no ocurrirá un error
func usarTryConExclamacion() {
    let numero = try! convertirACadenaANumero("456") // Esto es seguro
    print("Conversión exitosa: \(numero)") // Debería imprimir el número convertido
    // Si 'convertirACadenaANumero' fallara, generaría un crash en tiempo de ejecución
}

usarTryConInterrogacion()
usarTryConExclamacion()

// MARK: Ejercicio Errores 4: Manejo de Errores con Opcionales
// Crea una función que retorne un valor opcional, y usa la gestión de errores para manejar los casos en que el opcional sea `nil`. Usa `guard`.



//: [Next](@next)
