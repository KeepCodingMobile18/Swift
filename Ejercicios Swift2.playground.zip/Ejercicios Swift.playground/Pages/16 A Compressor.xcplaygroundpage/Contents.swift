//: [Previous](@previous)

import Foundation

// MARK: Ejercicio closures compressor 1
//  Crea la función `sumAll` que recibe un array de enteros y devuelve su suma. Usa un bucle for. ¿Qué debe de devolver cuando el array está vacío?
func sumAll(sequence: [Int]) -> Int {
    var total = 0
    for number in sequence{
        total = total + number
    }
    return total
}

// MARK: Ejercicio closures compressor 2
// Crea la función `multiplyAll` que recibe un Array de enteros y devuelve su producto. ¿Qué debe de devolver si el array está vacío?
func multiplyAll(sequence: [Int])-> Int{
    var total = 1
    for number in sequence{
        total = total * number
    }
    return total
}

// MARK: Ejercicio closures compressor 3
// Crea la función `compress`. Esta función se va a encargar de recibir un array con un tipo y reducirlo a un solo elemento del mismo tipo. Como lo único que cambia es el valor inicial y la operación de combinación, vamos a meterle eso como parámetros:
// func compress(sequence: [Int],
//                  initialValue: Int,
//                  operación:  (Int, Int)->Int
//                  ) -> Int
typealias IntCombiner = (Int, Int) -> Int // Este typealias se usa mucho con closures, sirve para sustituir al tipo, es puramente visual

func compress(sequence: [Int],
              initialValue: Int,
              combinationOperation: IntCombiner) -> Int{
    
    var accum = initialValue // Los parámetros se pasan como let, no se pueden modificar y necesitamos hacerlo dentro de la función
    for number in sequence{
        accum = combinationOperation(accum, number)
    }
    return accum
}

// MARK: Ejercicio closures compressor 4
// Usa la función compress para resolver los dos problemas de arriba (el 1 y el 2).
// Utiliza los diferentes tipos de sintaxis de las closures

let sumNormal = compress(sequence: [1,2,3,4],
                   initialValue: 0,
                   combinationOperation: { (accum: Int, number: Int) -> Int in
                       return accum + number
                   })
print("Suma con syntax normal = \(sumNormal)")
/// Suma con sintaxis de return implicito
let sumReturnImplicito = compress(sequence: [1,2,3,4],
                   initialValue: 0,
                   combinationOperation: { (accum: Int, number: Int) -> Int in accum + number })
print("Suma con return implícito = \(sumReturnImplicito)")
/// Suma con sintaxis de tipo de retorno implicito
let sumTipoRetornoImplicito = compress(sequence: [1,2,3,4],
                   initialValue: 0,
                   combinationOperation: { (accum, number) in accum + number })
print("Suma con tipo de retorno implícito = \(sumTipoRetornoImplicito)")
/// Suma con sintaxis hiperreducida
let sumHiperreducida = compress(sequence: [1,2,3,4],
         initialValue: 0,
         combinationOperation: {$0 + $1})
print("Suma con closure hiperreducida = \(sumHiperreducida)")

/// Multiplicacione con sintaxis normal
let multipNormal = compress(sequence: [1,2,3,4],
                            initialValue: 1,
                            combinationOperation: { (accum: Int, number: Int) -> Int in
                                return accum * number
                            })
print("Multiplicación con syntax normal = \(multipNormal)")
/// Multiplicación con sintaxis de return implícito
let multipReturnImplicito = compress(sequence: [1,2,3,4],
                                     initialValue: 1,
                                     combinationOperation: { (accum: Int, number: Int) -> Int in accum * number })
print("Multiplicación con return implícito = \(multipReturnImplicito)")
/// Multipllicación con sintaxis de tipo de retorno implícito
let multipTipoRetornoImplicito = compress(sequence: [1,2,3,4],
                                          initialValue: 1,
                                          combinationOperation: { (accum, number) in accum * number })
print("Multiplicación con tipo de retorno implícito = \(multipTipoRetornoImplicito)")
/// Multiplicación con sintaxis hiperreducida
let multipHiperreducida = compress(sequence: [1,2,3,4],
         initialValue: 1,
         combinationOperation: {$0 * $1})
print("Multiplicación con closure hiperreducida = \(multipHiperreducida)")

// MARK: Ejercicio closures compressor 5
// Obtén la suma de todos los elementos pares

// Solución Javier -> el primer número es el accum, esto funciona porque accum (num1) siempre es par
let resultMulti = compress(sequence: [1, 2, 3, 4, 5, 6], initialValue: 0) { num1, num2 in
    switch (num1 % 2 == 0, num2 % 2 == 0) {
    case (true, true):    // Si pares
        return num1 + num2
    case (true, false):   // Si 1 par
        return num1
    case (false, true):   // Si 2 par
        return num2
    default:              // Ninguno es par
        return 0
    }
}
print("Suma de números pares solución 2 = \(resultMulti)")

// Solución Hernán
let resultHernan = compress(sequence: [1,2,3,4,5,6], initialValue: 0) { num1, num2 in
    if (num2 % 2 == 0) {
        return num1 + num2
    }
    return num1
}

print("Suma de números pares solución 2 = \(resultHernan)")

// Solución Isma
let sumaPares = compress(sequence: [1,2,3,4,5,6], initialValue: 0) { accum, num in
    if num % 2 == 0 { return accum + num }
    else { return accum }
}

// Obtén la suma de todos los elementos pares menos la suma de los elementos impares

// Solución Hernán
let resultHernan2 = compress(sequence: [1,2,3,4,5,6], initialValue: 0) { num1, num2 in
    if (num2 % 2 == 0) {
        return num1 + num2
    }
    return num1 - num2
}

// Obtén el elemento máximo
// Solución Isma
let maxElement = compress(sequence: [1, 2, 3, 4, 5], initialValue: Int.min) {
    max($0, $1)
}
print("Elemento máximo = \(maxElement)")

// Solución Hernán
compress(sequence: [1,2,3,4,5,6], initialValue: Int.min) { num1, num2 in
    if (num2 > num1) {
        return num2
    }
    return num1
}
// Obtén el elemento mínimo
compress(sequence: [1,2,3,4,5,6], initialValue: Int.max) { num1, num2 in
    if (num2 > num1) {
        return num1
    }
    return num2
}
let minElement = compress(sequence: [1, 2, 3, 4, 5], initialValue: Int.max) {
    min($0, $1)
}
print("Elemento mínimo = \(minElement)")

// Obtén la cantidad de elementos positivos
let positiveCount = compress(sequence: [-1, 2, 3, -4, 5], initialValue: 0) {
    $0 + ($1 > 0 ? 1 : 0) // Vamos sumando uno cada vez que el elemento es positivo
}
print("Cantidad de elementos positivos = \(positiveCount)")

// MARK: Ejercicio closures compressor 6
// Crea la función `allEvens` que recibe una lista de enteros y devuelve true si todos son pares. ¿Qué devuelve si está vacío? Usa compress

// MARK: Ejercicio closures compressor 7
// Crea la función `allMultiplesOfThree` que recibe una lista de enteros y devuelve true si todos son múltiplos de 3. ¿Qué devuelve si el array está vacío? Usa compress

// MARK: Ejercicio closures compressor 8
// Crea la función `sumAllEvensAndOdds` que recibe un array de enteros y devuelve una tupla con la suma de los pares y la suma de los impares. ¿Puedes hacerlo usando compress?

// MARK: Ejercicio closures compressor 9
// Modifica `compress` para que no necesite el valor inicial.

// MARK: Ejercicio closures compressor2 10
// Modifica `compress` para que reciba como último parámetro una *clausura de finalización*.Se trata de una clausura que no recibe nada y no devuelve nada (a esa clausuraa veces se le llama un *thunk*, pregúntale a Grokk el origen de esa palabreja). Se va a usar para encapsular una tarea que se llevará a cabo pasado un tiempo, en concreto, cunado `compress` haya terminado.

// MARK: Ejercicio closures compressor2 11
//  Calcular la suma de los cuadrados de la secuencia y una vez terminado imprimir en pantalla un aviso de que se terminó. Usa compress2

// Calcula la suma de los elementos que son multiplos de 3 y cunado termine y pasados 4 segundos, imprime en pantalla la frase "¡Mamá, terminé!". Usa compress2

// MARK: Ejercicio closures compressor3 12
// Modifica de nuevo `compress` para que la *clausura de finalización* recibe como parámetro un entero, que es el resultado de la compresión.

// MARK: Ejercicio closures compressor3 13
// Calcula el producto de los cuadrados todos los elementos impares y usa la clausura de finalización para imprimir un mensaje con el resultado pasados 2 segundos.

//  Calcula la suma de los elementos divisibles por 3 y usa la *clausura de finalización* para imprimir un mensaje con el resultado pasados tantos segundos como el resultado dividido por 2.

//: [Next](@next)
