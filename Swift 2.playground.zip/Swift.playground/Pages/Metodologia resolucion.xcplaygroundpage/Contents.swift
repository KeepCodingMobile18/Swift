//: [Previous](@previous)

import Foundation

// MARK: Metodología de resolución
// Ejercicio 1: Crea la función `isPalindrome` que recibe una cadena y devuelve true si es un palíndromo y False si no.

// 1. Definir y entender el problema: "lcggcl" -> es un palíndromo

// 2. Declarar la función
// 2.1. Nombre de la función: isPalindrome
// 2.2. Entrada de la función: el string que vayamos a analizar -> "lcggcl"
// 2.3  Salida de la función: el booleano que nos va a decir si es o no es un palíndromo -> bool
// isPalindrome(word: String) -> Bool { }

// 3. Lógica de resolución del problema
// 3.1 Comparar letra por letra desde el inicio hasta el final: "lcggcl" -> l con l, c con c...
// 3.2. Invertir la palabra y ver si coincide con la palabra inicial: "lcpgal" == "lagpcl" ??
// 3. ....

// 4. Codificar la solución



func isPalindrome(_ word: String) -> Bool {
    // Comparar letra por letra desde el inicio hasta el final: "lcggcl" -> l con l, c con c...
    let characters = Array(word.lowercased().replacingOccurrences(of: " ", with: "")) // amanaplanacanalpanama
    
    
    var leftIndex = 0
    var lastIndex = characters.count - 1
    
    while leftIndex < lastIndex {
        if characters[leftIndex] != characters[lastIndex] {
            return false
        }
        // Actualizar los índices
        leftIndex += 1
        lastIndex -= 1
    }
    
    return true
}

// 5. Probar la función
print(isPalindrome("agaegfawaa")) // false
print(isPalindrome("anilina")) // true
print(isPalindrome("reconocer")) // true
print(isPalindrome("hola")) // false
print(isPalindrome("A man a plan a canal Panama")) // true
print(isPalindrome("reConOcer")) // true
print(isPalindrome("")) // true
print(isPalindrome("a")) // true

// 6. Problemas
// Las mayúsculas y minúsculas están siendo tenidas en cuenta
// agaegfawaa está dando true porque la primera y última letra son iguales
// A man a plan a canal Panama HAY ALGÚn problema

// 7. Refactorizar la función para resolver los problemas del punto 6 -> punto 4

func isPalindrome2(_ word: String) -> Bool {
    return word == String(word.reversed())
}

func test_whenEvenPalindrome_isTrue(word: String) {
    assert(isPalindrome2(word) == true, "The test \(#function) failed: the palindrome lcggcl is actually a palindrome")
}

test_whenEvenPalindrome_isTrue(word: "lcggcl")

// 8. Documentar

/// Verifica si la cadena es un palíndromo
/// - Parameter:
///     - word: la cadena que va a ser compararda
/// - Returns: `true` si es un palíndromo y `false` si no.
///
/// Notas cosas diferentes
func isPalindrome3(_ word: String) -> Bool {
    // Comparar letra por letra desde el inicio hasta el final: "lcggcl" -> l con l, c con c...
    let characters = Array(word.lowercased().replacingOccurrences(of: " ", with: "")) // amanaplanacanalpanama
    
    
    var leftIndex = 0
    var lastIndex = characters.count - 1
    
    while leftIndex < lastIndex {
        if characters[leftIndex] != characters[lastIndex] {
            return false
        }
        // Actualizar los índices
        leftIndex += 1
        lastIndex -= 1
    }
    
    return true
}

isPalindrome3(<#T##word: String##String#>)

//: [Next](@next)
