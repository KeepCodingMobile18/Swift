import Cocoa

/*
 ____  _          _               ____                  _
|  _ \(_) ___  __| |_ __ __ _    |  _ \ __ _ _ __   ___| |
| |_) | |/ _ \/ _` | '__/ _` |   | |_) / _` | '_ \ / _ \ |
|  __/| |  __/ (_| | | | (_| |_  |  __/ (_| | |_) |  __/ |_
|_|   |_|\___|\__,_|_|  \__,_( ) |_|   \__,_| .__/ \___|_( )
                             |/             |_|          |/
 _____ _  _
|_   _(_)(_) ___ _ __ __ _
  | | | || |/ _ \ '__/ _` |
  | | | || |  __/ | | (_| |
  |_| |_|/ |\___|_|  \__,_|
       |__/

 */
/// Vamos a estudiar cositas básicas del lenguaje Swift creando el juego de piedra papel y tijera.

/// 1. Repasa las reglas de juego (si hace falta :-))
/// 2. Vamos a crear una app de linea de comandos macOS (vamos a jugar directamente en la consola)
/// 3. Implementa un enum GameChoice con los casos posibles
/// 4. Crea las funciones`gameLoop`, `readUserChoice`, `isExit`,
///  `generateComputerChoice`, `evaluateMove` y
///  `printResult` vacías, si acaso con un valor de retorno cualquiera para
///  que el compilador se calle.
/// 5.¿Cómo arranca?
/// 6. La función principal del juego va a ser `gameLoop`
/// 7. Repasa las funciones y su declaración.
/// - ¿Qué información necesitas para trabajar dentro de cada función?
/// - ¿Qué debería devolver cada función para ser útil?,¿algo, nada?
/// - Ten en cuenta que una de las ideas por detrás del tipado de Swift es que te aporte más información a ti, el programador.
/// 8. Crea la función `gameLoop` en la que tendrás que ir llamando a las demás funciones.
/// 8.1 Ver bucles en playground para planificar el 8.
/// 9. Crea la función `readUserChoice`
/// 9.1. Implementación ingenua de `readUserChoice`. 
/// 9.2 Vete a `readLine  y Opcionales`, leélo y piensa cómo podría usarse en readUserChoice.
/// 9.3. Comienza a implementar la función `readUserChoice`. Si necesitas tratar un valor opcional, ¡llámame!
/// Después de la explicación para tratar valores opcionales, deberías ser capaz de continuar la implementación de `readUserChoice`.
/// Impleméntala, puede que necesites convertir tipos para hacerlo (si lo necesitas, `conversión de tipos`)
/// 10. Implementar `isExit`.
/// 11. Implementar `generateComputerChoice`. Vamos a necesitar números aleatorios`
/// 12. Implementa `evaluateMove`
/// 13. Implementa `printResult`
///
///
/// FIN DEL EJERCICIO
///
