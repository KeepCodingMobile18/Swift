//: [Previous](@previous)

import Foundation

/*
 ______               _ _     _
 | ___ \             | | |   (_)
 | |_/ /___  __ _  __| | |    _ _ __   ___
 |    // _ \/ _` |/ _` | |   | | '_ \ / _ \
 | |\ \  __/ (_| | (_| | |___| | | | |  __/
 \_| \_\___|\__,_|\__,_\_____/_|_| |_|\___|

 */

///
/// En Python, tenemos la función ``input`` que lee lo que escribe el usuario y nos lo devuelve convertido a una cadena.
/// En todos los lenguajes, existe algo parecido y por supuesto en Swift también, pero hay algunas diferencias sutiles.
/// En Swift, tenemos la función `readLine` que cumple  las mismas funciones.

let k = readLine()

///
/// DIFERENCIAS
///
/// 1. Recibe un parámetro booleano, pero no es para imprimir un mensaje para el usuario. Es para limpiar la cadena que haya proporcionado el
/// usuario de potenciales caracteres "chorras" y de retornos de carro. Por defecto, la función hace esta limpieza.
/// 2. No devuelve una cadena `String` sino algo  que parece una cadena `String?`, un String opcional.


/*
 _____            _                   _
|  _  |          (_)                 | |
| | | |_ __   ___ _  ___  _ __   __ _| | ___  ___
| | | | '_ \ / __| |/ _ \| '_ \ / _` | |/ _ \/ __|
\ \_/ / |_) | (__| | (_) | | | | (_| | |  __/\__ \
 \___/| .__/ \___|_|\___/|_| |_|\__,_|_|\___||___/
      | |
      |_|  

 */

/// En Python habíamos visto que se podían crear tipos "or", que con una combinación de dos (o más) tipos. Por ejemplo, algo podía ser
/// un `int` o un `float`. A esto se le llamaba "Tipos Algebraicos" y habíamos dicho que estaba muy de moda, y que se usaba en Swift.
///
/// En Python, esa combinación se hacía de la siguiente manera:
/// `num = int | float`
///
/// Existe un tipo de "Tipo Algebraico" (combinación de tipos mediante un _or_) que es tan común, que tiene un nombre propio.
/// Es la combinación de **algo o bien la nada**. Por ejemplo, una función puede devolver `str | NoneType` (recuerda `None` es
/// el valor único del tipo `NoneType`.
///
/// Viene a decir que  **o devuelve una cadena o no devuelve nada**.
///
/// Esa combinación de **algo o nada**, se le llama **OPCIONAL**, y es muy importante en Swift.
///
///          Python                      Swift
///          ===================================
/// Nada            `None`                                                  `nil`
/// int opcional   `int | NoneType`                           `Int?`
///

let maybeName: String?  // String Opcional: talvez contenga un nombre
let maybeAge: Int?      // Entero Opcional: quizás tenga un entero con la edad, o talvez no, quien sabe...

///  **FUNCIONES PARCIALES**
///
/// Los opcionales son una herramienta interesante para modelar *funciones parciales* (aunque no la mejor).
/// Por ejemplo, la función para calcular el índice de masa corporal que recibe el peso en kilos y la altura en cm.
///

func bmi(weightInKg: Double, heightInCm: Double) -> Double{
    let h = heightInCm / 100
    return (weightInKg / (h * h))
}

bmi(weightInKg: 82, heightInCm: 187)

/// Esta es una implementación algo simple, puesto que no comprueba si los valores que se les pasa
/// son razonables o no. Por ejemplo, si le paso un valor negativo, lo usa sin pensarlo, a pesar de ser una tontería.

bmi(weightInKg: 78, heightInCm: -169)

/// Hay dos tipos de errores posibles en nuestra función:
///
/// * Valor matemáticamente imposible: <= 0
/// * Valor fisiológicamente imposible: fuera de los rangos de peso y altura de un humano
///
/// En ambos casos se trata de **Errores de Dominio**, es decir, más o menos predecibles y que no deberían de hacer
/// que nuestro software se caiga: hay que gestionarlos.
///
/// Por sencillez, nos vamos a centrar únicamente en el primer caso: nos pasan valores iguales o menores que cero, y
/// sólo lo vamos a hacer con la altura.
///
/// ** EN PYTHON**
///
/// Una forma sencilla de hacerlo en Python sería comprobar el valor de la altura y si está fuera del rango admisible.
/// lanzar una excepción.
///
/// ** EN SWIFT **
///
/// Aunque en Swift también se pueden lanzar excepciones, y se hace, hay más posibilidades. Una de ellas, es usar los *Opcionales*.
///
/// En vez de devolver un `Double`, vamos a devolver un `Double?`:
/// * Si la altura es mayor que cero, devolvemos el `Double`
/// * Sino, devolvemos `nil` para indicar que algo ha salido mal.
///

func bmi2(weightInKg: Double, heightInCm: Double) -> Double? {
    var result: Double?  // Si no le asigno un valor, por defcto vale nil
    if heightInCm >= 0 {
        let h = heightInCm / 100
        result = (weightInKg / (h * h))
    }
    
    return result
}

/// Comprueba que la función es correcta y funciona como se espera.
///
/// Ahora hagamos lo mismo para el peso:

func bmi3(weightInKg: Double, heightInCm: Double)->Double?{
    var result: Double?  // Si no le asigno un valor, por defcto vale nil
    if heightInCm >= 0 && weightInKg >= 0{
        let h = heightInCm / 100
        result = (weightInKg / (h * h))
    }
    
    return result
}
/// Comprueba que la función es correcta y funciona como se espera.
///

bmi3(weightInKg: -89, heightInCm: 176)

/// **CONCLUSIONES**
///
/// 1. Si algo sale mal, me entero (puesto que devuelve `nil`) pero no sé exactamene lo que ha pasado
/// (talvez haya sido el peso o talvez la altura).
/// 2. Puesto que no devuelve un `Double` sino un `Double?`, que es algo así como una enum de un número y un nil, habrá que
/// saber cómo manejar valores del tipo opcional (opcionales II)
///


//: [Next](@next)
