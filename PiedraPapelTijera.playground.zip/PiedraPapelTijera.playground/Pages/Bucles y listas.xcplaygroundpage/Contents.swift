//: [Previous](@previous)

/*
 _        ___     _ _
 \ \      / / |__ (_) | ___
  \ \ /\ / /| '_ \| | |/ _ \
   \ V  V / | | | | | |  __/
    \_/\_/  |_| |_|_|_|\___|

 */

/// WHILE
print("While Loop")
///
/// Los bucles while de swift son exactamente iguales a los de Python. Sólo cambia las llaves en vez del indentado
/// Para salir de forma brusca tambien tenemos a `break`

var i = 0
let top = 9
var nums = ""

while i <= top{
    nums = nums + String(i) + "\n"
    i += 1
}

print(nums)
print()

/*
 _____
|  ___|__  _ __
| |_ / _ \| '__|
|  _| (_) | |
|_|  \___/|_|

 */

print("For Loop")
/// La secuencia más común es la lista y son muy parecidas a las de Python. La única diferencia es que tienen que ser
/// *homogeneas*. Es decir, todos los elementos del mimso tipo:

let names = ["Anakin", "Han", "Leia", "Tarkin"] // todo cadenas
let weights = [82.1, 102, 78.9, 67]             // todo doubles (incluso los enteros, que se convierten)

/// Se hace igual que en Python

print("Names")
for name in names{
    print(name)
}
print()

print("Total Elements")
var total = 0
for element in weights{
    total = total + Int(element)
}
print(total)
print()


///Al igual que en Python se usan los rangos para crear cosas que parecen una lista, pero que se evalúan
///de forma perezosa (sólo cuando hace falta).
///
///Los rangos se crean con el operador ...
///

print("Numbers from 0 to 9")
for each in 0...9 { // hasta el 9 incluido
    print(each)
}
print()

//: [Next](@next)
