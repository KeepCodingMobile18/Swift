/*
     _    _            _             _
    / \  | | ___  __ _| |_ ___  _ __(_) ___  ___
   / _ \ | |/ _ \/ _` | __/ _ \| '__| |/ _ \/ __|
  / ___ \| |  __/ (_| | || (_) | |  | | (_) \__ \
 /_/   \_\_|\___|\__,_|\__\___/|_|  |_|\___/|___/

 */

/// **SELECCIÓN AL AZAR**
///
/// En Python tenemos una función llamada `choice` que recibe una secuencia, como por ejemplo una
/// lista, y te devuelve un elemento al azar dentro de ella.
///
/// En Swift no existe eso (aunque lo vas a crear más adelante), pero en todos los lenguajes existen mecanismos
/// para generar números aleatorios. Es algo muy importante en muchas areas, especialmente en criptografía.
///
/// **NÚMEROS ALEATORIOS**
///
/// Para generar un entero aleatorio dentro de un cierto rango, haríamos lo siguiente:
///
Int.random(in: 1...42) // de 1 a 42, ambos incluidos
Int.random(in: 1..<4)  // de 1 a 3

/// Para un Double, sería algo parecido
///
Double.random(in: 1.5...1.99)
