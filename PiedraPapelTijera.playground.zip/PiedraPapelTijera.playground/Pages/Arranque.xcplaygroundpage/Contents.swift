//: [Previous](@previous)

/*
   / \   _ __ _ __ __ _ _ __   __ _ _   _  ___
  / _ \ | '__| '__/ _` | '_ \ / _` | | | |/ _ \
 / ___ \| |  | | | (_| | | | | (_| | |_| |  __/
/_/   \_\_|  |_|  \__,_|_| |_|\__, |\__,_|\___|
                                 |_|
 */

/// En Python, los ficheros se podían leer de dos formas, cunado se importa y cuando se ejecutan.
/// Por eso teníamos que saber en qué caso estábamos, y si es en el segundo, llamar a la función
/// que pone en marcha nuestro programa.
///
/// Era un poco confuso y había que usar algo que parecía un poco magia negra:
///
/// if __name__ == "__main__":
///     game_loop()
///
/// En Swift, NO hace falta esto y la regla es más sencilla:
/// 1. Si hay un fichero llamado `main`, ese es el principal y se ejecuta.
/// 2. Si sólo hay uno, pues será ese el principal y se ejecuta
/// 3. En cualquier caso, como estamos usando un playground, para ejecutar la función main tendremos que llamarla.
///
/// De momento, crea una función `main`y dentro de ella llama a `gameLoop`.
///

//: [Next](@next)
