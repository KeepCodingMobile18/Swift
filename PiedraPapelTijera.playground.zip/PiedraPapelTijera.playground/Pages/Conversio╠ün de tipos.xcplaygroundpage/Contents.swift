//: [Previous](@previous)

import Foundation

/*
 _____                               _
/  __ \                             (_)
| /  \/ ___  _ ____   _____ _ __ ___ _  ___  _ __
| |    / _ \| '_ \ \ / / _ \ '__/ __| |/ _ \| '_ \
| \__/\ (_) | | | \ V /  __/ |  \__ \ | (_) | | | |
 \____/\___/|_| |_|\_/ \___|_|  |___/_|\___/|_| |_|
                                                   
*/

///
///Al igual que en Python, para convertir un tipo en otro, en Swift se **utiliza el nombre del tipo de destino como si fuera una función**.
///
///Por ejemplo, para convertir algo en un `Int`, haríamos:
///
Int("42")
Int(78.222)

/// Si se ha podido, se devuelve el valor convertido al tipo de destino. ¿Pero y si no funciona?
/// Si no funciona, se devuelve `nil`.
///
Int("¡Fistro!")

/// Es decir, lo que devuelve `Int(42)` no es un `Int`, sino un `Int?`

/// **EJERCICIO**
///
/// Crea la función `parseInt(input: String?, defaultValue: Int = 0)->Int`
/// 1. Tiene dos parámetros. El primero es lo que tenemos que convertir a entero. El segundo, es un valor por defecto que se usará si algo sale mal
/// 2. Si `input` es nil, se devuelve `defaultValue`
/// 3. Si `ìnput` no se puede convertir en un entero, se devuelve el valor `defaultValue`
/// 4. Si `input`se puede convertir en entero, se devuelve el valor convertido
///
/// Para facilitar tu vida, Swift te permite tener variso `let` dentro de un if, para ir desempaquetando
/// opcionales por pasos. El if sólo será verdadero, si todos los desempaquetados son correctos!
func parseInt(input: String?, defaultValue: Int = 0)->Int{
    let result : Int
    if let raw = input,
        let num = Int(raw){
        result = num
    }else{
        result =  defaultValue
    }
    return result
    
}

parseInt(input: "hola", defaultValue: 42)


/// **ENUMS**
///
/// Las `enum`s son un tipo más, así que esto también funciona con ellas, cunado tienen un tipo
/// asociado.
///
/// Por ejemplo, aquí tienes una enum que representa a variso servicios comunes en internet
/// con su puerto por defecto asociado. Si no sabe slo que es esto, pregúntale a Grokk
///
enum NetworkPort: Int {
    case FTPData = 20
    case FTPControl = 21
    case SSH = 22
    case Telnet = 23
    case SMTP = 25
    case DNS = 53
    case HTTP = 80
    case POP3 = 110
    case IMAP = 143
    case HTTPS = 443
}

// Uso:
let portValue = NetworkPort.HTTP.rawValue
print("El puerto para HTTP es \(portValue)")  // Output: El puerto para HTTP es 80


/// **CONCLUSIÓN**
///
/// 1. Para convertir tipos, usamo sel tipo de destino como si fuese una función.
/// 2. A esa *función* se le llama un **constructor** del tipo de destino.
/// 3. El constructor devuelve un tipo de destino opcional. Si salió bien, devuelve el tipo y sino, un nil.
///
//: [Next](@next)

