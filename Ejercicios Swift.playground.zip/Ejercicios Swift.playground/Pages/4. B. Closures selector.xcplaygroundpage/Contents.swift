//: [Previous](@previous)

import Foundation


print()
print("-----------------------------------------------")
print("------------------Ejercicio 1------------------")
print("-----------------------------------------------")
print()

// MARK: Ejercicio 1
/// Crea la función `startWithVowels` que recibe un Array de cadenas y devuelve un array con aquellas cadenas que empiezan por una vocal.
/// Asegúrate de que funciona tanto con mayúsuculas como minúsculas. Puedes ignorar los caracteres acentuados.

func startWithVowels(strings: [String])->[String]{
    
    let vowels : Set<Character> = ["a", "e", "i", "o", "u"]
                        
    var selected : [String] = []
    
    for current in strings{
        if let firstChar = current.first {
            let normalizedChar = firstChar.lowercased()
            if vowels.contains(normalizedChar) {
                selected.append(current)
            }
        }
    }
    return selected
}

print("Palabras que empiezan por vocal en el array [hola, andres, Alba, Gustavo] \(startWithVowels(strings: ["", "hola", "andres", "Alba", "Gustavo"]))")




print()
print("-----------------------------------------------")
print("------------------Ejercicio 2------------------")
print("-----------------------------------------------")
print()

// MARK: Ejercicio 2
/// Crea la función `longerThan` que recibe un array de cadenas y un entero. Devuelve un array de cadenas cuya longitud es mayor que el entero recibido.

func longerThan(strings: [String], length: Int) -> [String] {
    var selected: [String] = []
    
    for current in strings {
        if current.count > length {
            selected.append(current)
        }
    }
    return selected
}

// Comprobación de la función
let result = longerThan(strings: ["hola", "andres", "Alba", "Gustavo"], length: 4)
print("Palabras cuya longitud es mayor que 4 en el array [hola, andres, Alba, Gustavo]: \(result)")




print()
print("-----------------------------------------------")
print("------------------Ejercicio 3------------------")
print("-----------------------------------------------")
print()

// MARK: Ejercicio 3
/// Crea la función `select(sequence:[String], predicate: (String) -> Bool) -> [String]` que recibe una secuencia de cadenas y un predicado,
/// devolviendo una lista de cadenas que cumplen con el predicado.

func select(sequence: [String],
            predicate: (String) -> Bool) -> [String] {
    
    var accum : [String] = []
    for element in sequence{
        if predicate(element){
            accum.append(element)
        }
    }
    return accum
}

/// Usa `select` para seleccionar las cadenas que tengan una longitud mayor que 5
let strings = ["hola", "mundo", "tengo una longitud más larga", "Rigoberto"]

func longerThanFive(text: String) -> Bool{
    return text.count > 5
}
select(sequence: strings,
       predicate: longerThanFive)




print()
print("-----------------------------------------------")
print("------------------Ejercicio 4------------------")
print("-----------------------------------------------")
print()

// MARK: Ejercicio 4
/// Usa `select` para seleccionar las cadenas que tengan una longitud mayor que 4

let longerThan4CharsWords = select(
    sequence: ["", "hola", "andres", "Alba", "Gustavo"]) { current in
        return current.count > 4
    }

print("Palabras cuya longitud es mayor que 4 en el array [hola, andres, Alba, Gustavo] con select \(longerThan4CharsWords)")




print()
print("-----------------------------------------------")
print("------------------Ejercicio 5------------------")
print("-----------------------------------------------")
print()

// MARK: Ejercicio 5
/// Usa `select` para resolver los ejercicios 1 y 2

let startingWithVowelsWords = select(
    sequence: ["", "hola", "andres", "Alba", "Gustavo"]) { current in
        let vowels : Set<Character> = ["a", "e", "i", "o", "u"]
        if let firstChar = current.first {
            let normalizedChar = firstChar.lowercased()
            return vowels.contains(normalizedChar)
        }
        return false
    }

print("Palabras que empiezan por vocal en el array [hola, andres, Alba, Gustavo] con select \(startingWithVowelsWords)")

let longerThan4CharsWords2 = select(
    sequence: ["", "hola", "andres", "Alba", "Gustavo"]) { current in
        return current.count > 4
    }

print("Palabras cuya longitud es mayor que 4 en el array [hola, andres, Alba, Gustavo] con select \(longerThan4CharsWords2)")




print()
print("-----------------------------------------------")
print("------------------Ejercicio 6------------------")
print("-----------------------------------------------")
print()

// MARK: Ejercicio 6
/// Modifica `select` para que al igual que `compress` reciba como último parámetro una clausura de finalización que a su vez recibe el resultado de `select`

func select2(sequence: [String],
            predicate: (String) -> Bool,
             completion: ([String]) -> Void) -> [String] {
    
    var accum : [String] = []
    for element in sequence{
        if predicate(element){
            accum.append(element)
        }
    }
    completion(accum)
    return accum
}




print()
print("-----------------------------------------------")
print("------------------Ejercicio 7------------------")
print("-----------------------------------------------")
print()

// MARK: Ejercicio 7
/// Devuelve el array de aquellas cadenas que están en mayúsculas e imprime el resultado pasados 3 segundos con el siguiente texto:
/// "Las cadenas que estaban en mayúsculas eran:" y entonces imprime cada una de ellas en una línea, en minúsculas.

// Predicado para verificar si una cadena está en mayúsculas
let isUppercase: (String) -> Bool = { $0.allSatisfy { $0.isUppercase } } // Mira en el array de chars si todas son uppercase

// Uso de la función select2
let wordsInMayusc = select2(
    sequence: ["HOLA", "andres", "ALBA", "GUSTAVO"],
    predicate: isUppercase,
    completion: { uppercaseWords in
        // Esperar 3 segundos antes de imprimir
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            print("Las cadenas que estaban en mayúsculas eran:")
            for word in uppercaseWords {
                print(word.lowercased()) // Imprimir en minúsculas
            }
        }
    }
)

//: [Next](@next)
