import SwiftUI

// MARK: Ejercicio 1 -> imports 
// Importa los módulos adecuados para que el programa funcione. Busca en google las librerías que contienen las funciones que hacen gritar al compilador.
print("-----------------------------------------------")
print("------------------Ejercicio 1------------------")
print("-----------------------------------------------")
print()
// Intentamos usar funciones y tipos que requieren librerías específicas

// 1. Crear un número aleatorio
let numeroAleatorio = Int.random(in: 1...100) // Error: 'random' no está definido

// 2. Crear una fecha actual
let fechaActual = Date() // Error: 'Date' no está definido

// 3. Texto simple para mostrar en SwiftUI
let mensaje = Text("Hola, Mundo!") // Error: 'Text' no está definido

// 4. Realizar una operación matemática
let resultado = pow(2, 3) // Error: 'pow' no está definido

// 5. Crear un arreglo y ordenarlo
var numeros = [5, 3, 1, 4, 2]
let numerosOrdenados = numeros.sorted() // Error: 'sorted' no está definido

// 6. Crear un temporizador con Combine
let timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { timer in
    print("¡Un segundo ha pasado!") // Error: 'Timer' no está definido
}
