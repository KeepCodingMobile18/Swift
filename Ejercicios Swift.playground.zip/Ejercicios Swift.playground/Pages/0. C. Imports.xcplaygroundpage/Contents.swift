//: [Previous](@previous)
import Foundation

// MARK: Ejercicio 1 -> imports
print("-----------------------------------------------")
print("------------------Ejercicio 1------------------")
print("-----------------------------------------------")
print()
// Importa los módulos adecuados para que el programa funcione. Busca en google las librerías que contienen las funciones que hacen gritar al compilador.

// 1. Crear un temporizador utilizando Combine
let timer = Timer.publish(every: 1.0, on: .main, in: .common).autoconnect() // Ahora definido correctamente

// 2. Uso de Combine para una suscripción
let cancellable = timer.sink { _ in
    print("Timer activated!") // Ahora definido correctamente
}

// 3. Crear un array de números y calcular la suma
let numeros = [1, 2, 3, 4, 5]
let suma = numeros.reduce(0, +) // Ahora definido correctamente
print("La suma es: \(suma)") // Muestra la suma

//: [Next](@next)
