//: [Previous](@previous)

import Foundation

print()
print("-----------------------------------------------")
print("------------------Ejercicio 1------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 1 -> Struct
// Diseña una estructura `Vehiculo` con propiedades para `marca`, `modelo` y `año`. Añade una propiedad computada `descripcion` que devuelva una cadena con toda la información del vehículo.

struct Vehiculo {
    var marca: String
    var modelo: String
    var año: Int
    
    var descripcion: String {
        return "\(marca) \(modelo) (\(año))"
    }
}

// Ejemplo de uso
let vehiculo = Vehiculo(marca: "Toyota", modelo: "Corolla", año: 2020)
print(vehiculo.descripcion) // Imprime: Toyota Corolla (2020)




print()
print("-----------------------------------------------")
print("------------------Ejercicio 2------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 2 -> Struct
// Diseña una estructura `Estudiante` con propiedades para `nombre`, `apellido` y un array de `calificaciones`. Incluye una propiedad computada `promedio` que calcule el promedio de las calificaciones. Incluye un método para añadir una calificación (un Double).


struct Estudiante {
    var nombre: String
    var apellido: String
    var calificaciones: [Double]
    
    var promedio: Double {
//        return calificaciones.reduce(0) { accum, nextResult in
//            accum + nextResult
//        } / Double(calificaciones.count)
        return calificaciones.reduce(0, +) / Double(calificaciones.count)    }
    
    mutating func añadirCalificacion(_ calificacion: Double) {
        calificaciones.append(calificacion)
    }
}

// Ejemplo de uso
var estudiante = Estudiante(nombre: "Juan", apellido: "Pérez", calificaciones: [4.0, 3.5, 4.5])
estudiante.añadirCalificacion(5.0)
print(estudiante.promedio) // Imprime: 4.25



print()
print("-----------------------------------------------")
print("------------------Ejercicio 3------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 3 -> Struct
// Crea una estructura `Rectangulo` con propiedades para `ancho` y `alto`. Añade un método que calcule el área del rectángulo.

struct Rectangulo {
    var ancho: Double
    var alto: Double
    
    func area() -> Double {
        return ancho * alto
    }
}

// Ejemplo de uso
let rectangulo = Rectangulo(ancho: 5.0, alto: 3.0)
print(rectangulo.area()) // Imprime: 15.0



print()
print("-----------------------------------------------")
print("------------------Ejercicio 4------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 4 -> Struct
// Crea una estructura `CuentaBancaria` con propiedades `titular` (String) y `saldo` (Double). Añade métodos para depositar y retirar dinero.

struct CuentaBancaria {
    var titular: String
    private(set) var saldo: Double // Explicar este private set, solo se puede leer desde fuera. Nunca setear, por eso se reserva set para dentro de la función, set es privado
    
    mutating func depositar(_ cantidad: Double) {
        saldo += cantidad
    }
    
    mutating func retirar(_ cantidad: Double) {
        if cantidad <= saldo {
            saldo -= cantidad
        } else {
            print("Fondos insuficientes para retirar \(cantidad)")
        }
    }
}

// Ejemplo de uso
var cuenta = CuentaBancaria(titular: "Ana", saldo: 1000.0)
cuenta.depositar(200.0)
cuenta.retirar(50.0)
print(cuenta.saldo) // Imprime: 1150.0. Aquí es importante que puedo leerla desde fuera! private(set)



print()
print("-----------------------------------------------")
print("------------------Ejercicio 5------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 5 -> Struct
// Crea una estructura `Libro` con propiedades para `titulo`, `autores` y `año de publicación`. Añade una propiedad computada que devuelva una descripción del libro. Usa un typeAlias para `Autor`.

typealias Autor = String

struct Libro {
    var titulo: String
    var autores: [Autor]
    var añoPublicacion: Int
    
    var descripcion: String {
        return "\(titulo) por \(autores.joined(separator: ", ")) (\(añoPublicacion))"
    }
}

// Ejemplo de uso
let libro = Libro(titulo: "Cien Años de Soledad", autores: ["Gabriel García Márquez"], añoPublicacion: 1967)
print(libro.descripcion) // Imprime: Cien Años de Soledad por Gabriel García Márquez (1967)



print()
print("-----------------------------------------------")
print("------------------Ejercicio 6------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 6 -> Struct
// Diseña una estructura `ReproductorMusica` con un array de canciones (cada canción es una estructura con título y artista). Incluye métodos para reproducir, pausar y cambiar a la siguiente canción.

struct Cancion {
    var titulo: String
    var artista: String
}

struct ReproductorMusica {
    var canciones: [Cancion]
    private var indiceCancionActual: Int = 0
    private var reproduciendo: Bool = false
    
    init(canciones: [Cancion]) {
        self.canciones = canciones
    }
    
    mutating func reproducir() {
        reproduciendo = true
        let cancionActual = canciones[indiceCancionActual]
        print("Reproduciendo \(cancionActual.titulo) de \(cancionActual.artista)")
    }
    
    mutating func pausar() {
        reproduciendo = false
        print("Pausado")
    }
    
    mutating func siguienteCancion() {
        indiceCancionActual = (indiceCancionActual + 1) % canciones.count // % canciones.count garantiza que se vuelva al inicio después de terminar la lista
        if reproduciendo {
            reproducir()
        }
    }
}

// Ejemplo de uso
let canciones = [Cancion(titulo: "Song 1", artista: "Artist 1"), Cancion(titulo: "Song 2", artista: "Artist 2")]
var reproductor = ReproductorMusica(canciones: canciones)
reproductor.reproducir()
reproductor.siguienteCancion()



print()
print("-----------------------------------------------")
print("------------------Ejercicio 7------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 7 -> Struct
// Crea una estructura `ConversorTemperatura` con una propiedad `celsius`. Añade propiedades computadas para obtener la temperatura en Fahrenheit y Kelvin.

struct ConversorTemperatura {
    var celsius: Double
    
    var fahrenheit: Double {
        return celsius * 9/5 + 32
    }
    
    var kelvin: Double {
        return celsius + 273.15
    }
}

// Ejemplo de uso
let conversor = ConversorTemperatura(celsius: 25.0)
print(conversor.fahrenheit) // Imprime: 77.0
print(conversor.kelvin)     // Imprime: 298.15


        
    
    //: [Next](@next)
