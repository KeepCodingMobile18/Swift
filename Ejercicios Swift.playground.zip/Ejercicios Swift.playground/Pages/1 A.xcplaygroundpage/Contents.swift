//: [Previous](@previous)

import Foundation

// MARK: Ejercicio declaración de variables y cambios 1
// Declarar una variable, cambiar su valor y mostrar los resultados en la consola.

// MARK: Ejercicio de uso de constantes 1
// Declarar una constante y demostrar que no puede ser modificada después de la inicialización.


//: [Next](@next)
