//: [Previous](@previous)

import Foundation

// MARK: Ejercicio Errores 1: Lanzamiento y Captura de Errores Básicos
// Crea una función que lance un error si recibe un número negativo y luego escribe otra función para llamar a la primera y manejar el error.


// MARK: Ejercicio Errores 2: Propagación de Errores
// Escribe una función que puede lanzar un error, y otra que llame a esta función usando `try` y propague el error a su llamante.


// MARK: Ejercicio Errores 3: Uso de `try?` y `try!`
// Modifica el ejercicio anterior para usar `try?` y `try!` explicando la diferencia entre ambos.


// MARK: Ejercicio Errores 4: Manejo de Errores con Opcionales
// Crea una función que retorne un valor opcional, y usa la gestión de errores para manejar los casos en que el opcional sea `nil`. Usa `guard`.

//: [Next](@next)
