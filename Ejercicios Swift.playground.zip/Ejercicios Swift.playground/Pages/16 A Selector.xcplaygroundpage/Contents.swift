//: [Previous](@previous)

import Foundation

// MARK: Ejercicio 1
/// Crea la función `startWithVowels` que recibe un Array de cadenas y devuelve un array con aquellas cadenas que empiezan por una vocal. Asegúrate de que funciona tanto con mayúsuculas como minúsculas. Puedes ignorar los caracteres acentuados

// MARK: Ejercicio 2
// Crea la función `longerThan` que recibe un array de cadenas y un entero. Devuelve un array de cadenas cuya longitud es mayor que el entero recibido.

// MARK: Ejercicio select  3
// Crea la función
// ```
// select(sequence:[String],
//         predicate: (String) -> Bool) -> [String]
// ```

// MARK: Ejercicio select  4
// Usa `select` para seleccionar las cadenas que tengan una longitud mayor que 5

// MARK: Ejercicio select  5
// Usa `select` para resolver los ejercicios 1 y 2

// MARK: Ejercicio select  6
/// Modifica `select` para que al igual que `compress` reciba como último parámetro una clasura de finalización que a su vez recibe el resultado de `select`

// MARK: Ejercicio select 7
// Devuelve el array de aquellas cadenas que están en mayúsculas e imprime el resultado pasados 3 segundos con el siguiente texto: "Las cadenas que estaban en mayúsculas eran:" y entonces imprime cada una de ellas en una linea, en minúsculas.


//: [Next](@next)
