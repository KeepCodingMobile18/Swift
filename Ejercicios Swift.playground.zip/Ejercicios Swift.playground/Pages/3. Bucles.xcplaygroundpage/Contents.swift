//: [Previous](@previous)

import Foundation

print("-----------------------------------------------")
print("------------------Ejercicio 1------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio bucles 1
// Crea la función `countChars(char:Character, inString:String)->Int` que devuelve el número de veces que un caracter aparece en una cadena.

func countChars(char: Character, inString: String) -> Int {
    var count = 0
    for ch in inString {
        if ch == char {
            count += 1
        }
    }
    return count
}

// Ejemplo de uso
let charCount = countChars(char: "a", inString: "banana")
print("El carácter 'a' aparece \(charCount) veces en 'banana'.")  // Output: 3


print()
print("-----------------------------------------------")
print("------------------Ejercicio 2------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio bucles 2
// Crea la función `removeDuplicates` que recibe una cadena y devuelve esa misma cadena con los caracteres repetidos eliminados. OJO, tiene que respetar el orden original!

func removeDuplicates(fromString: String) -> String {
    var seen = Set<Character>()
    var result = ""
    for char in fromString {
        if !seen.contains(char) {
            seen.insert(char)
            result.append(char)
        }
    }
    return result
}

// Ejemplo de uso
let noDuplicates = removeDuplicates(fromString: "banana")
print("Cadena sin duplicados: \(noDuplicates)")  // Output: "ban"



print()
print("-----------------------------------------------")
print("------------------Ejercicio 3------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio bucles 3
// Crea la función `condense`que recibe una cadena con caracteres en blanco y elimina los caracteres en blanco repetidos. Recuerda que tiene que funcionar con los que estén al principio y al final de la cadena, no sólo los que están dentro.

func condense(_ str: String) -> String {
    let trimmed = str.trimmingCharacters(in: .whitespaces)
    var result = ""
    var lastWasSpace = false
    
    for char in trimmed {
        if char.isWhitespace {
            if !lastWasSpace {
                result.append(char)
                lastWasSpace = true
            }
        } else {
            result.append(char)
            lastWasSpace = false
        }
    }
    return result
}

// Ejemplo de uso
let condensed = condense("   Esto es   un  test   ")
print("Cadena condensada: '\(condensed)'")  // Output: "Esto es un test"



print()
print("-----------------------------------------------")
print("------------------Ejercicio 4------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio bucles 4
//  Crea la función `classify` que recibe una cadena y devuelve una tupla con 2 valores:
//          * número de vocales
//          * número de caracteres que no son vocales

func classify(_ str: String) -> (vowels: Int, consonants: Int) {
    let vowelsSet = Set("aeiouAEIOU")
    var vowelsCount = 0
    var consonantsCount = 0
    
    for char in str {
        if vowelsSet.contains(char) {
            vowelsCount += 1
        } else if char.isLetter {
            consonantsCount += 1
        }
    }
    return (vowels: vowelsCount, consonants: consonantsCount)
}

func classify2(_ str: String) -> (vowels: Int, consonants: Int) {
    let vowelsSet = Set("aeiouAEIOU")
    
    let vowels = str.filter {
        vowelsSet.contains($0)
    }
    
    return (vowels: vowels.count, consonants: str.count - vowels.count)
}

// Ejemplo de uso
let classification = classify("Swift Programming")
let classification2 = classify2("Swift Programming")
print("Vocales: \(classification.vowels), Consonantes: \(classification.consonants)")  // Output: Vocales: 4, Consonantes: 12
print("Vocales: \(classification2.vowels), Consonantes: \(classification2.consonants)")  // Output: Vocales: 4, Consonantes: 12



print()
print("-----------------------------------------------")
print("------------------Ejercicio 5------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio bucles 5
//  Crea la función `fizzBuzz`que itera entre el 1 y el 100 e imprime "Fizz" si el número actual es divisible por 3, "Buzz" si es divisible por 5 y "FizzBuzz" si es divisible por 3 y por 5.

func fizzBuzz() {
    for number in 1...100 {
        if number % 15 == 0 {
            print("FizzBuzz")
        } else if number % 3 == 0 {
            print("Fizz")
        } else if number % 5 == 0 {
            print("Buzz")
        } else {
            print(number)
        }
    }
}

// Ejemplo de uso
fizzBuzz()  // Output: Números del 1 al 100 según regla de FizzBuzz



print()
print("-----------------------------------------------")
print("------------------Ejercicio 6------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio bucles 6
//  Recrea en Swift la función `choice` de Python, que recibe una lista y devuelve un elemento al azar de la misma.


func choice<T>(_ list: [T]) -> T? {
    guard !list.isEmpty else { return nil }
    return list.randomElement()
}

// Ejemplo de uso
let randomChoice = choice([1, 2, 3, 4, 5])
print("Elemento aleatorio: \(String(describing: randomChoice))")  // Output: Número aleatorio entre 1 y 5



print()
print("-----------------------------------------------")
print("------------------Ejercicio 7------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio bucles 7
//  Crea la función `contains(hayStack: String, needle: String)->Bool`. Si el *pajar* continene a la *aguja*, devolvemos `true` y sino, `false`

func contains(hayStack: String, needle: String) -> Bool {
    return hayStack.contains(needle)
}

// Ejemplo de uso
let doesContain = contains(hayStack: "Hello, world!", needle: "world")
print("Contiene 'world': \(doesContain)")  // Output: true



print()
print("-----------------------------------------------")
print("------------------Ejercicio 8------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio bucles 8
//  Crea la función `find(hayStack: String, needle: String)->Int` que en vez de devolver un booleano, devuele un entero con *la posición inicial* de la *aguja*.
//         * si no encuentra la aguja, devuelve la constante `NSNotFound`. Esa constante ya existe en `Cocoa`
//         * si no sabes donde está, habla con Grokk.


func find(hayStack: String, needle: String) -> Int {
    if let range = hayStack.range(of: needle) {
        return hayStack.distance(from: hayStack.startIndex, to: range.lowerBound)
    }
    return NSNotFound
}

// Ejemplo de uso
let needlePosition = find(hayStack: "Hello, world!", needle: "world")
print("Posición de 'world': \(needlePosition)")  // Output: 7 (o NSNotFound si no se encuentra)



print()
print("-----------------------------------------------")
print("------------------Ejercicio 9------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio bucles 9
//  Ahora que ya tienes `find`, piensa si de verdad hace falta `contains`. Busca la forma de poder reimplementar `contains` sólo en base a `find`.

func containsUsingFind(hayStack: String, needle: String) -> Bool {
    return find(hayStack: hayStack, needle: needle) != NSNotFound
}

// Ejemplo de uso
let doesContainUsingFind = containsUsingFind(hayStack: "Hello, world!", needle: "swift")
print("Contiene 'swift': \(doesContainUsingFind)")  // Output: false



print()
print("-----------------------------------------------")
print("------------------Ejercicio 10-----------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio bucles 10
//  Crea la función `containsOccurrences(hayStack: String, needle: String, numOfOccs: Int)->Bool`
//        * Si `numOfOccs` < 0, se devuelve `false`
//        * Si `numOfOccs` == 0, se comprueba que la *aguja* no aparece nunca en el *pajar*
//        * Si `numOfOccs` > 0, estamso en el caso general

func containsOccurrences(hayStack: String, needle: String, numOfOccs: Int) -> Bool {
    if numOfOccs < 0 {
        return false
    }
    
    let occurrences = hayStack.components(separatedBy: needle).count - 1
    
    if numOfOccs == 0 {
        return occurrences == 0
    } else {
        return occurrences == numOfOccs
    }
}

// Ejemplo de uso
let hasExactOccurrences = containsOccurrences(hayStack: "banana", needle: "a", numOfOccs: 3)
print("Contiene exactamente 3 'a's: \(hasExactOccurrences)")  // Output: true




//: [Next](@next)
