//: [Previous](@previous)

import CoreGraphics

// MARK: Ejercicio 1 -> imports
print("-----------------------------------------------")
print("------------------Ejercicio 1------------------")
print("-----------------------------------------------")
print()
// Importa los módulos adecuados para que el programa funcione. Busca en google las librerías que contienen las funciones que hacen gritar al compilador.

// 1. Crear un UILabel
let miLabel = UILabel() // Ahora definido correctamente

// 2. Cambiar el color de fondo de la vista
let vista = UIView() // Ahora definido correctamente
vista.backgroundColor = UIColor.red // Ahora definido correctamente

// 3. Dibujo básico con CoreGraphics
let rect = CGRect(x: 0, y: 0, width: 100, height: 100) // Ahora definido correctamente
let contexto: CGContext? = nil // Assume adecuado contexto

// Intentamos dibujar un rectángulo (este código no se puede ejecutar sin un contexto)
contexto?.setFillColor(UIColor.blue.cgColor) // Ahora definido correctamente
contexto?.fill(rect) // Ahora definido correctamente

// En este proyecto de playground no se puede importar UIKit así que no se pueden quitar los errores!

//: [Next](@next)
