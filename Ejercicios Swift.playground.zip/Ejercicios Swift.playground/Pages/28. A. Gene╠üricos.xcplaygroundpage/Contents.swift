//: [Previous](@previous)

import Foundation

print()
print("-----------------------------------------------")
print("------------------Ejercicio 1------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 1 -> Genéricos
// Implementar una Pila Genérica: Crea una estructura genérica `Stack` que implemente una pila con operaciones básicas como `count`, `push`, `pop`, y `peek`.

struct Stack<T> {
    private var items: [T] = []

    var count: Int {
        return items.count
    }

    mutating func push(_ item: T) {
        items.append(item)
    }

    mutating func pop() -> T? {
        return items.popLast()
    }
    
    // Devuelve el último elemento
    func peek() -> T? {
        return items.last
    }
}

// Ejemplo de uso
var intStack = Stack<Int>()
intStack.push(1)
intStack.push(2)
intStack.push(3)
print(intStack.peek()) // Output: Optional(3) // Cuando imprimes un Optional, Swift lo trata como un tipo Any y lo muestra en el formato Optional(value)
intStack.push(6)
print(intStack.pop())  // Output: Optional(6)
print(intStack.count)  // Output: 3



print()
print("-----------------------------------------------")
print("------------------Ejercicio 2------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 2 -> Genéricos
// Cola Genérica: Desarrolla una estructura genérica `Queue` que represente una cola con operaciones como `enqueue` y `dequeue`. Tiene que tener la propiedad `count` también.

struct Queue<T> {
    private var items: [T] = []

    var count: Int {
        return items.count
    }

    mutating func enqueue(_ item: T) {
        items.append(item)
    }

    mutating func dequeue() -> T? {
        return items.isEmpty ? nil : items.removeFirst()
    }
}



print()
print("-----------------------------------------------")
print("------------------Ejercicio 3------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 3 -> Genéricos
// Almacenamiento Seguro: Crea una estructura genérica `SafeStorage` que almacene un valor de cualquier tipo y proporcione un método para acceder de manera segura a su valor, devolviendo un valor predeterminado si el almacenamiento está vacío.

struct SafeStorage<T> {
    private var value: T?

    mutating func store(_ value: T?) {
        self.value = value
    }

    func retrieve(defaultValue: T) -> T {
        return value ?? defaultValue
    }
}

// Ejemplo de uso
var storage = SafeStorage<Int>()
storage.store(10)
print(storage.retrieve(defaultValue: 0)) // Output: 10
storage.store(nil)
print(storage.retrieve(defaultValue: 0)) // Output: 0



print()
print("-----------------------------------------------")
print("------------------Ejercicio 4------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 4 -> Genéricos
// Filtro Genérico: Implementa una función genérica `select` que tome una secuencia y un predicado como argumentos y devuelva una nueva secuencia con los elementos que cumplen el predicado.

func select<T>(_ sequence: [T], using predicate: (T) -> Bool) -> [T] {
    return sequence.filter(predicate)
}

// Ejemplo de uso
let numbers = [1, 2, 3, 4, 5]
let evenNumbers = select(numbers) { $0 % 2 == 0 }
print(evenNumbers) // Output: [2, 4]



print()
print("-----------------------------------------------")
print("------------------Ejercicio 5------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 5 -> Genéricos
// Máximo y Mínimo Genérico: Desarrolla funciones genéricas `max` y `min` que devuelvan el máximo y el mínimo, respectivamente, de dos valores pasados como argumentos.

func max<T: Comparable>(_ a: T, _ b: T) -> T {
    return a > b ? a : b
}

func min<T: Comparable>(_ a: T, _ b: T) -> T {
    return a < b ? a : b
}

// Ejemplo de uso
print(max(3, 5)) // Output: 5
print(min(3, 5)) // Output: 3




print()
print("-----------------------------------------------")
print("------------------Ejercicio 6------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 6 -> Genéricos
// Estructura de Pareja: Crea una estructura genérica `Pair` que contenga dos propiedades de cualquier tipo y demuestra cómo crear instancias de ella.

struct Pair<T, U> {
    let first: T
    let second: U
}

// Ejemplo de uso
let pair = Pair(first: "Hello", second: 42)
print(pair) // Output: Pair(first: "Hello", second: 42)




print()
print("-----------------------------------------------")
print("------------------Ejercicio 7------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 7 -> Extensiones
// Extensión de Array: Escribe una extensión para el tipo genérico `Array` que agregue una función para devolver el elemento en el índice n-ésimo o `nil` si el índice está fuera de rango.

extension Array {
    func at(index: Int) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}

// Ejemplo de uso
let fruits = ["Apple", "Banana", "Cherry"]
print(fruits.at(index: 1))  // Output: Optional("Banana")
print(fruits.at(index: 3))  // Output: nil



print()
print("-----------------------------------------------")
print("------------------Ejercicio 8------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 8 -> Extensiones
// Extensión de array :Crea una extensión a Array que añade el método `atRandom` que devuelve un elemento al azar de dicho `Array`.

extension Array {
    func atRandom() -> Element? {
        return isEmpty ? nil : self[Int.random(in: 0..<count)]
    }
}

// Ejemplo de uso
let letters = ["A", "B", "C", "D"]
if let randomLetter = letters.atRandom() {
    print(randomLetter) // Output: Could be "A", "B", "C", or "D"
}


//: [Next](@next)
