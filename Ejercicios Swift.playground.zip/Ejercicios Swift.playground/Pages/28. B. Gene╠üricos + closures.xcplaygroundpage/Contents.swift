//: [Previous](@previous)

import Foundation



print()
print("-----------------------------------------------")
print("------------------Ejercicio 1------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 1 -> Compress
// Re-escribe la versión final de `compress` y haz que sea genérica.
// Usala para resolver los siguientes problemas.
/*
func compress(sequence: [Int],
              initialValue: Int,
              closure: (Int, Int)->Int) -> Int{
    
    var accum = initialValue
    for number in sequence{
        accum = closure(accum, number)
    }
    return accum
}
*/
func compress<T>(sequence: [T],
                 initialValue: T,
                 closure: (T, T) -> T) -> T{
       
       var accum = initialValue
       for number in sequence{
           accum = closure(accum, number)
       }
       return accum
   }

print()
print("-----------------------------------------------")
print("------------------Problema A-------------------")
print("-----------------------------------------------")
print()
// Dada una lista de cadenas, concaténalas todas.

let cadenasConcatenadas = compress(
    sequence: [
        "primera",
        "segunda",
        "tercera"],
    initialValue: "") {acumulado, cadena in
    acumulado + cadena
}
print("Las cadenas concatenadas son \(cadenasConcatenadas)")




print()
print("-----------------------------------------------")
print("------------------Problema B-------------------")
print("-----------------------------------------------")
print()
// Dada una lista de cadenas, suma las longitudes de todas aquellas que contengan una vocal.
// Asegúrate de que funciona tanto con mayúsculas como minúsculas.

let cadenas = ["primera", "scnd", "third", "Star", "Wars"]

let sumaLongitudesConVocales = compress(
    sequence: cadenas,
    initialValue: "0") { acumulado, cadena in
    // Verificar si la cadena contiene una vocal (tanto mayúscula como minúscula)
    let vocales = CharacterSet(charactersIn: "aeiouAEIOU")
        print(cadena)
    if cadena.rangeOfCharacter(from: vocales) != nil { // Te da el rango de caracteres que están presentes en el set vocales
        return (Int(acumulado)! + Int(cadena.count)).description
    } else {
        return acumulado
    }
}

print("La suma de las longitudes de las cadenas con vocales es \(sumaLongitudesConVocales)")




print()
print("-----------------------------------------------")
print("------------------Problema C-------------------")
print("-----------------------------------------------")
print()
// Dado un array de números decimales, devuelve una tupla con la suma y el producto de todos ellos.

func compress<T, U>(sequence: [T],
                    initialValue: U,
                    closure: (U, T) -> U) -> U {
    
    var accum = initialValue
    for element in sequence {
        accum = closure(accum, element)
    }
    return accum
}

let numeros: [Double] = [1.0, 2.5, 3.0, 4.5]

let sumaYProducto = compress(
    sequence: numeros,
    initialValue: (suma: 0.0, producto: 1.0)
) { (acumulado, numero) in
    return (suma: acumulado.suma + numero, producto: acumulado.producto * numero)
}

print("La suma de los números es \(sumaYProducto.suma) y el producto es \(sumaYProducto.producto)")




print()
print("-----------------------------------------------")
print("------------------Problema E-------------------")
print("-----------------------------------------------")
print()
// A partir de una lista de enteros, devuelve true si todos son pares.

let numerosEnteros: [Int] = [2,5,6]

let todosSonPares = compress(
    sequence: numerosEnteros,
    initialValue: false // Por si hay un array vacío y no se entra en la closure
) { (acumulado, numero) in
    // En caso de que sea la primera iteración debemos cambiar el valor inicial del acumulado
    var nuevoValorDeAcumulado = acumulado
    if numero == numerosEnteros.first {
        nuevoValorDeAcumulado = true
    }
    return nuevoValorDeAcumulado && (numero % 2 == 0)
}

print("Todos los números son pares: \(todosSonPares)")




print()
print("-----------------------------------------------")
print("------------------Ejercicio 2------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 2 -> Select
// Re-escribe la versión final de `select` para que sea genérica.

/*
 func select2(sequence: [String],
             predicate: (String) -> Bool,
              completion: ([String]) -> Void) -> [String] {
     
     var accum : [String] = []
     for element in sequence{
         if predicate(element){
             accum.append(element)
         }
     }
     completion(accum)
     return accum
 }
 */

func select(sequence: [String],
            predicate: (String) -> Bool,
             completion: ([String]) -> Void) -> [String] {
    
    var accum : [String] = []
    for element in sequence{
        if predicate(element){
            accum.append(element)
        }
    }
    completion(accum)
    return accum
}

print()
print("-----------------------------------------------")
print("------------------Problema A-------------------")
print("-----------------------------------------------")
print()
// Devuelve el array de aquellas cadenas que están en mayúsculas e imprime el resultado pasados 3 segundos con el siguiente texto: "Las cadenas que estaban en mayúsculas eran:" y entonces imprime cada una de ellas en una linea, en minúsculas.

// Predicado para verificar si una cadena está en mayúsculas
let isUppercase: (String) -> Bool = { $0.allSatisfy { $0.isUppercase } } // Mira en el array de chars si todas son uppercase

// Uso de la función select2
let wordsInMayusc = select(
    sequence: ["HOLA", "andres", "ALBA", "GUSTAVO"],
    predicate: isUppercase,
    completion: { uppercaseWords in
        // Esperar 3 segundos antes de imprimir
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            print("Las cadenas que estaban en mayúsculas eran:")
            for word in uppercaseWords {
                print(word.lowercased()) // Imprimir en minúsculas
            }
        }
    }
)


//: [Next](@next)
