//: [Previous](@previous)

import Foundation


print()
print("-----------------------------------------------")
print("------------------Ejercicio 1------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 1 -> closures compressor
//  Crea la función `sumAll` que recibe un array de enteros y devuelve su suma. Usa un bucle for. ¿Qué debe de devolver cuando el array está vacío?
func sumAll(sequence: [Int]) -> Int {
    var total = 0
    for number in sequence{
        total = total + number
    }
    return total
}




print()
print("-----------------------------------------------")
print("------------------Ejercicio 2------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 2 -> closures compressor
// Crea la función `multiplyAll` que recibe un Array de enteros y devuelve su producto. ¿Qué debe de devolver si el array está vacío?
func multiplyAll(sequence: [Int])-> Int{
    var total = 1
    for number in sequence{
        total = total * number
    }
    return total
}




print()
print("-----------------------------------------------")
print("------------------Ejercicio 3------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 3 ->  closures compressor
// Crea la función `compress`. Esta función se va a encargar de recibir un array con un tipo y reducirlo a un solo elemento del mismo tipo. Como lo único que cambia es el valor inicial y la operación de combinación, vamos a meterle eso como parámetros:
// func compress(sequence: [Int],
//                  initialValue: Int,
//                  operación:  (Int, Int)->Int
//                  ) -> Int
typealias IntCombiner = (Int, Int) -> Int // Este typealias se usa mucho con closures, sirve para sustituir al tipo, es puramente visual

func compress(sequence: [Int],
              initialValue: Int,
              combinationOperation: IntCombiner) -> Int{
    
    var accum = initialValue // Los parámetros se pasan como let, no se pueden modificar y necesitamos hacerlo dentro de la función
    for number in sequence{
        accum = combinationOperation(accum, number)
    }
    return accum
}




print()
print("-----------------------------------------------")
print("------------------Ejercicio 4------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 4 -> closures compressor
// Usa la función compress para resolver los dos problemas de arriba (el 1 y el 2).
// Utiliza los diferentes tipos de sintaxis de las closures

let sumNormal = compress(sequence: [1,2,3,4],
                   initialValue: 0,
                   combinationOperation: { (accum: Int, number: Int) -> Int in
                       return accum + number
                   })
print("Suma con syntax normal = \(sumNormal)")
/// Suma con sintaxis de return implicito
let sumReturnImplicito = compress(sequence: [1,2,3,4],
                   initialValue: 0,
                   combinationOperation: { (accum: Int, number: Int) -> Int in accum + number })
print("Suma con return implícito = \(sumReturnImplicito)")
/// Suma con sintaxis de tipo de retorno implicito
let sumTipoRetornoImplicito = compress(sequence: [1,2,3,4],
                   initialValue: 0,
                   combinationOperation: { (accum, number) in accum + number })
print("Suma con tipo de retorno implícito = \(sumTipoRetornoImplicito)")
/// Suma con sintaxis hiperreducida
let sumHiperreducida = compress(sequence: [1,2,3,4],
         initialValue: 0,
         combinationOperation: {$0 + $1})
print("Suma con closure hiperreducida = \(sumHiperreducida)")

/// Multiplicacione con sintaxis normal
let multipNormal = compress(sequence: [1,2,3,4],
                            initialValue: 1,
                            combinationOperation: { (accum: Int, number: Int) -> Int in
                                return accum * number
                            })
print("Multiplicación con syntax normal = \(multipNormal)")
/// Multiplicación con sintaxis de return implícito
let multipReturnImplicito = compress(sequence: [1,2,3,4],
                                     initialValue: 1,
                                     combinationOperation: { (accum: Int, number: Int) -> Int in accum * number })
print("Multiplicación con return implícito = \(multipReturnImplicito)")
/// Multipllicación con sintaxis de tipo de retorno implícito
let multipTipoRetornoImplicito = compress(sequence: [1,2,3,4],
                                          initialValue: 1,
                                          combinationOperation: { (accum, number) in accum * number })
print("Multiplicación con tipo de retorno implícito = \(multipTipoRetornoImplicito)")
/// Multiplicación con sintaxis hiperreducida
let multipHiperreducida = compress(sequence: [1,2,3,4],
         initialValue: 1,
         combinationOperation: {$0 * $1})
print("Multiplicación con closure hiperreducida = \(multipHiperreducida)")





print()
print("-----------------------------------------------")
print("------------------Ejercicio 5------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 5 -> closures compressor
// Obtén la suma de todos los elementos pares

// Solución Javier -> el primer número es el accum, esto funciona porque accum (num1) siempre es par
let resultMulti = compress(sequence: [1, 2, 3, 4, 5, 6], initialValue: 0) { num1, num2 in
    switch (num1 % 2 == 0, num2 % 2 == 0) {
    case (true, true):    // Si pares
        return num1 + num2
    case (true, false):   // Si 1 par
        return num1
    case (false, true):   // Si 2 par
        return num2
    default:              // Ninguno es par
        return 0
    }
}
print("Suma de números pares solución 2 = \(resultMulti)")

// Solución Hernán
let resultHernan = compress(sequence: [1,2,3,4,5,6], initialValue: 0) { num1, num2 in
    if (num2 % 2 == 0) {
        return num1 + num2
    }
    return num1
}

print("Suma de números pares solución 2 = \(resultHernan)")

// Solución Isma
let sumaPares = compress(sequence: [1,2,3,4,5,6], initialValue: 0) { accum, num in
    if num % 2 == 0 { return accum + num }
    else { return accum }
}

// Obtén la suma de todos los elementos pares menos la suma de los elementos impares

// Solución Hernán
let resultHernan2 = compress(sequence: [1,2,3,4,5,6], initialValue: 0) { num1, num2 in
    if (num2 % 2 == 0) {
        return num1 + num2
    }
    return num1 - num2
}

// Obtén el elemento máximo
// Solución Isma
let maxElement = compress(sequence: [1, 2, 3, 4, 5], initialValue: Int.min) {
    max($0, $1)
}
print("Elemento máximo = \(maxElement)")

// Solución Hernán
compress(sequence: [1,2,3,4,5,6], initialValue: Int.min) { num1, num2 in
    if (num2 > num1) {
        return num2
    }
    return num1
}
// Obtén el elemento mínimo
compress(sequence: [1,2,3,4,5,6], initialValue: Int.max) { num1, num2 in
    if (num2 > num1) {
        return num1
    }
    return num2
}
let minElement = compress(sequence: [1, 2, 3, 4, 5], initialValue: Int.max) {
    min($0, $1)
}
print("Elemento mínimo = \(minElement)")

// Obtén la cantidad de elementos positivos
let positiveCount = compress(sequence: [-1, 2, 3, -4, 5], initialValue: 0) {
    $0 + ($1 > 0 ? 1 : 0) // Vamos sumando uno cada vez que el elemento es positivo
}
print("Cantidad de elementos positivos = \(positiveCount)")





print()
print("-----------------------------------------------")
print("------------------Ejercicio 6------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 6 -> closures compressor
// Crea la función `allEvens` que recibe una lista de enteros y devuelve true si todos son pares. ¿Qué devuelve si está vacío? Usa compress
func allEvens(sequence: [Int]) -> Bool { // [2, 2, 4, 1, 1]
    if sequence.isEmpty { return false }

    // Compress
        // Si el accum al final es de elementos pares -> true
    let result = compress(sequence: sequence,
                          initialValue: 0) { accum, num in
        if num % 2 == 0 {
            return accum + 1
        } else {
            return accum
        }
        // return num % 2 == 0 ? accum + 1 : accum
    }
    
    return result == sequence.count
}

print("Devuelve true: \(allEvens(sequence: [2, 4, 6]))")
print("Devuelve false: \(allEvens(sequence: []))")
print("Devuelve false: \(allEvens(sequence: [2, 4, 3, 6, 5]))")




print()
print("-----------------------------------------------")
print("------------------Ejercicio 7------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 7 -> closures compressor
// Crea la función `allMultiplesOfThree` que recibe una lista de enteros y devuelve true si todos son múltiplos de 3. ¿Qué devuelve si el array está vacío? Usa compress

func allMultiplesOfThree(sequence: [Int]) -> Bool {
    if sequence.isEmpty {
        return false     }
    
    let result = compress(sequence: sequence,
                          initialValue: 0,
                          combinationOperation: { (accum, number) in
                              // Check if the number is a multiple of 3 and return an updated accum value.
                              return accum + (number % 3 == 0 ? 1 : 0)
                          })
    
    // If result is equal to the length of the sequence, all numbers are multiples of 3.
    return result == sequence.count
}
print("Todos son múltiplos de 3: \(allMultiplesOfThree(sequence: [3, 9, 6]))")
print("Todos son pares en lista vacía: \(allMultiplesOfThree(sequence: []))")
print("Todos son pares en lista con un 4: \(allMultiplesOfThree(sequence: [4, 3, 9, 6]))")





print()
print("-----------------------------------------------")
print("------------------Ejercicio 8------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 8 ->  closures compressor
// Crea la función `sumAllEvensAndOdds` que recibe un array de enteros y devuelve una tupla con la suma de los pares y la suma de los impares. ¿Puedes hacerlo usando compress?

func sumAllEvensAndOdds(sequence: [Int]) -> (evenSum: Int, oddSum: Int) {
    let odds = compress(sequence: sequence, initialValue: 0) {
        $1 % 2 != 0 ? ($0 + $1) : $0 // Si accum es par entonces devuelve accum + número, si no, devuelve accum
    }
    let evens = compress(sequence: sequence, initialValue: 0) {
        $1 % 2 == 0 ? ($0 + $1) : $0 // Si accum es impar entonces devuelve accum + número, si no, devuelve accum
    }
    return (evens, odds) // Return a tuple with both sums
}


// Print statements to test the sumAllEvensAndOdds function
print("La suma de todos los pares y impares en [1, 2, 3, 4] es: \(sumAllEvensAndOdds(sequence: [1, 2, 3, 4]))") // Even: 6, Odd: 4
print("La suma de todos los pares y impares en [0, -2, 3, -5] es: \(sumAllEvensAndOdds(sequence: [0, -2, 3, -5]))") // Even: -2, Odd: -2
print("La suma de todos los pares y impares en [10, 15, 20] es: \(sumAllEvensAndOdds(sequence: [10, 15, 20]))") // Even: 30, Odd: 15
print("La suma de todos los pares y impares en [-1, -4, -3, -6] es: \(sumAllEvensAndOdds(sequence: [-1, -4, -3, -6]))") // Even: -10, Odd: -4
print("La suma de todos los pares y impares en lista vacía es: \(sumAllEvensAndOdds(sequence: []))") // Even: 0, Odd: 0





print()
print("-----------------------------------------------")
print("------------------Ejercicio 9------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 9 -> closures compressor
// Modifica `compress` para que no necesite el valor inicial.

func compress(sequence: [Int], combinationOperation: (Int, Int) -> Int) -> Int? {
    // Check if the sequence is empty
    if sequence.isEmpty {
        return nil
    }
    
    // Initialize accum with the first element of the sequence
    var accum = sequence.first!

    // Iterate through the rest of the sequence starting from the second element
    for number in sequence.dropFirst() {
        accum = combinationOperation(accum, number)
    }
    
    return accum // Return the final accumulated value
}
let sumOfValues = compress(sequence: [2,2,2]) { a, b in
    a + b
}
print("The sum of values with the new func is \(sumOfValues)")





print()
print("-----------------------------------------------")
print("------------------Ejercicio 10-----------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 10 -> closures compressor2
// Modifica `compress` para que reciba como último parámetro una *clausura de finalización*. Se trata de una clausura que no recibe nada y no devuelve nada. Se va a usar cuando `compress` haya terminado. -> completion: () -> Void
typealias Thunk = () -> Void

func compress2(sequence: [Int],
              initialValue: Int,
              combinationOperation: IntCombiner,
              completion: Thunk) -> Int{
    
    var accum = initialValue
    for number in sequence{
        accum = combinationOperation(accum, number)
    }
    completion()
    return accum
}



print()
print("-----------------------------------------------")
print("------------------Ejercicio 11-----------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 11 -> closures compressor2

//  Calcular la suma de los cuadrados de la secuencia y una vez terminado imprimir en pantalla un aviso de que se terminó. Usa compress2

let sumaCuadrados = compress2(
    sequence: [2, 4],
    initialValue: 0,
    combinationOperation: { accum, number in
        return accum + number * number // Calcular el cuadrado de cada número
    },
    completion: {
        print("¡Mamá, terminé la suma de los cuadrados!")
    }
)

print("La suma de los cuadrados es \(sumaCuadrados)")

// Probando con más ejemplos
let sumaCuadrados2 = compress2(
    sequence: [1, 3, 5],
    initialValue: 0,
    combinationOperation: { accum, number in
        return accum + number * number
    },
    completion: {
        print("¡Mamá, terminé la suma de los cuadrados!")
    }
)

print("La suma de los cuadrados es \(sumaCuadrados2)")

let sumaCuadrados3 = compress2(
    sequence: [0, -2, 10],
    initialValue: 0,
    combinationOperation: { accum, number in
        return accum + number * number
    },
    completion: {
        print("¡Mamá, terminé la suma de los cuadrados!")
    }
)

print("La suma de los cuadrados es \(sumaCuadrados3)")

// Calcula la suma de los elementos que son multiplos de 3 y cunado termine y pasados 4 segundos, imprime en pantalla la frase "¡Mamá, terminé!". Usa compress2

let sumaMultiplos3_1 = compress2(
    sequence: [3, 6, 9],
    initialValue: 0,
    combinationOperation: { accum, number in
        return accum + (number % 3 == 0 ? number : 0)
    },
    completion: {
        DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
            print("¡Mamá, terminé la suma de los múltiplos de 3!")
        }
    }
)

print("La suma de los múltiplos de 3 es \(sumaMultiplos3_1)")

let sumaMultiplos3_2 = compress2(
    sequence: [3, 6, 9, 5],
    initialValue: 0,
    combinationOperation: { accum, number in
        return accum + (number % 3 == 0 ? number : 0)
    },
    completion: {
        DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
            print("¡Mamá, terminé la suma de los múltiplos de 3!")
        }
    }
)

print("La suma de los múltiplos de 3 es \(sumaMultiplos3_2)")



print()
print("-----------------------------------------------")
print("------------------Ejercicio 12-----------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 12 -> closures compressor3
// Modifica de nuevo `compress` para que la *clausura de finalización* reciba como parámetro un entero, que es el resultado de la compresión.

typealias CompletionWithIntParameter = (Int) -> Void

func compress3(sequence: [Int],
              initialValue: Int,
              combinationOperation: IntCombiner,
              completion: CompletionWithIntParameter) -> Int{
    
    var accum = initialValue
    for number in sequence{
        accum = combinationOperation(accum, number)
    }
    completion(accum)
    return accum
}



print()
print("-----------------------------------------------")
print("------------------Ejercicio 13-----------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 13 -> closures compressor3

// Calcula el producto de los cuadrados todos los elementos impares y usa la clausura de finalización para imprimir un mensaje con el resultado pasados 2 segundos.

let productoCuadradosDeImpares = compress3(
    sequence: [3, 5], // 9 * 25 = 225
    initialValue: 1) { accum, number in
        return accum * (number % 2 == 1 ? (number * number) : 0)
    } completion: { productoCuadradosImpares in
        DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
            print("¡Mamá, terminé el producto de los cuadrados de los impares que es \(productoCuadradosImpares)!")
        }
    }

print("El producto de los cuadrados de los impares \(productoCuadradosDeImpares)")



//  Calcula la suma de los elementos divisibles por 3 y usa la *clausura de finalización* para imprimir un mensaje con el resultado pasados tantos segundos como el resultado dividido por 2.

let sumaElementosDivisiblespor3 = compress3(sequence: [3,6,9,2], initialValue: 0) { accum, number in
    return accum + (number % 3 == 0 ? number : 0)
} completion: { sumaElementosDivisiblesPor3 in
    let tiempo: Int = sumaElementosDivisiblesPor3 / 2
    DispatchQueue.main.asyncAfter(deadline: .now() + DispatchTimeInterval.seconds(tiempo)) {
        print("¡Mamá, terminé la suma de los elementos divisibles por 3 que es \(sumaElementosDivisiblesPor3)!")
    }
}
print("La suma de los elementos divisibles por 3 que es \(sumaElementosDivisiblespor3)")


//: [Next](@next)
