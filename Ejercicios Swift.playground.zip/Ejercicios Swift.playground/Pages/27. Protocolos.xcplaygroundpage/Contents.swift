//: [Previous](@previous)

import Foundation


print()
print("-----------------------------------------------")
print("------------------Ejercicio 1------------------")
print("-----------------------------------------------")
print()
// MARK: Ejercicio 1 -> Protocolos

/// Debes de diseñar la `struct` `Jedi` para representar a un... Jedi. Debe de tener las siguientes propiedades:
/// * `name`, `surname` de tipo cadena
/// * `midichlorians` de tipo entero, entre 0 y 1000
/// * `affiliation` es de tipo `Affiliation`, una enum que tendrás que crear para representar los siguinetes
/// casos: GalacticRepublic, RebelAlliance, FirstOrder, GalacticEmpire, MandalorianOrder, KnightsOfRen y Unknown
/// * Una propiedad computable que imprime su nombre completo y la afiliación. Si los midiclorianos son >= 600, debe de anteponer el título "Master"
///
/// Tendrá un init que le pasa esos valores.
///
/// Tendrá un método `unsheathe` (desenvaina) que devuelve una cadena con texto como éste:
/// o:::::::::·::▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
/// La longitud debe de ser proporcional a la cantidad de midiclorianos
///
/// Tienes que hacer que conforme los siguinetes protocolos:
///* `Equatable`: usa todas las propiedades
///* `Comparable`: usa los midiclorianos
///* `CustomStringConvertible`: Debe de imprimir el nombre completoy los midiclorianos entre paréntesis
///* `Codable`

// Enum que representa las diferentes afiliaciones posibles
enum Affiliation: String, Codable {
    case GalacticRepublic = "Galactic Republic"
    case RebelAlliance = "Rebel Alliance"
    case FirstOrder = "First Order"
    case GalacticEmpire = "Galactic Empire"
    case MandalorianOrder = "Mandalorian Order"
    case KnightsOfRen = "Knights of Ren"
    case Unknown = "Unknown"
}

// Definición de la estructura Jedi que conforma múltiples protocolos
struct Jedi: Equatable, Comparable, CustomStringConvertible, Codable {
    let name: String
    let surname: String
    private(set) var midichlorians: Int
    var affiliation: Affiliation
    
    // Inicializador para la estructura Jedi
    init(name: String, surname: String, midichlorians: Int, affiliation: Affiliation) {
        // Limita los midiclorianos entre 0 y 1000
        self.name = name
        self.surname = surname
        self.midichlorians = max(0, min(midichlorians, 1000))
        self.affiliation = affiliation
    }
    
    // Propiedad computada para el nombre completo y la afiliación
    var fullNameWithAffiliation: String {
        let title = midichlorians >= 600 ? "Master" : ""
        // Junta el título (si aplica), nombre, apellido y afiliación en una cadena
        return [title, name, surname, "(\(affiliation.rawValue))"].filter { !$0.isEmpty }.joined(separator: " ")
    }
    
    // Método desenvainar sable de luz, cuya longitud depende de los midiclorianos
    func unsheathe() -> String {
        let length = max(1, midichlorians / 50) // Cada 50 midiclorianos incrementa la longitud
        return "o" + String(repeating: ":", count: length) + "·::▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
    }
    
    // Conformidad con Comparable
    static func < (lhs: Jedi, rhs: Jedi) -> Bool {
        // Se compara basándose en la cantidad de midiclorianos
        return lhs.midichlorians < rhs.midichlorians
    }
    
    // Conformidad con CustomStringConvertible
    var description: String {
        // Representación con nombre completo y midiclorianos
        return "\(fullNameWithAffiliation) (\(midichlorians))"
    }
}

// Ejemplo de uso
let jedi = Jedi(name: "Luke", surname: "Skywalker", midichlorians: 800, affiliation: .RebelAlliance)
print(jedi.fullNameWithAffiliation) // Imprime "Master Luke Skywalker (Rebel Alliance)"
print(jedi.unsheathe()) // Imprime una línea larga proporcional a los midiclorianos
print(jedi.description) // Imprime "Master Luke Skywalker (Rebel Alliance) (800)"


//: [Next](@next)
