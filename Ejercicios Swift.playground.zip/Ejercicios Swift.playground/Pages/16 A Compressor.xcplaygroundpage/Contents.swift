//: [Previous](@previous)

import Foundation

// MARK: Ejercicio closures compressor 1
//  Crea la función `sumAll` que recibe un array de enteros y devuelve su suma. Usa un bucle for. ¿Qué debe de devolver cuando el array está vacío?

// MARK: Ejercicio closures compressor 2
// Crea la función `multiplyAll` que recibe un Array de enteros y devuelve su producto. ¿Qué debe de devolver si el array está vacío?

// MARK: Ejercicio closures compressor 3
// Crea la función `compress`. Esta función se va a encargar de recibir un array con un tipo y reducirlo a un solo elemento del mismo tipo. Como lo único que cambia es el valor inicial y la operación de combinación, vamos a meterle eso como parámetros:
// func compress(sequence: [Int],
//                  initialValue: Int,
//                  operación:  (Int, Int)->Int
//                  ) -> Int


// MARK: Ejercicio closures compressor 4
// Usa la función compress para resolver los dos problemas de arriba (el 1 y el 2).
// Utiliza los diferentes tipos de sintaxis de las closures

// MARK: Ejercicio closures compressor 5
// Obtén la suma de todos los elementos pares

// Obtén la suma de todos los elementos pares menos la suma

// Obtén el elemento máximo

// Obtén el elemento mínimo

// Obtén la cantidad de elementos positivos

// MARK: Ejercicio closures compressor 6
// Crea la función `allEvens` que recibe una lista de enteros y devuelve true si todos son pares. ¿Qué devuelve si está vacío? Usa compress

// MARK: Ejercicio closures compressor 7
// Crea la función `allMultiplesOfThree` que recibe una lista de enteros y devuelve true si todos son múltiplos de 3. ¿Qué devuelve si el array está vacío? Usa compress

// MARK: Ejercicio closures compressor 8
// Crea la función `sumAllEvensAndOdds` que recibe un array de enteros y devuelve una tupla con la suma de los pares y la suma de los impares. ¿Puedes hacerlo usando compress?

// MARK: Ejercicio closures compressor 9
// Modifica `compress` para que no necesite el valor inicial.

// MARK: Ejercicio closures compressor2 10
// Modifica `compress` para que reciba como último parámetro una *clausura de finalización*.Se trata de una clausura que no recibe nada y no devuelve nada (a esa clausuraa veces se le llama un *thunk*, pregúntale a Grokk el origen de esa palabreja). Se va a usar para encapsular una tarea que se llevará a cabo pasado un tiempo, en concreto, cunado `compress` haya terminado.

// MARK: Ejercicio closures compressor2 11
//  Calcular la suma de los cuadrados de la secuencia y una vez terminado imprimir en pantalla un aviso de que se terminó. Usa compress2

// Calcula la suma de los elementos que son multiplos de 3 y cunado termine y pasados 4 segundos, imprime en pantalla la frase "¡Mamá, terminé!". Usa compress2

// MARK: Ejercicio closures compressor3 12
// Modifica de nuevo `compress` para que la *clausura de finalización* recibe como parámetro un entero, que es el resultado de la compresión.

// MARK: Ejercicio closures compressor3 13
// Calcula el producto de los cuadrados todos los elementos impares y usa la clausura de finalización para imprimir un mensaje con el resultado pasados 2 segundos.

//  Calcula la suma de los elementos divisibles por 3 y usa la *clausura de finalización* para imprimir un mensaje con el resultado pasados tantos segundos como el resultado dividido por 2.

//: [Next](@next)
