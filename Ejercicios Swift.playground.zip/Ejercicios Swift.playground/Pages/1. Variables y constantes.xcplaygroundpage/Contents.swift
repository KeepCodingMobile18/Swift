//: [Previous](@previous)

import Foundation

// MARK: Ejercicio 1 -> declaración de variables y cambios 1
print("-----------------------------------------------")
print("------------------Ejercicio 1------------------")
print("-----------------------------------------------")
print()
// Declarar una variable, cambiar su valor y mostrar los resultados en la consola.
var favoriteCountry = "YourFavoriteCountry"
favoriteCountry = "ChangedFavoriteCountry"
print("La variable es \(favoriteCountry)")


// MARK: Ejercicio 2 -> uso de constantes
print()
print("-----------------------------------------------")
print("------------------Ejercicio 2------------------")
print("-----------------------------------------------")
print()
// Declarar una constante y demostrar que no puede ser modificada después de la inicialización.
let birthYear = 1990
print("La constante es \(birthYear)")
// birthYear = 1002

//: [Next](@next)
