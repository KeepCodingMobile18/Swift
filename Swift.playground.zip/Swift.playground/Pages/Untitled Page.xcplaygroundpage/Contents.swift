import Cocoa

// MARK: Variables y constantes

// Variables
var greeting = "Hello, playground"
print(greeting)
greeting = "Hello, hemos cambiado el saludo"
print(greeting)

// Constantes
let greetingConstante = "Greeting constante"
print(greetingConstante)
let greetingConstante2 = "Cambiamos el valor del greeting Constante" // Declaramos el greeting como constante
print(greetingConstante2)

// MARK: Comentarios

/// La función de prueba suma dos números y devuelve la suma multiplicada por dos.
///
/// - Parameters:
///   - num1: Número 1 que se va a sumar.
///   - num2: Número 2 que se va a sumar.
/// - Returns: La suma de los dos números multiplicada por dos.
///
/// Something
func funcionDePrueba(num1: Int, num2: Int) -> Int {
    return (num1) * 2
}


/*
 wadhiwahdiawnhid
 dnwidnhwiandiaw
 - Esto es un bloque
* Esto está comentado
 */

// MARK:
// MARK: -
// TODO: haY QUE implementar una funcionalidad
// FIXME: esto hay que arreglarlo


// MARK: Tipos
// Primitivos
let constanteStringImplícita = "Es un string implícito" // Manera implícita
let constanteStringExplícita: String = "Es un string explícito"
let intNumber: Int = 666 // Negativos o positivos -> 4 bytes
let intnumberImplícito = 122
let positiveIntNumber: UInt8 = 255 // hasta 255 -> 8 bits = 1 byte
let positiveLongIntNumber: UInt16 = 12737 // hasta 65535 -> 16 bits
let floatNumber: Float = 12.3
let doubleNumber: Double = 12.3442453
let isMinor: Bool = intNumber < 100

// Listas
let array1Implícito = ["Starlight", "Homelander", "Black Noir", "Queen Mave", "Translucent", "A Train", "The Deep"]
let array1explíctio: [String] = ["Starlight", "Homelander", "Black Noir", "Queen Mave", "Translucent", "A Train", "The Deep"]
let arrayDeArrays: [[String]] = [["Starlight", "Homelander", "Black Noir", "Queen Mave", "Translucent", "A Train", "The Deep"]]
// let arrayDeNúmeros = [2,2,4,2,"String"] // No acepta arrays de varios tipos

// Sets
let vowels = ["a", "e", "o", "u", "a"]
let vowelsSet: Set = ["a", "e", "o", "u", "a"]
let vowelsSetExplicit: Set<String> = ["a", "e", "o", "u", "a"]
let voewslSet2 = Set(["a", "e", "o", "u", "a"])

print(vowels)
print(vowelsSet)
print(vowelsSetExplicit)
print(voewslSet2)

// Diccionarios

var phoneNumbers: [String: String] = [
    "Alice":"630997788",
    "Bob":"91287391"
]

var number = phoneNumbers["Alice"]

if let aliceNumber = phoneNumbers["Alice"] {
    print(aliceNumber)
} else {
    print("Con optional")
}

print(number)

var bobNumber = phoneNumbers["Bob3"]
print(bobNumber)

for (name, number) in phoneNumbers {
    print(name, number)
}

// Boleano
let weight = 30
let age = 50
let ageIsMinorThanWeight = age < weight
print(ageIsMinorThanWeight)

if ageIsMinorThanWeight {
    print("Age is minor than weigth")
} else if weight > 90 {
    print("Age is greater or equal than weigth")
} else {
    print("Other")
}

// Enums
enum EmailState {
    case addressUnknown
    case confirmed
    case notConfirmed
}

let emailState = EmailState.addressUnknown
if emailState == EmailState.confirmed {
    print("Email confirmed")
} else {
    print("Email not confirmed")
}

enum Currency: String {
    case usd = "USD"
    case euro = "EURO"
}

let currency = Currency.euro
print(currency)
print(currency.rawValue)

// MARK: - Funciones

// El bmi es el peso / altura * altura
func maleBMI(weight: Double, height: Double) -> Double {
    // Función hace algo aquí
    let bmi = weight / (height * height)
    return bmi
}

print(maleBMI(weight: 2,height: 2))

func calculateBMI(withWeightInKg weight: Double, andHeightInMeters height: Double) -> Double {
    let bmi = weight / (height * height)
    return bmi
}

func calculateBMI(_ weight: Double, andHeightInMeters height: Double) -> Double {
    let bmi = weight / (height * height)
    return bmi
}


// MARK: Metodología de resolución
// Ejercicio 1: Crea la función `isPalindrome` que recibe una cadena y devuelve true si es un palíndromo y False si no.

// 1. Definir y entender el problema: "lcggcl" -> es un palíndromo

// 2. Declarar la función
// 2.1. Nombre de la función: isPalindrome
// 2.2. Entrada de la función: el string que vayamos a analizar -> "lcggcl"
// 2.3  Salida de la función: el booleano que nos va a decir si es o no es un palíndromo -> bool
// isPalindrome(word: String) -> Bool { }

// 3. Lógica de resolución del problema
// 3.1 Comparar letra por letra desde el inicio hasta el final: "lcggcl" -> l con l, c con c...
// 3.2. Invertir la palabra y ver si coincide con la palabra inicial: "lcpgal" == "lagpcl" ??
// 3. ....

// 4. Codificar la solución
func isPalindrome(_ word: String) -> Bool {
    // Comparar letra por letra desde el inicio hasta el final: "lcggcl" -> l con l, c con c...
    let characters = Array(word.lowercased().replacingOccurrences(of: " ", with: "")) // amanaplanacanalpanama
    
    
    var leftIndex = 0
    var lastIndex = characters.count - 1
    
    while leftIndex < lastIndex {
        if characters[leftIndex] != characters[lastIndex] {
            return false
        }
        // Actualizar los índices
        leftIndex += 1
        lastIndex -= 1
    }
    
    return true
}

// 5. Probar la función
print(isPalindrome("agaegfawaa")) // false
print(isPalindrome("anilina")) // true
print(isPalindrome("reconocer")) // true
print(isPalindrome("hola")) // false
print(isPalindrome("A man a plan a canal Panama")) // true
print(isPalindrome("reConOcer")) // true
print(isPalindrome("")) // true
print(isPalindrome("a")) // true

// 6. Problemas
// Las mayúsculas y minúsculas están siendo tenidas en cuenta
// agaegfawaa está dando true porque la primera y última letra son iguales
// A man a plan a canal Panama HAY ALGÚn problema

// 7. Refactorizar la función para resolver los problemas del punto 6 -> punto 4

func isPalindrome2(_ word: String) -> Bool {
    return word == String(word.reversed())
}

func test_whenEvenPalindrome_isTrue(word: String) {
    assert(isPalindrome2(word) == true, "The test \(#function) failed: the palindrome lcggcl is actually a palindrome")
}

test_whenEvenPalindrome_isTrue(word: "lcggcl")
