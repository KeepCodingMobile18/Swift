//
//  main.swift
//  game
//
//  Created by Ismael Sabri Pérez on 1/9/24.
//

import Foundation

enum GameChoice: String {
    case Rock = "Rock"
    case Paper = "Paper"
    case Scissors = "Scissors"
    case Quit = "Quit"
}

typealias PlayResult = String

func main() {
    while true {
        let userChoice = readUserChoice()
        if !isExit(choice: userChoice) {
            let computerChoice = generateComputerChoice()
            let result = evaluateMove(user: userChoice, computer: computerChoice)
            displayResult(result)
        } else {
            print("Gracias por jugar! Adiós.")
            break
        }
    }
}


func readUserChoice() -> GameChoice {
    var choice: GameChoice = .Rock
    
    while true {
        print()
        print("Select an option")
        print("0 - Rock")
        print("1 - Paper")
        print("2 - Scissors")
        print("3 - Quit")
        print("-----------")
        if let response = readLine(), let number = Int(response) {
            switch number {
            case 0:
                choice = .Rock
                break
            case 1:
                choice = .Paper
                break
            case 2:
                choice = .Scissors
                break
            case 3:
                choice = .Quit
                break
            default:
                print("Opción no válida. Inténtalo de nuevo.")
                continue
            }
        } else {
            print("Por favor, introduce un número válido.")
        }
        
        break
    }
    print("Has elegido \(choice.rawValue)")
    return choice
}

func isExit(choice: GameChoice) -> Bool {
    return choice == .Quit
}

func generateComputerChoice() -> GameChoice {
    let randomChoice = Int.random(in: 0...2)
    let computerChoice: GameChoice

    switch randomChoice {
    case 0:
        computerChoice = .Rock
    case 1:
        computerChoice = .Paper
    case 2:
        computerChoice = .Scissors
    default:
        computerChoice = .Rock
    }
    
    print("El ordenador ha elegido \(computerChoice.rawValue)")
    return computerChoice
}

func evaluateMove(user: GameChoice, computer: GameChoice) -> PlayResult {
    if user == computer {
        return "Empate! Ambos eligieron \(user)."
    }
    
    switch (user, computer) {
    case (.Rock, .Scissors), (.Scissors, .Paper), (.Paper, .Rock):
        return "Ganaste! \(user) vence a \(computer)."
        // En caso de que..
    default:
        return "Perdiste! \(computer) vence a \(user)."
    }
}

func displayResult(_ result: PlayResult) -> Void {
    print(result)
}

main()


// Tests
func testEvaluateMove() {
    let user = GameChoice.Rock
    let computer = GameChoice.Scissors
    let result = evaluateMove(user: user, computer: computer)
    assert(result == "Ganaste! Rock vence a Scissors.", "Test evaluate move failed")
}

func testGenerateComputerChoice() {
    let computerChoice = generateComputerChoice()
    assert(computerChoice == .Rock || computerChoice == .Paper || computerChoice == .Scissors, "Test generate computer choice failed")
}

func testIsExit() {
    let choice = GameChoice.Quit
    let result = isExit(choice: choice)
    assert(result == true, "Test is exit failed")
}

func testReadUserChoice() {
    let choice = readUserChoice()
    assert(choice == .Rock || choice == .Paper || choice == .Scissors || choice == .Quit, "Test read user choice failed")
}

func testAll() {
    print("Running tests...")
    testEvaluateMove()
    testGenerateComputerChoice()
    testIsExit()
    testReadUserChoice()
}

testAll()
